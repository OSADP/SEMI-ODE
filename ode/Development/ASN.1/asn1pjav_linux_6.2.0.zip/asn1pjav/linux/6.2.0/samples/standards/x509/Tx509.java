/*****************************************************************************/
/* Copyright (C) 2015 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Tx509.java	16.5 14/02/08
 */

/*
 * This sample test program creates a sample X.509 certificate and prints
 * its contents in a user friendly way. 
 * NOTE: cryptographic algorithms are out of scope of this sample so
 * precalculated values are used in order to create the certificate.
 * These values are taken from 'Sample encoding' shown in Appendix D.1
 * of RFC 2459.
 * The program accepts an optional argument - input file with DER encoded
 * X.509 certificate. If it is specified, contents of the file are 
 * decoded and certificate is printed. By default, when no argument is 
 * specified, the program creates a 'sample.cer' certificate file by DER-
 * encoding a fixed Certificate PDU value, decodes the file back to memory
 * and prints its contents.
 */

import java.io.*;
import java.math.BigInteger;

import com.oss.asn1.*;
import com.oss.util.HexTool;
import com.oss.util.ASN1ObjidFormat;
import com.oss.asn1printer.DataPrinter;

import x509.*;
import x509.authenticationframework.*;
import x509.informationframework.*;
import x509.certificateextensions.*;
import x509.selectedattributetypes.*;
import x509.mtsabstractservice.OrganizationName;
import x509.mtsabstractservice.OrganizationalUnitName;
import x509.x509sample.*;

public class Tx509 {

    /* precalculated 'p' DSA parameter value */
    static byte[] p = {
    (byte)0xD4, (byte)0x38, (byte)0x02, (byte)0xC5, (byte)0x35, (byte)0x7B, (byte)0xD5, (byte)0x0B, 
    (byte)0xA1, (byte)0x7E, (byte)0x5D, (byte)0x72, (byte)0x59, (byte)0x63, (byte)0x55, (byte)0xD3,
    (byte)0x45, (byte)0x56, (byte)0xEA, (byte)0xE2, (byte)0x25, (byte)0x1A, (byte)0x6B, (byte)0xC5, 
    (byte)0xA4, (byte)0xAB, (byte)0xAA, (byte)0x0B, (byte)0xD4, (byte)0x62, (byte)0xB4, (byte)0xD2,
    (byte)0x21, (byte)0xB1, (byte)0x95, (byte)0xA2, (byte)0xC6, (byte)0x01, (byte)0xC9, (byte)0xC3, 
    (byte)0xFA, (byte)0x01, (byte)0x6F, (byte)0x79, (byte)0x86, (byte)0x83, (byte)0x3D, (byte)0x03,
    (byte)0x61, (byte)0xE1, (byte)0xF1, (byte)0x92, (byte)0xAC, (byte)0xBC, (byte)0x03, (byte)0x4E, 
    (byte)0x89, (byte)0xA3, (byte)0xC9, (byte)0x53, (byte)0x4A, (byte)0xF7, (byte)0xE2, (byte)0xA6,
    (byte)0x48, (byte)0xCF, (byte)0x42, (byte)0x1E, (byte)0x21, (byte)0xB1, (byte)0x5C, (byte)0x2B, 
    (byte)0x3A, (byte)0x7F, (byte)0xBA, (byte)0xBE, (byte)0x6B, (byte)0x5A, (byte)0xF7, (byte)0x0A,
    (byte)0x26, (byte)0xD8, (byte)0x8E, (byte)0x1B, (byte)0xEB, (byte)0xEC, (byte)0xBF, (byte)0x1E, 
    (byte)0x5A, (byte)0x3F, (byte)0x45, (byte)0xC0, (byte)0xBD, (byte)0x31, (byte)0x23, (byte)0xBE,
    (byte)0x69, (byte)0x71, (byte)0xA7, (byte)0xC2, (byte)0x90, (byte)0xFE, (byte)0xA5, (byte)0xD6, 
    (byte)0x80, (byte)0xB5, (byte)0x24, (byte)0xDC, (byte)0x44, (byte)0x9C, (byte)0xEB, (byte)0x4D,
    (byte)0xF9, (byte)0xDA, (byte)0xF0, (byte)0xC8, (byte)0xE8, (byte)0xA2, (byte)0x4C, (byte)0x99, 
    (byte)0x07, (byte)0x5C, (byte)0x8E, (byte)0x35, (byte)0x2B, (byte)0x7D, (byte)0x57, (byte)0x8D
    };

    /* precalculated 'q' DSA parameter value */
    static byte[] q = {
    (byte)0xA7, (byte)0x83, (byte)0x9B, (byte)0xF3, (byte)0xBD, (byte)0x2C, (byte)0x20, (byte)0x07, 
    (byte)0xFC, (byte)0x4C, (byte)0xE7, (byte)0xE8, (byte)0x9F, (byte)0xF3, (byte)0x39, (byte)0x83,
    (byte)0x51, (byte)0x0D, (byte)0xDC, (byte)0xDD
    };

    /* precalculated 'g' DSA parameter value */
    static byte[] g = {
    (byte)0x0E, (byte)0x3B, (byte)0x46, (byte)0x31, (byte)0x8A, (byte)0x0A, (byte)0x58, (byte)0x86,
    (byte)0x40, (byte)0x84, (byte)0xE3, (byte)0xA1, (byte)0x22, (byte)0x0D, (byte)0x88, (byte)0xCA,
    (byte)0x90, (byte)0x88, (byte)0x57, (byte)0x64, (byte)0x9F, (byte)0x01, (byte)0x21, (byte)0xE0, 
    (byte)0x15, (byte)0x05, (byte)0x94, (byte)0x24, (byte)0x82, (byte)0xE2, (byte)0x10, (byte)0x90,
    (byte)0xD9, (byte)0xE1, (byte)0x4E, (byte)0x10, (byte)0x5C, (byte)0xE7, (byte)0x54, (byte)0x6B, 
    (byte)0xD4, (byte)0x0C, (byte)0x2B, (byte)0x1B, (byte)0x59, (byte)0x0A, (byte)0xA0, (byte)0xB5,
    (byte)0xA1, (byte)0x7D, (byte)0xB5, (byte)0x07, (byte)0xE3, (byte)0x65, (byte)0x7C, (byte)0xEA, 
    (byte)0x90, (byte)0xD8, (byte)0x8E, (byte)0x30, (byte)0x42, (byte)0xE4, (byte)0x85, (byte)0xBB,
    (byte)0xAC, (byte)0xFA, (byte)0x4E, (byte)0x76, (byte)0x4B, (byte)0x78, (byte)0x0E, (byte)0xDF, 
    (byte)0x6C, (byte)0xE5, (byte)0xA6, (byte)0xE1, (byte)0xBD, (byte)0x59, (byte)0x77, (byte)0x7D,
    (byte)0xA6, (byte)0x97, (byte)0x59, (byte)0xC5, (byte)0x29, (byte)0xA7, (byte)0xB3, (byte)0x3F,
    (byte)0x95, (byte)0x3E, (byte)0x9D, (byte)0xF1, (byte)0x59, (byte)0x2D, (byte)0xF7, (byte)0x42,
    (byte)0x87, (byte)0x62, (byte)0x3F, (byte)0xF1, (byte)0xB8, (byte)0x6F, (byte)0xC7, (byte)0x3D,
    (byte)0x4B, (byte)0xB8, (byte)0x8D, (byte)0x74, (byte)0xC4, (byte)0xCA, (byte)0x44, (byte)0x90,
    (byte)0xCF, (byte)0x67, (byte)0xDB, (byte)0xDE, (byte)0x14, (byte)0x60, (byte)0x97, (byte)0x4A,
    (byte)0xD1, (byte)0xF7, (byte)0x6D, (byte)0x9E, (byte)0x09, (byte)0x94, (byte)0xC4, (byte)0x0D
    };

    /* precalculated 'subjectPublicKey' value */
    static byte[] subjectPublicKey = {
    (byte)0xAA, (byte)0x98, (byte)0xEA, (byte)0x13, (byte)0x94, (byte)0xA2, (byte)0xDB, (byte)0xF1, (byte)0x5B, (byte)0x7F,
    (byte)0x98, (byte)0x2F, (byte)0x78, (byte)0xE7, (byte)0xD8, (byte)0xE3, (byte)0xB9, (byte)0x71, (byte)0x86, (byte)0xF6,
    (byte)0x80, (byte)0x2F, (byte)0x40, (byte)0x39, (byte)0xC3, (byte)0xDA, (byte)0x3B, (byte)0x4B, (byte)0x13, (byte)0x46,
    (byte)0x26, (byte)0xEE, (byte)0x0D, (byte)0x56, (byte)0xC5, (byte)0xA3, (byte)0x3A, (byte)0x39, (byte)0xB7, (byte)0x7D,
    (byte)0x33, (byte)0xC2, (byte)0x6B, (byte)0x5C, (byte)0x77, (byte)0x92, (byte)0xF2, (byte)0x55, (byte)0x65, (byte)0x90,
    (byte)0x39, (byte)0xCD, (byte)0x1A, (byte)0x3C, (byte)0x86, (byte)0xE1, (byte)0x32, (byte)0xEB, (byte)0x25, (byte)0xBC,
    (byte)0x91, (byte)0xC4, (byte)0xFF, (byte)0x80, (byte)0x4F, (byte)0x36, (byte)0x61, (byte)0xBD, (byte)0xCC, (byte)0xE2,
    (byte)0x61, (byte)0x04, (byte)0xE0, (byte)0x7E, (byte)0x60, (byte)0x13, (byte)0xCA, (byte)0xC0, (byte)0x9C, (byte)0xDD,
    (byte)0xE0, (byte)0xEA, (byte)0x41, (byte)0xDE, (byte)0x33, (byte)0xC1, (byte)0xF1, (byte)0x44, (byte)0xA9, (byte)0xBC,
    (byte)0x71, (byte)0xDE, (byte)0xCF, (byte)0x59, (byte)0xD4, (byte)0x6E, (byte)0xDA, (byte)0x44, (byte)0x99, (byte)0x3C,
    (byte)0x21, (byte)0x64, (byte)0xE4, (byte)0x78, (byte)0x54, (byte)0x9D, (byte)0xD0, (byte)0x7B, (byte)0xBA, (byte)0x4E,
    (byte)0xF5, (byte)0x18, (byte)0x4D, (byte)0x5E, (byte)0x39, (byte)0x30, (byte)0xBF, (byte)0xE0, (byte)0xD1, (byte)0xF6,
    (byte)0xF4, (byte)0x83, (byte)0x25, (byte)0x4F, (byte)0x14, (byte)0xAA, (byte)0x71, (byte)0xE1
    };

    /* precalculated 'SubjectKeyIdentifier' value */
    static byte[] subject_key_identifier = {
    (byte)0xE7, (byte)0x26, (byte)0xC5, (byte)0x54, (byte)0xCD, (byte)0x5B, (byte)0xA3, (byte)0x6F,
    (byte)0x35, (byte)0x68, (byte)0x95, (byte)0xAA, (byte)0xD5, (byte)0xFF, (byte)0x1C, (byte)0x21,
    (byte)0xE4, (byte)0x22, (byte)0x75, (byte)0xD6
    };

    /* precalculated DSA signature 'r' value */
    static byte[] r_value = {
    (byte)0xA0, (byte)0x66, (byte)0xC1, (byte)0x76, (byte)0x33, (byte)0x99, (byte)0x13, (byte)0x51, (byte)0x8D, (byte)0x93,
    (byte)0x64, (byte)0x2F, (byte)0xCA, (byte)0x13, (byte)0x73, (byte)0xDE, (byte)0x79, (byte)0x1A, (byte)0x7D, (byte)0x33
    };

    /* precalculated DSA signature 's' value */
    static byte[] s_value = {
    (byte)0x5D, (byte)0x90, (byte)0xF6, (byte)0xCE, (byte)0x92, (byte)0x4A, (byte)0xBF, (byte)0x29, (byte)0x11, (byte)0x24,
    (byte)0x80, (byte)0x28, (byte)0xA6, (byte)0x5A, (byte)0x8E, (byte)0x73, (byte)0xB6, (byte)0x76, (byte)0x02, (byte)0x68
    };

    /* the file with certificate to be printed */
    static String certFile = "sample.cer";
    /* the writer which will print certificate */
    static DataPrinter.IndentationWriter writer = new DataPrinter.IndentationWriter(System.out, true);
    static int indent = 4;

    /*
     * SupportedAttributes     ATTRIBUTE       ::=     {
     *   name | commonName | surname | givenName | initials |
     *   generationQualifier | dnQualifier | countryName |
     *   localityName | stateOrProvinceName | organizationName |
     *   organizationalUnitName | title | pkcs9email }
     */
    static SupportedAttribute[] attributes = {
	new DirectoryStringAttribute(SelectedAttributeTypes.name, "name", null, Name.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.commonName, "CN", null, CommonName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.surname, "SN", null, Surname_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.givenName, "givenName", null, GivenName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.initials, "initials", null, Initials_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.generationQualifier, "generationQualifier", null, GenerationQualifier_WITH_SYNTAX.class),
	new OtherStringAttribute(SelectedAttributeTypes.dnQualifier, "dnQualifier", null, null),
	new OtherStringAttribute(SelectedAttributeTypes.countryName, "C", new CountryName("US"), CountryName.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.organizationName, "O", 
	    OrganizationName_WITH_SYNTAX.createOrganizationName_WITH_SYNTAXWithPrintableString(new PrintableString("gov")), OrganizationName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.organizationalUnitName, "OU", 
	    OrganizationalUnitName_WITH_SYNTAX.createOrganizationalUnitName_WITH_SYNTAXWithPrintableString(new PrintableString("nist")),
				     OrganizationalUnitName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.localityName, "L", null, LocalityName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.stateOrProvinceName, "ST", null, StateOrProvinceName_WITH_SYNTAX.class),
	new DirectoryStringAttribute(SelectedAttributeTypes.title, "title", null, Title_WITH_SYNTAX.class),
	new OtherStringAttribute(X509Sample.pkcs9email, "Email", null, null)
    };

    static final String[] months =
    {
	"Jan","Feb","Mar","Apr","May","Jun",
	"Jul","Aug","Sep","Oct","Nov","Dec"
    };
    
    static Coder coder;

    public static void main(String[] args) throws java.io.FileNotFoundException, Exception
    {
	// Initialize the project
	try {
	    X509.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = X509.getDERCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	initObjectSets();

	switch (args.length) {
	    case 0:
		/* 
		 * No argument is specified. Create a sample certificate
		 * and print its contents.
		 */
		try { 
		    create_X509Certificate();
		} catch (Exception e) {
		    System.out.println(e.getMessage());
		}
		break;
	    case 1:
		/* 
		 * A file containing X.509 certificates as DER encoding is specified;
		 * decode the file contents and print the Certificate decoded.
		 */
		certFile = args[0];
		break;
	    default:
		System.out.println("Usage: java X509 [X.509 certificate file to print]\n");
		System.exit(1);
	}

	FileInputStream source = new FileInputStream(new File(certFile));
	/*
	 * Decode the PDU (certificate)
	 */
	Certificate msg = null;

	try {
	    msg = (Certificate)coder.decode(source, new Certificate());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}

	/* Print the certificate contents */
    	print_X509_Certificate(msg);
    }

    /* Creates sample X.509 certificate */
    static void create_X509Certificate() throws Exception
    {
	/* the certificate is signed with DSA and the SHA-1 hash algorithm; */
	AlgorithmIdentifier signatureAlgorithm = 
	    new AlgorithmIdentifier((ObjectIdentifier)X509Sample.id_dsa_with_sha1.clone());

	Validity validity = 
	    new Validity (Time.createTimeWithUtcTime(new UTCTime("970630000000Z")),
			  Time.createTimeWithUtcTime(new UTCTime("971231000000Z")));

	Certificate.ToBeSigned toBeSigned = 
	    new Certificate.ToBeSigned(
		create_CertificateSerialNumber(),  /* the serial number is 17 (11 hex); */
		signatureAlgorithm,
		get_CertSubjectOrIssuer(),	   /* the issuer is "OU=nist; O=gov; C=US" */
		validity,
		get_CertSubjectOrIssuer(),	   /* the subject is "OU=nist; O=gov; C=US" */
		create_SubjectPublicKeyInfo()
	    );
	    
	toBeSigned.setVersion(Version.v3);	   /* version 3 certificate */

	Certificate pdu = new Certificate();
	pdu.setToBeSigned(toBeSigned);
	add_BasicConstraintExtension(pdu, true, true, 0);
	add_SubjectKeyIdentifierExtension(pdu, subject_key_identifier);
	sign_X509Certificate(pdu);	
	FileOutputStream out = new FileOutputStream(certFile);

	try {
	    coder.encode(pdu, out);
	    out.close();
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}
    }

    /* Stub function to create a 'serialNumber' value */
    static HugeInteger create_CertificateSerialNumber()
    {
	/* 
	 * Place code here to get unique serial number. This sample just returns
	 * the predefined value.
	 */
	return new HugeInteger(new BigInteger("11", 16));
    }

    /* Function to get Certificate subject or Certificate issuer from user */
    static Name get_CertSubjectOrIssuer()
    {
	RDNSequence rdnSequence = new RDNSequence();
	/* for every attribute in attributes[] array */
	for (int i = 0; i < attributes.length; i++) {
	    /* Get attribute value from user */
	    Object attrVal = attributes[i].get_Attribute();
	    if (attrVal != null) {
		ObjectIdentifier type = attributes[i].object.getId();
		OpenType value = new OpenType((AbstractData) attrVal);
		AttributeTypeAndDistinguishedValue attrTypeAndVal = 
		    new AttributeTypeAndDistinguishedValue(type, value);
		RelativeDistinguishedName rdName = new RelativeDistinguishedName();
		rdName.add(attrTypeAndVal); 
		rdnSequence.add(rdName);
	    }
	}	    
	return Name.createNameWithRdnSequence(rdnSequence);
    }

    /* Utility function filling in 'SubjectPublicKeyInfo' certificate data
     * (uses hardcoded value instead of generating a key pair). 
     */
    static SubjectPublicKeyInfo create_SubjectPublicKeyInfo()
    {
	AlgorithmIdentifier pkeyAlgorithm = 
	    new AlgorithmIdentifier(
		(ObjectIdentifier)X509Sample.id_dsa.clone(), /* indicate that DSA algorithm is used */
		new OpenType(DSA_generate_parameters())      /* indicate that optional DSA parameters are present */
	    );
	/* 
	 * Generate a private key
         * 4. x = a randomly or pseudorandomly generated integer with 0 < x < q
         * This step is skipped in this sample since we use precalculated
         * signature and publick key
         *
         * Calculate publick key
         * 5. y = gx mod p
         */
	DSAPublicKey pKey = new DSAPublicKey(new BigInteger(subjectPublicKey));
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(pKey, sink);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}

	BitString encoded_pKey = new BitString(sink.toByteArray());
	SubjectPublicKeyInfo spki = 
	    new SubjectPublicKeyInfo(pkeyAlgorithm, encoded_pKey);
	return spki;
    }

    /* Signs existing X.509 certificate (uses hardcoded key values for this) */
    static void sign_X509Certificate(Certificate x509)
    {
	/* indicate algorithm used for signing */
	AlgorithmIdentifier algorithm = new AlgorithmIdentifier(
		    (ObjectIdentifier)X509Sample.id_dsa_with_sha1.clone());
	
	x509.setAlgorithmIdentifier(algorithm);

	ByteArrayOutputStream toBeSigned = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(x509.getToBeSigned(), toBeSigned);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}
	/* calculate SHA message digest (skip the step for this sample)
	 * 
         * calculate signature r value
         * r = (g^k mod p) mod q
         *
         * calculate signature s value
         * s = (k^-1(SHA(M) + xr)) mod q.
         */

	ByteArrayOutputStream encodedSignature = new ByteArrayOutputStream();
	Dss_Sig_Value signature = 
	    new Dss_Sig_Value(new HugeInteger(new BigInteger(r_value)),
			      new HugeInteger(new BigInteger(s_value)));
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(signature, encodedSignature);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}
	/* The encoded signature is conveyed as the value of the BIT STRING */
	x509.setEncrypted(new BitString(encodedSignature.toByteArray()));
    }

    /* Wrapper to add_Extension that adds given BasicConstraintsSyntax extension */
    static void add_BasicConstraintExtension(Certificate x509,
			boolean critical, boolean isCa, long pathLenConstraint)
    {
	BasicConstraintsSyntax bcSyntax = new BasicConstraintsSyntax();
	if (isCa)
	    bcSyntax.setCA(true);
	if (isCa && pathLenConstraint != 0)
	    bcSyntax.setPathLenConstraint(pathLenConstraint);
	add_Extension(x509, critical, CertificateExtensions.id_ce_basicConstraints, bcSyntax);
    }

    /* Wrapper to add_Extension that adds given SubjectKeyIdentifier extension */
    static void add_SubjectKeyIdentifierExtension(Certificate x509, byte[] idValue)
    {
	SubjectKeyIdentifier keyIdentifier = new SubjectKeyIdentifier(idValue);
	add_Extension(x509, false, CertificateExtensions.id_ce_subjectKeyIdentifier, 
								      keyIdentifier);
    }

    /* Utility function adding an extension to certificate. Extension is
     * provided in a form of unencoded value of some PDU type. 
     */
    static void add_Extension(Certificate x509, boolean critical, 
			      ObjectIdentifier extnId, AbstractData ext_data)
    {
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(ext_data, sink);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}
	Extension_1 ext = new Extension_1(extnId, critical, 
					  new OctetString(sink.toByteArray()));

	if (x509.getToBeSigned().getExtensions() == null) 
	    x509.getToBeSigned().setExtensions(new Extensions());
	x509.getToBeSigned().getExtensions().add(ext);
    }

    /* Stub function to calculate DSA parameters (uses hardcoded values instead) */
    static Dss_Parms DSA_generate_parameters()
    {
	/* 
         * 1. p = a prime modulus, where 2L-1 < p >< 2L for 512 =< L =< 1024
         * and L a multiple of 64>
	 * 2. q = a prime divisor of p - 1, where 2159 < q < 2160  
	 * 3. g = h(p-1)/q mod p, where h is any integer with 1 < h < p - 1 
	 * such that h(p-1)/q mod p > 1 (g has order q mod p)
         */
	Dss_Parms pdu = new Dss_Parms(new HugeInteger(new BigInteger(p)),
				      new HugeInteger(new BigInteger(q)),
				      new HugeInteger(new BigInteger(g))
				     );
	return pdu;
    }

    /* Illustrates the run-time manipulation of information object sets. */
    static void initObjectSets()
    {
	for (int i = 0; i < attributes.length; i++) {
	    InformationFramework.supportedAttributes.addElement(attributes[i].object);
	}

	AuthenticationFramework.extensionSet.addElement(CertificateExtensions.subjectKeyIdentifier);
	AuthenticationFramework.extensionSet.addElement(CertificateExtensions.basicConstraints);
	AuthenticationFramework.supportedAlgorithms_1.addElement(X509Sample.dssPublicKey);
	AuthenticationFramework.supportedAlgorithms_1.addElement(X509Sample.dsaSHA_1);
    }

    /*
     * The below functions print any valid X.509 certificate. The output format
     * is close to one used in Open-SSL implementation to display certificates.
     */

    /* prints an X.509 certificate */
    static void print_X509_Certificate(Certificate x509) throws Exception
    {    
	Version  version = Version.v1; 	/* Certificate version (default v1) */
	writer.print("Certificate:");
	writer.setIndentWidth(indent);
	writer.indent(); /* raise indent level */
	writer.println();
	writer.print("Data:");
	writer.indent(); /* raise indent level */
	writer.println();
	/* Determine the certificate version */
	Certificate.ToBeSigned toBeSigned = x509.getToBeSigned();

	if (toBeSigned.hasVersion())
	    version = toBeSigned.getVersion();
	else if (toBeSigned.hasExtensions())
	    /* if the extensions component is present version shall be v3 */
	    version = Version.v3;
	else if (toBeSigned.hasIssuerUniqueIdentifier())
	    /*
	     * If the issuerUniqueIdentifier or subjectUniqueIdentifier component
	     * is present version shall be v2
	     */
	    version = Version.v2;
	writer.print("Version: " + (version.intValue()+ 1) +
		     " (0x" +  (version.intValue()) + ")");
	writer.println();
	writer.print("Serial Number: ");
	HugeInteger serial = toBeSigned.getSerialNumber();
	writer.print(serial.bigIntegerValue().toString() +
		    " (0x" + serial.bigIntegerValue().toString(16) + ")");
	writer.println();
	writer.print("Issuer:");
	print_RDNames((RDNSequence) toBeSigned.getIssuer().getChosenValue());
	writer.println();
	writer.print("Validity");
	writer.indent();
	writer.println();
	writer.print("Not Before: ");
	print_Time(toBeSigned.getValidity().getNotBefore());
	writer.println();
	writer.print("Not After : ");
	print_Time(toBeSigned.getValidity().getNotAfter());
	writer.undent();
	writer.println();
	writer.print("Subject:");
	print_RDNames((RDNSequence) toBeSigned.getSubject().getChosenValue());
	writer.println();
	writer.print("Subject Public Key Info:");
	writer.indent();
	writer.println();
	print_SubjectPublicKeyInfo(toBeSigned.getSubjectPublicKeyInfo());
	writer.undent();
	writer.println();

	if (toBeSigned.hasExtensions()) {
	    print_Extensions(toBeSigned.getExtensions());
	}
	writer.undent();
	writer.println();
    	print_Signature(x509);
    }

    /* prints RDNSequence (a list of RelativeDistinguishedName's) */
    static void print_RDNames(RDNSequence rdnSequence)
    {
        for (int i = 0; i < rdnSequence.getSize(); i++) {
    	    RelativeDistinguishedName name  = rdnSequence.get(i);

    	    for (int j = 0; j < name.getSize(); j++) {
		AttributeTypeAndDistinguishedValue attr = name.get(j);

		if (attr.getValue().getDecodedValue() == null) {
		    /* 
		     * Unknown attribute: print attribute type object identificator.
		     */
		    try {
			String oid_type =
			    ASN1ObjidFormat.formatOID(attr.getType().byteArrayValue(), false, true);
			writer.print(oid_type + "=#");
			String oid_value =
			    HexTool.getHex(attr.getValue().getEncodedValue(), 0).replaceAll(" ", "");
			/*
			 * Print attribute value in hex.
			 */
			print_Hex(oid_value, false);
		    } catch (Exception e) {
			System.out.println(e.getMessage());
		    }
		} else {
		    /*
		     * The attribute is automatically decoded
		     */
		    for (int k = 0; k < attributes.length; k++) {
			if (attributes[k].matches(attr.getValue().getDecodedValue())) {
			    attributes[k].print_Attribute(attr);
                        }
		    }
		}

		if (j < name.getSize()-1)
		    writer.print("+");
	    } /* for */

	    if (i < rdnSequence.getSize()-1)
		writer.print(",");
	} /* for */
    }

    /* prints data in HEX */
    static void print_Hex(String value, boolean multiline)
    {
	int i;
	for (i = 0; i < value.length() - 3; i = i + 2) {
	    if (multiline && (i % 15) == 0) {
		writer.println();
	    }
	    writer.print(value.substring(i, i + 2) + ":");
	}
	writer.print(value.substring(i, i + 2));
    }

    /* prints Time value */
    static void print_Time(Time tm)
    {
	AbstractTime time;
	if (tm.getChosenFlag() == Time.utcTime_chosen) {
	    time = (UTCTime)tm.getChosenValue();
	} else 
	    time = (GeneralizedTime)tm.getChosenValue();
	String mindiff = (time.getMinuteDifferential() == 0 ? " GMT" : "");
	writer.print(months[time.getMonth() - 1] + " " + time.getDay() + " " +
		addZero(time.getHour()) + ":" + addZero(time.getMinute()) + ":" + 
		addZero(time.getSecond()) + 
		" " + time.getYear() + mindiff);
    }

    /* add '0' before simple quantity */
    public static String addZero(int i)
    {
	if (i < 10)
	    return "0".concat(String.valueOf(i));
	return String.valueOf(i);
    }

    /* prints SubjectPublicKeyInfo value */
    static void print_SubjectPublicKeyInfo(SubjectPublicKeyInfo spki)
    {
	AlgorithmIdentifier algorithm = spki.getAlgorithm();

	if (algorithm.getAlgorithm().equals(X509Sample.id_dsa)) {
	    writer.print("Public Key Algorithm: dsaEncryption");

    	    byte[] array = spki.getSubjectPublicKey().byteArrayValue();
    	    ByteArrayInputStream source = new ByteArrayInputStream(array);
    	    DSAPublicKey pKey = null;
	    try {
		pKey = (DSAPublicKey) coder.decode(source, new DSAPublicKey());
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoding failed: " + e);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoding failed: " + e);
	    }

	    writer.println();
	    writer.print("DSA Public Key:");
	    writer.indent();
	    writer.println();
	    writer.print("pub:");
	    writer.indent();
	    String pKey_value = null;
	    if (pKey != null) {
		pKey_value = HexTool.getHex(pKey.bigIntegerValue().toByteArray(), 0).replaceAll(" ", "");
		print_Hex(pKey_value, true);
	    }
	    writer.undent();
	    writer.println();

	    if (algorithm.getParameters() != null 
		    && algorithm.getParameters().getDecodedValue() != null) {
		writer.print("P:");
		Dss_Parms dss_parms = (Dss_Parms)algorithm.getParameters().getDecodedValue();
		writer.indent();
		String dss_parms_value = 
		    HexTool.getHex(dss_parms.getP().bigIntegerValue().toByteArray(),0).replaceAll(" ", "");
		print_Hex(dss_parms_value, true);
		writer.undent();
		writer.println();
		writer.print("Q:");
		writer.indent();
		dss_parms_value = 
		    HexTool.getHex(dss_parms.getQ().bigIntegerValue().toByteArray(),0).replaceAll(" ", "");
		print_Hex(dss_parms_value, true);
		writer.undent();
		writer.println();
		writer.print("G:");
		writer.indent();
		dss_parms_value = 
		    HexTool.getHex(dss_parms.getG().bigIntegerValue().toByteArray(),0).replaceAll(" ", "");
		print_Hex(dss_parms_value, true);
		writer.undent();
	    }
	    writer.undent();
	} else {
	    writer.println();
	    writer.print("Public Key Algorithm: algorithm not supported");
	}
    }

    /* prints supported X.509 certificate extensions */
    static void print_Extensions(Extensions extensions)
    {
	writer.print("X509v3 extensions:");
	writer.indent();
	writer.println();

        for (int i = 0; i <  extensions.getSize(); i++) {
    	    Extension_1 ext_data = extensions.get(i);

	    if (ext_data.getExtnId().equals(
		    CertificateExtensions.id_ce_basicConstraints)) {
		writer.print("X509v3 Basic Constraints: " +
			    (ext_data.hasCritical() ? "critical" : ""));

    		byte[] array = ext_data.getExtnValue().byteArrayValue();
    		ByteArrayInputStream source = new ByteArrayInputStream(array);
		BasicConstraintsSyntax bcSyntax = null;

		try {
		    bcSyntax = (BasicConstraintsSyntax)
			coder.decode(source, new BasicConstraintsSyntax());
		} catch (DecodeNotSupportedException e) {
		    System.out.println("Decoding failed: " + e);
		} catch (DecodeFailedException e) {
		    System.out.println("Decoding failed: " + e);
		}
		writer.indent();

		if (bcSyntax.hasCA()) {
		    writer.println();
		    writer.print("CA:" + (bcSyntax.getCA() ? "TRUE" : "FALSE"));
		}

		if (bcSyntax.hasPathLenConstraint()) {
		    writer.println();
		    writer.print("pathlen:" + bcSyntax.getPathLenConstraint());
		}
		writer.undent();
	    } else if (ext_data.getExtnId().equals(
		    CertificateExtensions.id_ce_subjectKeyIdentifier)) {
		writer.println();
		writer.print("X509v3 Subject Key Identifier: " +
			    (ext_data.hasCritical() ? "critical" : ""));

    		byte[] array = ext_data.getExtnValue().byteArrayValue();
    		ByteArrayInputStream source = new ByteArrayInputStream(array);
		SubjectKeyIdentifier keyIdentifier = null;

		try {
		    keyIdentifier = (SubjectKeyIdentifier) 
			coder.decode(source, new SubjectKeyIdentifier());
		} catch (DecodeNotSupportedException e) {
		    System.out.println("Decoding failed: " + e);
		} catch (DecodeFailedException e) {
		    System.out.println("Decoding failed: " + e);
		}

		String keyIdentifier_value = null;
		if (keyIdentifier != null) {
		    writer.indent();
		    keyIdentifier_value = 
			HexTool.getHex(keyIdentifier.byteArrayValue(), 0).replaceAll(" ", "");
		    print_Hex(keyIdentifier_value, true);
		    writer.undent();
		}
	    } else {
		writer.println();
		writer.print("X509v3 Not Supported: " +
			    (ext_data.hasCritical() ? "critical" : ""));
		writer.indent();
		String value =
		    HexTool.getHex(ext_data.getExtnValue().byteArrayValue(), 0).replaceAll(" ", "");
		    print_Hex(value, true);
		writer.undent();
	    }
	}
	writer.undent();
    }

    /* prints identification of a signature algorithm, if supported */
    static void print_Signature(Certificate x509)
    {
	AlgorithmIdentifier algorithmId = x509.getAlgorithmIdentifier();

	if (algorithmId.getAlgorithm().equals(X509Sample.id_dsa_with_sha1)) {
	    writer.print("Signature Algorithm: dsaWithSHA1");
	    writer.indent();
	    String value =
		HexTool.getHex(x509.getEncrypted().byteArrayValue(), 0).replaceAll(" ", "");
	    print_Hex(value, true);
	    writer.undent();
	    writer.println();
	} else
	    writer.print("Signature Algorithm: algorithm not supported");
    }

    /* 
     * Auxiliary class, which contains all the information about
     * X.509 certificate attributes. Facilitates work with attributes.
     */
    abstract static class SupportedAttribute
    {
	public ATTRIBUTE_2 object;  /*
	                    	     * pointer to the information object corresponding
	                             * to the given attribute
	                             */
	public String typeString;   /* attribute type name string as per RFC2256 */
	public Object dflt_val;	    /* attribute default value */
	Class  javaClass;	    /* Class of a attibute */
    
	protected SupportedAttribute(ATTRIBUTE_2 object, String typeString, 
				Object dflt_val, Class javaClass)
	{
	    this.object = object;
	    this.typeString = typeString; 
	    this.dflt_val = dflt_val;	  
	    this.javaClass = javaClass;
	}
	
	/* prints attribute */
	abstract void print_Attribute(AttributeTypeAndDistinguishedValue attr);
	
	/* gets attribute from a user */
	Object get_Attribute() { 
	    /*
	     * Place code here to get the attribute value from user
	     */
	    return dflt_val; 
	}
	
	/* compares class of the attribute with class of the value */
	boolean matches(AbstractData value)
	{
	    return javaClass == value.getClass();
	}
    } // End class definition for SupportedAttribute
    
    /* 
     * Auxiliary class, which contains all the information about
     * X.509 certificate DirectoryString attributes.
     * Facilitates work with such attributes.
     */
    static class DirectoryStringAttribute extends SupportedAttribute {
	public DirectoryStringAttribute(ATTRIBUTE_2 object, String typeString,
	                            	    Object dflt_val, Class javaClass) {
	    super(object, typeString, dflt_val, javaClass);
	}

	/* prints a DirectoryString attribute*/
	void print_Attribute(AttributeTypeAndDistinguishedValue attr)
	{
	    writer.print(typeString + "=");
	    DirectoryString value = (DirectoryString)attr.getValue().getDecodedValue();
	    
	    switch (value.getChosenFlag()) {
		case DirectoryString.printableString_chosen:
		case DirectoryString.teletexString_chosen:
		case DirectoryString.uTF8String_chosen:
		case DirectoryString.bmpString_chosen:
		    writer.print(((AbstractString16)value.getChosenValue()).stringValue());
		    break;
		case DirectoryString.universalString_chosen:
		    writer.print("universalString"); 			/* Unimplemented */
	    }
	}	
    }

    /* 
     * Auxiliary class, which contains all the information about
     * X.509 certificate non-DirectoryString attributes. 
     * Facilitates work with such attributes.
     */
    static class OtherStringAttribute extends SupportedAttribute {
	public OtherStringAttribute(ATTRIBUTE_2 object, String typeString,
	                            	    Object dflt_val, Class javaClass) {
	    super(object, typeString, dflt_val, javaClass);
	}
	
	/* prints a non-DirectoryString attribute*/
	void print_Attribute(AttributeTypeAndDistinguishedValue attr)
	{
	    writer.print(typeString + "=");
	    AbstractString16 value = (AbstractString16)attr.getValue().getDecodedValue();
	    writer.print(value.stringValue());
	}	
    }
}
