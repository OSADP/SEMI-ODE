/*****************************************************************************/
/* Copyright (C) 2015 OSS Nokalva, Inc.  All rights reserved.	          */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Tsbcap.java	17.1  14/06/01
 */

/*
 * Demonstrates work with data for SBCAP protocol of LTE.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.*;
import sbcap.*;
import sbcap.oss_sbcap_sbc_ap_commondatatypes.*;
import sbcap.oss_sbcap_sbc_ap_constants.*;
import sbcap.oss_sbcap_sbc_ap_containers.*;
import sbcap.oss_sbcap_sbc_ap_ies.*;
import sbcap.oss_sbcap_sbc_ap_pdu_contents.*;
import sbcap.oss_sbcap_sbc_ap_pdu_descriptions.*;

public class Tsbcap {

    static Coder coder;
    static String border = "-------------------------------------------------------";

    /*
     * Decodes and prints the input messages; creates, encodes and prints 
     * the output (response) messages.
     */
    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    Sbcap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = Sbcap.getPERAlignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	try {
	    test_SBCAP_Message("SBC-AP-PDU_WriteReplaceWarningRequest_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * Prints ProtocolExtensionContainer data.
     */
    static void printProtocolExtensions(OSS_SBCAP_ProtocolExtensionContainer ie_Extensions) 
    {
        System.out.println("IE-Extensions includes the following extensions:");
        for (int i=0; i<ie_Extensions.getSize(); i++) {
            OSS_SBCAP_ProtocolExtensionField ext = ie_Extensions.get(i);
            System.out.printf("EXTENSION#%d: id = %d, criticality = %s\n",
                i+1, ext.getId().intValue(), ext.getCriticality().name());
            AbstractData value = ext.getExtensionValue().getDecodedValue();
            if (value != null) {
                System.out.print(value);
            } else {
                System.out.println("The EXTENSION was left undecoded: ");
                System.out.println(HexTool.getHex(ext.getExtensionValue().getEncodedValue()));
            }
        }
    }

    /*
     * Prints the list of TAIs.
     */
    static void printListOfTAIs(OSS_SBCAP_List_of_TAIs tais) 
    {
        System.out.println("value List-of-TAIs:");
        // Print each TAI
        for (int i=0; i<tais.getSize(); i++) {
            System.out.printf("TAI#%d\n", i+1);
            OSS_SBCAP_TAI tai = tais.get(i).getTai();
            System.out.printf("%s: %s\n",  "PLMN-Identity", 
                toHstring(tai.getPLMNidentity().byteArrayValue()));
            System.out.printf("%s: %s\n",  "TAC", 
                toHstring(tai.getTAC().byteArrayValue()));
            if (tai.hasIE_Extensions())
                printProtocolExtensions(tai.getIE_Extensions());
        }
    }

    /*
     * Prints ProtocolIE_Container data.
     * This method handles only some IEs that can be present
     * in a Write-Replace-Warning-Request message.    
     */
    static void printProtocolIEs(OSS_SBCAP_ProtocolIE_Container ies) 
    {
        for (int i=0; i<ies.getSize(); i++) {
            OSS_SBCAP_ProtocolIE_Field field = ies.get(i);
            OSS_SBCAP_ProtocolIE_ID field_id = field.getId();
            System.out.printf("IE#%d: id = %2d, criticality = %s\n", i+1, 
                field_id.intValue(), field.getCriticality().name());
            AbstractData value = field.getValue().getDecodedValue();
            if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Message_Identifier)) {
                // Print Message-Identifier IE
                OSS_SBCAP_Message_Identifier ie_value =
                    (OSS_SBCAP_Message_Identifier)value;
                System.out.printf("value %s: %s\n",  "Message-Identifier", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Serial_Number)) {
                // Print Serial-Number IE
                OSS_SBCAP_Serial_Number ie_value =
                    (OSS_SBCAP_Serial_Number)value;
                System.out.printf("value %s: %s\n",  "Serial-Number", 
                    toBstring(ie_value));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_List_of_TAIs)) {
                // Print List-of-TAIs IE
                OSS_SBCAP_List_of_TAIs tais =
                    (OSS_SBCAP_List_of_TAIs)value;
                printListOfTAIs(tais);
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Repetition_Period)) {
                // Print Repetition-Period IE
                OSS_SBCAP_Repetition_Period ie_value =
                    (OSS_SBCAP_Repetition_Period)value;
                System.out.printf("value %s: %d\n",  "Repetition-Period", ie_value.intValue());
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Extended_Repetition_Period)) {
                // Print Extended-Repetition-Period IE
                OSS_SBCAP_Extended_Repetition_Period ie_value =
                    (OSS_SBCAP_Extended_Repetition_Period)value;
                System.out.printf("value %s: %d\n",  "Extended-Repetition-Period", ie_value.intValue());
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Number_of_Broadcasts_Requested)) {
                // Print Number-of-Broadcasts-Requested IE
                OSS_SBCAP_Number_of_Broadcasts_Requested ie_value =
                    (OSS_SBCAP_Number_of_Broadcasts_Requested)value;
                System.out.printf("value %s: %d\n",  "Number-of-Broadcasts-Requested", ie_value.intValue());
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Warning_Type)) {
                // Print Warning-Type IE
                OSS_SBCAP_Warning_Type ie_value =
                    (OSS_SBCAP_Warning_Type)value;
                System.out.printf("value %s: %s\n",  "Warning-Type", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Warning_Security_Information)) {
                // Print Warning-Security-Information IE
                OSS_SBCAP_Warning_Security_Information ie_value =
                    (OSS_SBCAP_Warning_Security_Information)value;
                System.out.printf("value %s: %s\n",  "Warning-Security-Information", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Data_Coding_Scheme)) {
                // Print Data-Coding-Scheme IE
                OSS_SBCAP_Data_Coding_Scheme ie_value =
                    (OSS_SBCAP_Data_Coding_Scheme)value;
                System.out.printf("value %s: %s\n",  "Data-Coding-Scheme", 
                    toBstring(ie_value));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Warning_Message_Content)) {
                // Print Warning-Message-Content IE
                OSS_SBCAP_Warning_Message_Content ie_value =
                    (OSS_SBCAP_Warning_Message_Content)value;
                System.out.printf("value %s: %s\n",  "Warning-Message-Content", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Omc_Id)) {
                // Print Omc-Id IE
                OSS_SBCAP_Omc_Id ie_value =
                    (OSS_SBCAP_Omc_Id)value;
                System.out.printf("value %s: %s\n",  "Omc-Id", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Concurrent_Warning_Message_Indicator)) {
                // Print Concurrent-Warning-Message-Indicator IE
                OSS_SBCAP_Concurrent_Warning_Message_Indicator ie_value =
                    (OSS_SBCAP_Concurrent_Warning_Message_Indicator)value;
                System.out.printf("value %s: %s\n",  "Concurrent-Warning-Message-Indicator\"", ie_value.name());
            } else {
                // Print other IEs via toString()
                if (value != null) {
                    System.out.print(value);
                } else {
                    System.out.println("The IE was left undecoded");
                }
            }
        }
    }

    /*
     * Prints the WriteReplaceWarningReq message.  
     */
    static void printWriteReplaceWarningReqMsg(OSS_SBCAP_Write_Replace_Warning_Request req) 
    {
        OSS_SBCAP_ProtocolIE_Container ies = req.getProtocolIEs();
        if (ies.getSize() == 0) {
            System.out.println("The message does not include any IEs");
            return;
        }
        printProtocolIEs(ies);
    }

    /*
     * Creates SBCAP successful outcome
     * message for the given WriteReplace Warning Request.    
     */
    static OSS_SBCAP_SBC_AP_PDU createSuccessResponse(OSS_SBCAP_Write_Replace_Warning_Request req) 
    {
        System.out.println("Creating response...");
        // Find and copy Message_Identifier and Serial_Number IEs from input to output
        OSS_SBCAP_Message_Identifier message_identifier = null;
        OSS_SBCAP_Serial_Number serial_number = null;
        OSS_SBCAP_ProtocolIE_Container req_ies = req.getProtocolIEs();
        for (int i=0; i<req_ies.getSize(); i++) {
            OSS_SBCAP_ProtocolIE_Field field = req_ies.get(i);
            OSS_SBCAP_ProtocolIE_ID field_id = field.getId();
            if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Message_Identifier)) {
                message_identifier = (OSS_SBCAP_Message_Identifier)field.getValue().getDecodedValue();
            } else if (field_id.equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Serial_Number)) {
                serial_number = (OSS_SBCAP_Serial_Number)field.getValue().getDecodedValue();
            }
        }
        
        if (message_identifier == null || serial_number == null) {
            System.out.println("Unexpected Write-Replace-Warning-Request data");
            return null;
        }
        
        OSS_SBCAP_ProtocolIE_Container resp_ies = 
            new OSS_SBCAP_ProtocolIE_Container();
        // Add Message_Identifier
        OSS_SBCAP_ProtocolIE_Field field = new OSS_SBCAP_ProtocolIE_Field(
            new OSS_SBCAP_ProtocolIE_ID(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Message_Identifier.intValue()), 
            OSS_SBCAP_Criticality.reject, 
            new OpenType(message_identifier));
        resp_ies.add(field);
        // Add Serial Number
        field = new OSS_SBCAP_ProtocolIE_Field(
            new OSS_SBCAP_ProtocolIE_ID(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Serial_Number.intValue()), 
            OSS_SBCAP_Criticality.reject, 
            new OpenType(serial_number));
        resp_ies.add(field);
        // Add Cause IE to outcome message
        field = new OSS_SBCAP_ProtocolIE_Field(
            new OSS_SBCAP_ProtocolIE_ID(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Cause.intValue()), 
            OSS_SBCAP_Criticality.ignore, 
            new OpenType(OSS_SBCAP_Cause.OSS_SBCAP_message_accepted));
        resp_ies.add(field);
        OSS_SBCAP_Write_Replace_Warning_Response resp = 
            new OSS_SBCAP_Write_Replace_Warning_Response(resp_ies);
        // Construct the SuccessfulOutcome message
        OSS_SBCAP_SuccessfulOutcome successfulOutcome = 
            new OSS_SBCAP_SuccessfulOutcome(
                new OSS_SBCAP_ProcedureCode(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Write_Replace_Warning.intValue()), 
                OSS_SBCAP_Criticality.reject, 
                new OpenType(resp));
        // Construct and return the top-level PDU
        return OSS_SBCAP_SBC_AP_PDU.createOSS_SBCAP_SBC_AP_PDUWithSuccessfulOutcome(successfulOutcome);
    }

    /*
     * Demonstrates processing of the sample SBCAP message.
     * The input serialized pdu is deserialized and printed, then an outcome 
     * message is created, printed and encoded.
     */
    static void test_SBCAP_Message(String filename) throws IOException, Exception
    {
        OSS_SBCAP_SBC_AP_PDU incoming;

 	File file = new File(filename);
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	System.out.println("Read encoding from file: " + filename + "\n");
	System.out.println("Decoding the input SBCAP message...");
	System.out.println(border);
	/* Deserialize input message */
        incoming = (OSS_SBCAP_SBC_AP_PDU)coder.decode(
    			    source, new OSS_SBCAP_SBC_AP_PDU());
	source.close();
	System.out.println("\nPDU decoded");
        
	if (!incoming.hasInitiatingMessage()) {
	    throw new Exception("Incorrect message: expecting InitiatingMessage");
	}

        OSS_SBCAP_InitiatingMessage msg = 
            (OSS_SBCAP_InitiatingMessage)incoming.getChosenValue();
        if (!msg.getProcedureCode().equalTo(OSS_SBCAP_SBC_AP_Constants.OSS_SBCAP_id_Write_Replace_Warning)) {
            System.out.println("Unexpected message");
            return;
        }
        OSS_SBCAP_Write_Replace_Warning_Request req =
            (OSS_SBCAP_Write_Replace_Warning_Request)msg.getValue().getDecodedValue();
        printWriteReplaceWarningReqMsg(req);
        OSS_SBCAP_SBC_AP_PDU outgoing =
            createSuccessResponse(req);
        if (outgoing != null) {
            System.out.println("Response created successfully");
            System.out.println("The Response message");
            System.out.println(border);
            System.out.println(outgoing);
            System.out.println("Serializing response...");
            System.out.println(border);
            ByteArrayOutputStream sink = new ByteArrayOutputStream();
            coder.encode(outgoing, sink);
            sink.close();
            byte[] encoded = sink.toByteArray();
            System.out.printf("Serialized response (%d bytes):\n",
                encoded.length);
            System.out.println(border);
            System.out.println(HexTool.getHex(encoded));
        }
    }
    
    /*
     * Formats the value of BIT STRING as binary string
     */
    static String toBstring(BitString bitString)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        for (int i=0; i<bitString.getSize(); i++)
            buffer.append(bitString.getBit(i) ? '1' : '0');
        buffer.append("'B");
        
        return buffer.toString();
    }

    /*
     * Formats the value of byte[] as hex string
     */
    static String toHstring(byte[] bytes)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        buffer.append(HexTool.getHex(bytes, 0));
        buffer.append("'H");
        
        return buffer.toString();
    }
}
