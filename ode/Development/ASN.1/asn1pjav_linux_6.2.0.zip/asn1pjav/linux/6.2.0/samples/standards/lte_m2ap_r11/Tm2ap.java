/*****************************************************************************/
/* Copyright (C) 2015 OSS Nokalva, Inc.  All rights reserved.	          */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Tm2ap.java	17.1  14/06/01
 */

/*
 * Demonstrates work with data for M2AP protocol of LTE.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.*;
import m2ap.*;
import m2ap.oss_m2ap_m2ap_commondatatypes.*;
import m2ap.oss_m2ap_m2ap_constants.*;
import m2ap.oss_m2ap_m2ap_containers.*;
import m2ap.oss_m2ap_m2ap_ies.*;
import m2ap.oss_m2ap_m2ap_pdu_contents.*;
import m2ap.oss_m2ap_m2ap_pdu_descriptions.*;

public class Tm2ap {

    static Coder coder;
    static String border = "-------------------------------------------------------";

    /*
     * Decodes and prints the input messages; creates, encodes and prints 
     * the output (response) messages.
     */
    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    M2ap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = M2ap.getPERAlignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	try {
	    test_M2AP_Message("M2AP-PDU_MBMSSessionStartRequest_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	}

	try {
	    test_M2AP_Message("M2AP-PDU_MCEConfigurationUpdate_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * Prints ProtocolIE_Container data.
     * This method handles only some IEs that can be present in a MBMS Session
     * Start Request message.
     */
    static void printSessionStartRequestProtocolIEs(OSS_M2AP_ProtocolIE_Container protocolIEs) 
    {
        System.out.printf("%s includes the following protocol IEs:\n", 
            "Session Start Request message");
        for (int i=0; i<protocolIEs.getSize(); i++) {
            OSS_M2AP_ProtocolIE_Field field = protocolIEs.get(i);
            OSS_M2AP_ProtocolIE_ID field_id = field.getId();
            System.out.printf("IE#%d: id = %2d, criticality = %s\n", i+1, 
                field_id.intValue(), field.getCriticality().name());
            AbstractData value = field.getValue().getDecodedValue();
            if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MCE_MBMS_M2AP_ID)) {
                // Print MCE-MBMS-M2AP-ID IE
                int ie_value = ((OSS_M2AP_MCE_MBMS_M2AP_ID)value).intValue();
                System.out.printf("value %s: %d\n",  "MCE-MBMS-M2AP-ID", ie_value);
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_TMGI)) {
                // Print TMGI IE
                OSS_M2AP_TMGI ie_value = (OSS_M2AP_TMGI)value;
                System.out.printf("value %s: \n",  "TMGI fields");
                System.out.printf("%s: %s\n",  "PLMN-Identity", 
                    toHstring(ie_value.getPLMNidentity().byteArrayValue()));
                System.out.printf("%s: %s\n",  "Service-ID", 
                    toHstring(ie_value.getServiceID().byteArrayValue()));
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MBMS_Session_ID)) {
                // Print MBMS-Session-ID IE
                OSS_M2AP_MBMS_Session_ID ie_value = (OSS_M2AP_MBMS_Session_ID)value;
                System.out.printf("value %s: %s\n",  "MBMS-Session-ID", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MBMS_Service_Area)) {
                // Print MBMS-Service-Area IE
                OSS_M2AP_MBMS_Service_Area ie_value = (OSS_M2AP_MBMS_Service_Area)value;
                System.out.printf("value %s: %s\n",  "MBMS-Service-Area", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_TNL_Information)) {
                // Print TNL-Information IE
                OSS_M2AP_TNL_Information ie_value = (OSS_M2AP_TNL_Information)value;
                System.out.printf("value %s: \n",  "TNL-Information fields");
                System.out.printf("%s: %s\n",  "IPMC-Address", 
                    toHstring(ie_value.getIPMCAddress().byteArrayValue()));
                System.out.printf("%s: %s\n",  "IP-Source-Address", 
                    ByteTool.toIPAddress(ie_value.getIPSourceAddress().byteArrayValue()));
                System.out.printf("%s: %s\n",  "GTP-TEID", 
                    toHstring(ie_value.getGTP_TEID().byteArrayValue()));
            } else {
                // Print other IEs via toString()
                if (value != null) {
                    System.out.print(value);
                } else {
                    System.out.println("The IE was left undecoded");
                }
            }
        }
    }

    /*
     * Creates an OSS_M2AP_SessionStartResponse PDU for a given
     * OSS_M2AP_SessionStartRequest PDU.
     */
    static OSS_M2AP_M2AP_PDU createSessionStartResponse(OSS_M2AP_SessionStartRequest req) 
    {
        System.out.printf("\nCreating Session Start Response...\n");
        OSS_M2AP_ProtocolIE_Container request_IEs = req.getProtocolIEs();
        
        if (request_IEs == null || request_IEs.getSize() == 0) {
            System.out.println("No IEs in Session Start Request");
            return null;
        }
        /* 
         * Find the MCE-MBMS-M2AP-ID IE which uniquely identifies the MBMS 
         * service association 
         */
        OSS_M2AP_MCE_MBMS_M2AP_ID srcv_assoc_ID = null;
        for (int i=0; i<request_IEs.getSize(); i++) {
            OSS_M2AP_ProtocolIE_Field field = request_IEs.get(i);
            if (field.getId().equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MCE_MBMS_M2AP_ID)) {
                srcv_assoc_ID = (OSS_M2AP_MCE_MBMS_M2AP_ID)field.getValue().getDecodedValue();
                break;
            }
        }
        if (srcv_assoc_ID == null) {
            System.out.println("Unexpected Session Start Request data");
            return null;
        }
        
        // Create the protocol container
        OSS_M2AP_ProtocolIE_Container response_IEs = new OSS_M2AP_ProtocolIE_Container();
        // Add the MCE-MBMS-M2AP-ID IE
        OSS_M2AP_ProtocolIE_Field field = new OSS_M2AP_ProtocolIE_Field(
            OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MCE_MBMS_M2AP_ID, 
            OSS_M2AP_Criticality.ignore, 
            new OpenType(srcv_assoc_ID));
        response_IEs.add(field);
        // Add ENB-MBMS-M2AP-ID IE
        field = new OSS_M2AP_ProtocolIE_Field(
            OSS_M2AP_M2AP_Constants.OSS_M2AP_id_ENB_MBMS_M2AP_ID, 
            OSS_M2AP_Criticality.ignore, 
            new OpenType(new OSS_M2AP_ENB_MBMS_M2AP_ID(6600)));
        response_IEs.add(field);
        // Construct the SessionStartResponse message
        OSS_M2AP_SessionStartResponse resp =
            new OSS_M2AP_SessionStartResponse(response_IEs);
        // Construct the SuccessfulOutcome message
        OSS_M2AP_SuccessfulOutcome successfulOutcome = 
            new OSS_M2AP_SuccessfulOutcome(
                OSS_M2AP_M2AP_Constants.OSS_M2AP_id_sessionStart, 
                OSS_M2AP_Criticality.reject, 
                new OpenType(resp));
        // Construct and return the top-level PDU
        return OSS_M2AP_M2AP_PDU.createOSS_M2AP_M2AP_PDUWithSuccessfulOutcome(successfulOutcome);
    }

    /*
     * Prints ProtocolIE_Container data.
     * This function handles only some IEs that can be present in a MCE
     * Configuration Update message.
     */
    static void printMCEConfigUpdateProtocolIEs(OSS_M2AP_ProtocolIE_Container protocolIEs) {
        System.out.printf("%s includes the following protocol IEs:\n", 
            "MCE Configuration Update message");
        for (int i=0; i<protocolIEs.getSize(); i++) {
            OSS_M2AP_ProtocolIE_Field field = protocolIEs.get(i);
            OSS_M2AP_ProtocolIE_ID field_id = field.getId();
            System.out.printf("IE#%d: id = %2d, criticality = %s\n", i+1, 
                field_id.intValue(), field.getCriticality().name());
            AbstractData value = field.getValue().getDecodedValue();
            if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_GlobalMCE_ID)) {
                // Print GlobalMCE-ID IE
                OSS_M2AP_GlobalMCE_ID ie_value = (OSS_M2AP_GlobalMCE_ID)value;
                System.out.printf("value %s: \n",  "GlobalMCE-ID fields");
                System.out.printf("%s: %s\n",  "PLMN-Identity", 
                    toHstring(ie_value.getPLMN_Identity().byteArrayValue()));
                System.out.printf("%s: %s\n",  "MCE-ID", 
                    toHstring(ie_value.getMCE_ID().byteArrayValue()));
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MCEname)) {
                // Print MCE-Name IE
                System.out.printf("value %s: %s\n",  "MCE-Name",
                    ((OSS_M2AP_MCEname)value).stringValue());
            } else if (field_id.equalTo(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_MCCHrelatedBCCH_ConfigPerMBSFNArea)) {
                // Print MCCHrelatedBCCH-ConfigPerMBSFNArea IE
                OSS_M2AP_MCCHrelatedBCCH_ConfigPerMBSFNArea data =
                    (OSS_M2AP_MCCHrelatedBCCH_ConfigPerMBSFNArea)value;
                System.out.println("List of  MCCH related BCCH config data items:");
                for (int k=0; k<data.getSize(); k++)
                    printBCCHConfigItem(data.get(k));
            } else {
                // Print other IEs via toString()
                if (value != null) {
                    System.out.print(value);
                } else {
                    System.out.println("The IE was left undecoded");
                }
            }
        }
    }

    /*
     * Creates an OSS_M2AP_MCEConfigurationUpdateAcknowledge PDU for a given
     * OSS_M2AP_MCEConfigurationUpdate PDU.
     */
    static OSS_M2AP_M2AP_PDU createConfigUpdateAcknowledge(OSS_M2AP_MCEConfigurationUpdate req) 
    {
        System.out.println("\nCreating Configuration Update Acknowledge...");
        
        // Create the MCEConfigurationUpdateAcknowledge message with empty
        // protocol IEs list
        OSS_M2AP_MCEConfigurationUpdateAcknowledge ack = 
            new OSS_M2AP_MCEConfigurationUpdateAcknowledge(
                new OSS_M2AP_ProtocolIE_Container());
        // Create the SuccessfulOutcome message
        OSS_M2AP_SuccessfulOutcome successfulOutcome = 
            new OSS_M2AP_SuccessfulOutcome(
                OSS_M2AP_M2AP_Constants.OSS_M2AP_id_mCEConfigurationUpdate, 
                OSS_M2AP_Criticality.reject, 
                new OpenType(ack));
        // Create and return the top-level PDU
        return OSS_M2AP_M2AP_PDU.createOSS_M2AP_M2AP_PDUWithSuccessfulOutcome(successfulOutcome);
    }

    /*
     * Prints the OSS_M2AP_MCCHrelatedBCCH_ConfigPerMBSFNArea_Item data.    
     */
    static void printBCCHConfigItem(OSS_M2AP_ProtocolIE_Field ie) 
    {
        OSS_M2AP_MCCHrelatedBCCH_ConfigPerMBSFNArea_Item item =
            (OSS_M2AP_MCCHrelatedBCCH_ConfigPerMBSFNArea_Item)ie.getValue().getDecodedValue();
        // Print MBSFN-Area-ID field
        System.out.printf("%s: %d\n", "MBSFN-Area-ID", item.getMbsfnArea().intValue());
        // Print PDCCH-Length field
        System.out.printf("%s: %s\n", "PDCCH-Length", item.getPdcchLength().name());
        // Print  Offset field
        System.out.printf("%s: %d\n", "Offset", item.getOffset());
        // Print Modification-Period field
        System.out.printf("%s: %s\n", "Modification-Period", item.getModificationPeriod().name());
        // Print Subframe-Allocation-Info field
        System.out.printf("%s: %s\n", "Subframe-Allocation-Info", 
            toBstring(item.getSubframeAllocationInfo()));
        // Print Modulation-And-Coding-Scheme
        System.out.printf("%s: %s\n", "Modulation-And-Coding-Scheme", 
            item.getModulationAndCodingScheme().name());
        // Print CellInformationList if available
        if (item.hasCellInformationList()) {
            OSS_M2AP_Cell_Information_List list = item.getCellInformationList();
            System.out.println("Cell-Information-List items:");
            for (int i=0; i<list.getSize(); i++) {
                OSS_M2AP_Cell_Information entry = list.get(i);
                System.out.printf("ITEM#%d Cell-Info:\n", i+1);
                System.out.println("E-UTRAN CGI fields:");
                OSS_M2AP_ECGI ecgi = entry.getECGI();
                // Print PLMN-Identity field
                System.out.printf("%s: %s\n", "PLMN-Identity",
                    toHstring(ecgi.getPLMN_Identity().byteArrayValue()));
                // Print Cell-Identity field
                System.out.printf("%s: %s\n", "Cell-Identity",
                    toBstring(ecgi.getEUTRANcellIdentifier()));
                // Print Cell-Reservation-Info
                System.out.printf("%s: %s\n", "Cell-Reservation-Info",
                   entry.getCellReservationInfo().name());
                // Print IE-Extension if present
                if (entry.hasIE_Extensions()) {
                    OSS_M2AP_ProtocolExtensionContainer ie_extensions = 
                        entry.getIE_Extensions();
                    System.out.printf("%s includes the following IEs", "IE-Extensions");
                    for (int k=0; k<ie_extensions.getSize(); k++) {
                        OSS_M2AP_ProtocolExtensionField ext = ie_extensions.get(k);
                        System.out.printf("EXTENSION#%d: id = %d, criticality = %s\n",
                            i+1, ext.getId().intValue(), ext.getCriticality().name());
                        AbstractData value = ext.getExtensionValue().getDecodedValue();
                        if (value != null) {
                            System.out.print(value);
                        } else {
                            System.out.println("The EXTENSION was left undecoded: ");
                            System.out.println(HexTool.getHex(ext.getExtensionValue().getEncodedValue()));
                        }
                    }
                }
            }
        }
    }
    
    /*
     * M2AP elementary procedure codes
     */
    public static enum ProcedureID {
        SessionStart(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_sessionStart),
        SessionStop (OSS_M2AP_M2AP_Constants.OSS_M2AP_id_sessionStop),
        SessionUpdate(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_sessionUpdate),
        MbmsSchedulingInformation(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_mbmsSchedulingInformation),
        Reset(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_reset),
        M2Setup(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_m2Setup),
        ENBConfigurationUpdate(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_eNBConfigurationUpdate),
        MCEConfigurationUpdate(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_mCEConfigurationUpdate),
        MbmsServiceCounting(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_mbmsServiceCounting),
        MbmsServiceCountingResultsReport(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_mbmsServiceCountingResultsReport),
        ErrorIndication(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_errorIndication),
        PrivateMessage(OSS_M2AP_M2AP_Constants.OSS_M2AP_id_privateMessage),
        Unknown(null);
        
        private int id;
        private ProcedureID(OSS_M2AP_ProcedureCode id)
        {
            if (id != null)
                this.id = id.intValue();
        }
        
        public static ProcedureID valueOf(OSS_M2AP_ProcedureCode id)
        {
            int code = id.intValue();
            ProcedureID[] enums = values();
            int unknown = enums.length-1;
            for (int i=0; i<unknown; i++) {
                if (code == enums[i].id)
                    return enums[i];
            }
            
            return enums[unknown];
        }
    }

    /*
     * Represents an incomplete implementation
     * of an eNB-side function processing of an M2AP message. It decodes the
     * message, prints it, and creates a response for some particular
     * alternatives. The function can be used to implement a complete
     * LTE M2AP eNB-side dispatcher.
     */

    static void test_M2AP_Message(String filename) throws IOException, Exception
    {
        OSS_M2AP_M2AP_PDU incoming;

 	File file = new File(filename);
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	System.out.println("Read encoding from file: " + filename + "\n");
	System.out.println("Decoding the input M2AP message...");
	System.out.println(border);
	/* Deserialize input message */
        incoming = (OSS_M2AP_M2AP_PDU)coder.decode(
    			    source, new OSS_M2AP_M2AP_PDU());
	source.close();
	System.out.println("\nPDU decoded");

	if (!incoming.hasInitiatingMessage()) {
	    throw new Exception("Incorrect message: expecting InitiatingMessage");
	}
        
        OSS_M2AP_InitiatingMessage msg = 
            (OSS_M2AP_InitiatingMessage)incoming.getChosenValue();
        
        ProcedureID code = ProcedureID.valueOf(msg.getProcedureCode());
        switch (code) {
            /* You can take unimplemented alternatives one by
             * one and add support for them */
            case SessionStart:
            {
                OSS_M2AP_SessionStartRequest req = 
                    (OSS_M2AP_SessionStartRequest)msg.getValue().getDecodedValue();
                printSessionStartRequestProtocolIEs(req.getProtocolIEs());
                OSS_M2AP_M2AP_PDU resp = 
                    createSessionStartResponse(req);
                if (resp != null) {
                    System.out.println("Response created successfully");
                    System.out.println("The Session Start Response message");
                    System.out.println(border);
                    System.out.println(resp);
                    System.out.println("Serializing response...");
                    System.out.println(border);
                    ByteArrayOutputStream sink = new ByteArrayOutputStream();
                    coder.encode(resp, sink);
                    sink.close();
                    byte[] encoded = sink.toByteArray();
                    System.out.printf("Serialized response (%d bytes):\n",
                        encoded.length);
                    System.out.println(border);
                    System.out.println(HexTool.getHex(encoded));
                }
                break;
            }
            case MCEConfigurationUpdate:
            {
                OSS_M2AP_MCEConfigurationUpdate req = 
                    (OSS_M2AP_MCEConfigurationUpdate)msg.getValue().getDecodedValue();
                printMCEConfigUpdateProtocolIEs(req.getProtocolIEs());
                OSS_M2AP_M2AP_PDU resp = 
                    createConfigUpdateAcknowledge(req);
                if (resp != null) {
                    System.out.println("Acknowledge created successfully");
                    System.out.println("The Configuration Update Acknowledge message");
                    System.out.println(border);
                    System.out.println(resp);
                    System.out.println("Serializing response...");
                    System.out.println(border);
                    ByteArrayOutputStream sink = new ByteArrayOutputStream();
                    coder.encode(resp, sink);
                    sink.close();
                    byte[] encoded = sink.toByteArray();
                    System.out.printf("Serialized response (%d bytes):\n",
                        encoded.length);
                    System.out.println(border);
                    System.out.println(HexTool.getHex(encoded));
                }
                break;
            }
            case SessionStop:
            case SessionUpdate:
            case ENBConfigurationUpdate:
            case ErrorIndication:
            case M2Setup:
            case MbmsSchedulingInformation:
            case MbmsServiceCounting:
            case MbmsServiceCountingResultsReport:
            case PrivateMessage:
            case Reset:
                System.out.printf("%s - Unimplemented \n", code.name());
                break;
            case Unknown:
                System.out.printf("Unexpected PDU type \n");
                break;
        }
    }
    
    /*
     * Formats the value of BIT STRING as binary string
     */
    static String toBstring(BitString bitString)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        for (int i=0; i<bitString.getSize(); i++)
            buffer.append(bitString.getBit(i) ? '1' : '0');
        buffer.append("'B");
        
        return buffer.toString();
    }

    /*
     * Formats the value of byte[] as hex string
     */
    static String toHstring(byte[] bytes)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        buffer.append(HexTool.getHex(bytes, 0));
        buffer.append("'H");
        
        return buffer.toString();
    }
}
