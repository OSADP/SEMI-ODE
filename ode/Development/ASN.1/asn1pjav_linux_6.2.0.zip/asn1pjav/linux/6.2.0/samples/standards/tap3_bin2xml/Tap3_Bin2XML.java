/*
 * Copyright (C) 2015 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/* FILE: @(#)Tap3_Bin2XML.java	17.1 15/09/07 */
/* Prepared by OSS Nokalva, Inc.  */

/**
    Application program Tap3_Bin2XML.java
    Demonstrates BER-->XML (XER) conversion.
*/

/* To run the program:

asn1pjav TAP-0310.asn -ber -xer
cd tap_0310
tap_0310.bat javac
cd ..
javac -g Tap3_Bin2XML.java
java Tap3_Bin2XML

If you experience difficulties running or compiling this program, carefully read
through the Installing section of the quickstart.html guide in the doc/guide
directory of your shipment. If that doesn't help contact support@oss.com. Be
sure to submit your license number, as well as a description of the problem.
*/

/* main() shows how to convert BER-->XML */

/* Compiler-generated classes */
import tap_0310.*;
import tap_0310.tap_0310.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Tap3_Bin2XML {

    /**
     * Constructor.
     */
    public Tap3_Bin2XML () {
    }

    public static void main(String args[]) {

	// Parse the command line options.
	if (args.length != 2) {
	    System.out.println("Usage: java Tap3_Bin2XML <src>.bin <dest>.xml\n");
	    System.exit(1);
	}

	// Initialize the project
	try {
	    tap_0310.Tap_0310.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Initialize Binary2XMLConvertor to perform BER-->XML (XER)
	Binary2XMLConvertor convertor = new Binary2XMLConvertor(
	    tap_0310.Tap_0310.getBERCoder(),
	    tap_0310.Tap_0310.getXERCoder()
	);

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    convertor.disableDecoderConstraints();
	    convertor.disableEncoderConstraints();
	    convertor.enableRelaxedDecoding();
	}

	System.out.println("Printing the original BER-encoded message...\n");
	printFile(args[0], true);

	System.out.println("\nEncoding using XML (XER)...\n");
	try {
	    FileInputStream source = new FileInputStream(args[0]);
	    FileOutputStream sink  = new FileOutputStream(args[1]);

	    convertor.convert(source, sink, new DataInterChange());
	    source.close();
	    sink.close();

	} catch (IOException e) {
	    System.out.println("IO exception: " + e);
	    System.exit(3);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	    System.exit(4);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoder exception: " + e);
	    System.exit(4);
	}
	System.out.println("Converted successfully.");
	System.out.println("\nPrinting the XML encoded message...\n");
	printFile(args[1], false);
    }

    // Prints file contents to System.out
    static void printFile(String fname, boolean hex) {
	File file = new File(fname);

	int length = (int)file.length();
	byte[] buf = new byte[length];

	try {
	    FileInputStream source = new FileInputStream(file);

	    for (int i = 0; i < length; i++)
		buf[i] = (byte)source.read();
	    source.close();
	} catch (IOException e) {
	    System.out.println("IO exception: " + e);
	    System.exit(2);
	}

	if (hex)
	    HexTool.printHex(buf);
	else {
	    System.out.write(buf, 0, length);
	    System.out.println("");
	}
    }
}
