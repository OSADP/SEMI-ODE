/*
 * Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)ExeSigner.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program ExeSigner.java
    Demonstrates OSS ASN.1/Java Tools API for handling huge
    values which reside in disk files.
*/

/* To run the program:

      asn1pjav -der signed.asn
      javac ExeSigner.java
      cd signed
      sh signed.sh (or signed.bat javac)
   cd ..
   java ExeSigner -v send <file to sign> john jabberwock
or
   java ExeSigner -v receive <signed file to verify>

If you experience difficulties running or compiling this program, carefully
read through the Installing section of the quickstart.html guide in the
doc/guide directory of your shipment. If that doesn't help contact
support@oss.com. Be sure to submit your license number, as well as a
description of the problem.
*/

/* main() shows how to make use of the ValueInFile directive. 
      The example implements a simple utility for secure exchange 
      of executable files. The sender takes an executable file, signs 
      it and sends it to the recipient. The recipient verifies the electronic 
      signature and if the signature matches the contents, s/he saves the 
      enclosed executable code for future use. For a more detailed 
      explanation, see vif.htm in the doc/guide directory of your shipment.
*/

import com.oss.storage.*;
import com.oss.asn1.*;
import java.io.*;
import java.security.*;
import java.security.cert.*;
import signed.*;
import signed.signedexe.*;

public class ExeSigner {
    // Exit codes
    public final static int SUCCESS = 0;
    public final static int INIT_FAILED = -1;
    public final static int FEW_ARGS = 1;
    public final static int FEW_SEND_ARGS = 2;
    public final static int FEW_RECV_ARGS = 3;
    public final static int BAD_COMMAND = 4;
    public final static int SIGNING_FAILED = 6;
    public final static int EXTRACTION_FAILED = 7;
    // Enables verbose operation
    static boolean verbose = false;
    // Main executes the command, specified
    // in the command line.
    public static void main(String[] args)
    {
        int arg_count = args.length;
	int arg = 0;
	int rc = SUCCESS;
	try {
	    Signed.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization failed: " + e);
	    System.exit(INIT_FAILED);
	}
        if (arg_count < 1)
	    rc = FEW_ARGS;
        else {
	    rc = BAD_COMMAND;
	    while (arg_count > 0) {
		if (args[arg].equals("-v")) {
		    verbose = true;
		    ++arg;
		    --arg_count;
		} else if (args[arg].equals("send")) {
        	    if (arg_count < 4)
			rc = FEW_SEND_ARGS;
		    else
            		// Sign the executable. The command-line
            		// parameters specify:
            		// args[1] - the name of the executable to sign.
            		// args[2] - the name of the signer. The signer
            		//           should have a private key defined in
            		//           local key store.
            		// args[3] - the password to get the private key
            		//           from the key store.
            		rc = send(args[arg+1], args[arg+2], args[arg+3]);
		    break;
    		} else if (args[arg].equals("receive")) {
        	    if (arg_count < 2)
			rc = FEW_RECV_ARGS;
        	    else
            		// Verify the file received. The command-line
            		// parameters specify:
            		// args[1] - the name of the file, that contains
            		//           DER encoded SignedExecutable message.
            		rc = receive(args[arg+1]);
		    break;
    		} else {
        	    System.out.println("Unrecognized command: " + args[arg]);
		    rc = BAD_COMMAND;
		    break;
		}
	    }
        }
	Signed.deinitialize();
	if (rc > SUCCESS && rc < SIGNING_FAILED)
	    usage();
	if (verbose)
	    System.out.println("The utility ran to completion. Result code = "
		+ rc + ".");
	System.exit(rc);
    }
    // Print informatory message, that explains the syntax of the
    // command-line
    public static void usage()
    {
	System.out.println("Usage:");
	System.out.println("  java ExeSigner [-v] send <filename> <signer's name> <key password>");
	System.out.println("or");
	System.out.println("  java ExeSigner [-v] receive <filename>");
    }
    // Create an instance of SignedExecutable, sign its 'data' field,
    // and save the resut DER encoding of the SignedExecutable to a
    // disk file.
    public static int send(String fileName, String signer, String password)
    {
        SignedExecutable signedExecutable = null;
        try {
	    if (verbose)
		System.out.println(
    "***** Phase 1. Generating the SignedExecutable message ...");
            // 1. Create an instance of SignedExecutable. Note that
            // the constructor for the 'code' field uses the
            // OSSByteStorage(File) to associate the ByteStorage
            // object with the existing disk file.
            // Strip any directories from the 'filename'
            String exeName = new File(fileName).getName();
            signedExecutable = new SignedExecutable(
                    new OctetString(),        // encryptedDigest
                    new UTF8String16(signer), // signer's name
                    new UTF8String16("DSA"),  // digest algorithm
                    new Executable(           // data field
                        new UTF8String16(         // executable name 
                            exeName
                        ),
                        new HugeOctetString(      // executable code
                            new OSSByteStorage(new File(fileName))
                        )
		    )
            );
            // 2. Generate DER encoding of the 'data' component
            Coder coder = Signed.getDERCoder();
	    if (verbose) {
		System.out.println(
    "***** Phase 2. Generating DER encoding of 'data' ...");
		coder.enableEncoderDebugging();
	    }
            signedExecutable.encodeData(coder);
	    if (verbose)
		System.out.println(
    "***** Phase 3. Getting signer's private key and initializing the Signer ...");
            // 3. Get an instance of Signature object to compute the
            // encrypted digest for the 'data'
            KeyStore ks = KeyStore.getInstance("JKS");
            char[] c = password.toCharArray();
            // load .keystore
            ks.load(new FileInputStream(".keystore"), null);
            // read the Private key
            PrivateKey privateKey = (PrivateKey) ks.getKey(signer, c);
	      Signature signature = Signature.getInstance("DSA");
	      signature.initSign(privateKey);
    	    if (verbose)
		System.out.println(
    "***** Phase 3a. Computing the digest ...");
	    // Compute the encrypted digest for the 'data' field
            ByteStorage dataToSign = 
               signedExecutable.getEncodedData();
            // Allocate internal buffer to read octets from the
            // ByteStorage
            int blockSize = 1024;
            byte[] buffer = new byte[blockSize];
            InputStream reader = dataToSign.getReader();
            try {
                int len = -1;
		int octets = 0;
                // Read octets from the ByteStorage and compute
                // the encrypted digest.
                while ((len = reader.read(buffer)) != -1) {
		    octets += len;
                    signature.update(buffer, 0, len);
                }
		if (verbose)
		    System.out.println(octets + " octets(s) processed.");
            } finally {
                reader.close();
            }
            // Get the encrypted digest computed
            byte[] digest = signature.sign();
	    if (verbose)
		System.out.println(
    "***** Phase 4. Adding the digest to SignedExecutable message ...");
            // 4. Assign the digest computed to the 'encryptedDigest' 
            // component
            signedExecutable.getEncryptedDigest().setValue(digest);
	    if (verbose)
		System.out.println(
    "***** Phase 5. Writing DER-encoded message to the file ...");
            // 5. Create DER encoding of the SignedExecutable and save it
            // into a disk file
            File derEncoding = new File(fileName + ".der");
            FileOutputStream sink = new FileOutputStream(derEncoding);
            try {
                coder.encode(signedExecutable, sink);
                sink.close();
            } catch (Exception e) {
                // Delete file, created to store DER encoding
                derEncoding.delete();
                throw e;
            }
        } catch (Exception e) {
            System.out.println("Signing the executable failed: " + e);
            return SIGNING_FAILED;
        } finally {
            // Destroy the instance of SignedExecutable before exit.
            if (signedExecutable != null)
                signedExecutable.delete();
        }
	
	return SUCCESS;
    }
    // Verify received executable and if the signature is valid, save the
    // executable code into a disk file.
    public static int receive(String fileName)
    {
        SignedExecutable signedExecutable = null;
        try {
            // 1. Decode DER encoded SignedExecutable from the input file
            FileInputStream source = new FileInputStream(fileName);
            Coder coder = Signed.getDERCoder();

	    // enable relaxed decoding mode if needed
	    String relax = System.getProperty("oss.samples.relaxedmode");
	    if (relax != null && relax.equalsIgnoreCase("on")) {
		coder.enableRelaxedDecoding();
	    }

	    if (verbose) {
		System.out.println(
    "***** Phase 1. Decoding signed executable ...");
		coder.enableDecoderDebugging();
	    }
            signedExecutable = 
                (SignedExecutable)coder.decode(source, new SignedExecutable());
	    if (verbose)
		System.out.println(
    "***** Phase 2. Getting signers's certificate and initializing the Verifier ...");
            // 2. Get the public key certificate for the signer from the key
            // storage and verify the signature for the file received.
            KeyStore ks = KeyStore.getInstance("JKS");
            // load .keystore
            ks.load(new FileInputStream(".keystore"), null);
            // read the Public key
            java.security.cert.Certificate certificate = ks.getCertificate(
                signedExecutable.getSignerID().stringValue());
            PublicKey publicKey = certificate.getPublicKey();
	    Signature signature = Signature.getInstance("DSA");
	    signature.initVerify(publicKey);
	    if (verbose)
		System.out.println(
    "***** Phase 2a. Verifying the signature ...");
            // Get DER encoded 'data' and verify the signature
            ByteStorage dataToVerify = 
                signedExecutable.getEncodedData();
            // Allocate internal buffer to read octets from the
            // ByteStorage
            int blockSize = 1024;
            byte[] buffer = new byte[blockSize];
            InputStream reader = dataToVerify.getReader();
            try {
                int len = -1;
		int octets = 0;
                // Read octets from the ByteStorage and compute
                // the encrypted digest.
                while ((len = reader.read(buffer)) != -1) {
		    octets += len;
                    signature.update(buffer, 0, len);
                }
		
		if (verbose)
		    System.out.println(octets + " octet(s) processed.");
            } finally {
                reader.close();
            }
            // Verify the signature
            byte[] messageDigest = 
                signedExecutable.getEncryptedDigest().byteArrayValue();
            if (!signature.verify(messageDigest))
                throw new SignatureException(
                    "Signature verification failed"
                );
	    if (verbose)
		System.out.println(
    "***** Phase 3. Verification suceeded. Extracting the executable code ...");
            // 3. Signature verification succeeded,
            // decode the deferred 'data' component and save the
            // executable into a disk file.
            signedExecutable.decodeData(coder);
            Executable executable = signedExecutable.getData();
	    if (verbose)
		System.out.println(
    "***** Phase 3a. Saving the executable code into a disk file ...");
            ByteStorage executableCode = 
                executable.getCode().byteStorageValue();
            File exeFile = new File(executable.getName().stringValue());
            FileOutputStream code = 
                new FileOutputStream(exeFile);
            reader = executableCode.getReader();
            try {
                int len = -1;
                // Read octets from the ByteStorage and copy
                // them into the result output file
                while ((len = reader.read(buffer)) != -1) {
                    code.write(buffer, 0, len);
                }
                code.close();
            } catch (Exception e) {
                exeFile.delete();
                throw e;
            } finally {
                reader.close();
            }
        } catch (Exception e) {
            System.out.println("Extraction of executable failed: " + e);
            return EXTRACTION_FAILED;
        } finally {
            // Destroy the instance of SignedExecutable before exit.
            if (signedExecutable != null)
                signedExecutable.delete();
        }
	
	return SUCCESS;
    }
}
