/*
 * Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)XERDemo.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program XERDemo.java
    Demonstrates OSS ASN.1/Java Tools XML Encoding Rules (XER) API using
    BCAS (Baseball Card Abstract Syntax).
*/

/* To run the program:

asn1pjav basebalx.asn -xer -test -xsl -dtd
cd basebalx
basebalx.bat javac
cd ..
javac -g XERDemo.java
java XERDemo

If you experience difficulties running or compiling this program, carefully read
through the Installing section of the quickstart.html guide in the doc/guide
directory of your shipment. If that doesn't help contact support@oss.com. Be
sure to submit your license number, as well as a description of the problem.
*/

/* main() shows how to encode and decode data using XERCoder class,   */
/*    how customise XML output using XERDocument class.               */

/* Compiler-generated classes */
import basebalx.*;
import basebalx.bcas.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class XERDemo {

    /**
     * Constructor.
     */
    public XERDemo () {
    }

    public static void main(String args[]) {

	// Initialize the project
	try {
	    Basebalx.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// We are using value myCard defined in the ASN.1 module BCAS
	System.out.println("Using 'myCard' value, defined in the BCAS module...");
	BBCard myCard = basebalx.bcas.BCAS.myCard;

	// Encode the myCard value using Basic XER
	try {
	    Coder coder = Basebalx.getXERCoder();
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();

	    // Enable trace output from the encoder and decoder
	    coder.enableEncoderDebugging();
	    coder.enableDecoderDebugging();

	    // Print the input to the encoder
	    System.out.println("\nThe input to the encoder\n");
	    System.out.println(myCard);

	    // Encode a card
	    System.out.println("\nEncoding with Basic XER coder");
	    System.out.println("The encoder's trace messages ...");
	    coder.encode(myCard, sink);

	    // Extract the encoding from the sink stream
	    byte[] encoding = sink.toByteArray();

	    // Print the encoding
	    System.out.println("\nCard encoded into " + encoding.length + " bytes.");
	    System.out.write(encoding, 0, encoding.length);

	    // enable relaxed decoding mode if needed
	    String relax = System.getProperty("oss.samples.relaxedmode");
	    if (relax != null && relax.equalsIgnoreCase("on")) {
		coder.enableRelaxedDecoding();
	    }

	    try {
		ByteArrayInputStream source = new ByteArrayInputStream(encoding);

		// Decode the card whose encoding is in the 'encoding' byte array.
		System.out.println("\n\nThe decoder's trace messages ...\n");
		BBCard decodedCard = (BBCard)coder.decode(source, new BBCard());
		System.out.println("\nCard decoded.");
		System.out.println("Output from decoder ...");
		System.out.println(decodedCard);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoder exception: " + e);
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoder exception: " + e);
	    }
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}


	// Generating XML output with XERDocument

	try {
	    XERCoder coder = Basebalx.getXERCoder();
	    XERDocument document = new XERDocument(coder, myCard);
	    System.out.println("\nGenerating XML document with XERDocument...");
	    System.out.println("Using default settings\n");
	    document.writeTo(System.out);
	    System.out.println("\n\nExcluding preamble.");
	    document.excludePreamble();
	    System.out.println("Excluding stylesheet.");
	    document.excludeStylesheet();
	    System.out.println("Setting indent width to 4.\n");
	    document.setIndentWidth(4);
	    document.writeTo(System.out);
	} catch (IOException e) {
	    System.out.println("I/O exception: " + e);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}
	System.out.println("\nAll done.");
    }
}
