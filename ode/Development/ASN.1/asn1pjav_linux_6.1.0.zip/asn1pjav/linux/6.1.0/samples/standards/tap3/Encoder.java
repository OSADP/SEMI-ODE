/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Encoder.java	16.2 14/02/08
 */

/*
 * Demonstrates TAP and RAP PDUs encoding.
 */


import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import tap3.*;
import tap3.tap_0310.*;
import tap3.rap_0102.*;

public class Encoder {

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Tap3.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Tap3.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	System.out.println("=== Encoding RAP sample message ===\n\n");

	/*
	 * Construct the PDU for encoding.
	 */
	AbstractData msg = fill_RapDataInterChange_PDU();

	System.out.println("PDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);

	System.out.println("=== Encoding TAP3 sample message ===\n\n");
	/*
	 * Construct the PDU for encoding.
	 */
	msg = fill_DataInterChange_PDU();

	System.out.println("PDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	encoding = sink.toByteArray();
	HexTool.printHex(encoding);
    }


/*
 * Helper functions to set up the PDU for encoding.
 */
    static DataInterChange  fill_DataInterChange_PDU()
    {
	DataInterChange pdu = new DataInterChange();
	TransferBatch batch = new TransferBatch();
	pdu.setTransferBatch(batch);

	BatchControlInfo info = new BatchControlInfo();
	batch.setBatchControlInfo(info);
	info.setSender(
	    new Sender(
		make_octet_string("PRYHT")
	    )
	);

	info.setRecipient(
	    new Recipient(
		make_octet_string("HKGHT")
	    )
	);

	info.setFileSequenceNumber(
	    new FileSequenceNumber(
		make_octet_string("00003")
	    )
	);

	FileCreationTimeStamp stamp = new FileCreationTimeStamp();
	info.setFileCreationTimeStamp(stamp);
	stamp.setLocalTimeStamp(
	    new LocalTimeStamp(
	       make_octet_string("20040204114448")
	    )
	);

	stamp.setUtcTimeOffset(
	    new UtcTimeOffset(
	       make_octet_string("-0400")
	    )
	);

	TransferCutOffTimeStamp tstamp = new TransferCutOffTimeStamp();
	info.setTransferCutOffTimeStamp(tstamp);
	tstamp.setLocalTimeStamp(
	    new LocalTimeStamp(
	       make_octet_string("20040204114448")
	    )
	);

	tstamp.setUtcTimeOffset(
	    new UtcTimeOffset(
	       make_octet_string("-0400")
	    )
	);

	FileAvailableTimeStamp fstamp = new FileAvailableTimeStamp();
	info.setFileAvailableTimeStamp(fstamp);

	fstamp.setLocalTimeStamp(
	    new LocalTimeStamp(
	       make_octet_string("FileAvailableTimeStamp")
	    )
	);

	fstamp.setUtcTimeOffset(
	    new UtcTimeOffset(
	       make_octet_string("-0400")
	    )
	);

	info.setSpecificationVersionNumber(
	    new SpecificationVersionNumber(3)
	);
	info.setReleaseVersionNumber(
	    new ReleaseVersionNumber(10)
	);
	info.setFileTypeIndicator(
	    new FileTypeIndicator(
		make_octet_string("T")
	    )
	);

	AccountingInfo ainfo = new AccountingInfo();
	batch.setAccountingInfo(ainfo);
	TaxationList txn = new TaxationList();
	ainfo.setTaxation(txn);
	Taxation element = new Taxation();
	txn.add(element);
	element.setTaxCode(new TaxCode(1));
	element.setTaxType(
	    new TaxType(
		make_octet_string("13")
	    )
	);
	element.setTaxRate(
	    new TaxRate(
		make_octet_string("1000000")
	    )
	);

	ainfo.setLocalCurrency(
	    new LocalCurrency(
		make_octet_string("USD")
	    )
	);

	CurrencyConversionList cclist = new CurrencyConversionList();
	ainfo.setCurrencyConversionInfo(cclist);
	CurrencyConversion cvn = new CurrencyConversion();
	cclist.add(cvn);

	cvn.setExchangeRateCode(new ExchangeRateCode(1));
	cvn.setNumberOfDecimalPlaces(new NumberOfDecimalPlaces(3));
	cvn.setExchangeRate(new ExchangeRate(1477));

	ainfo.setTapDecimalPlaces(new TapDecimalPlaces(5));

	NetworkInfo ninfo =  new NetworkInfo();
	batch.setNetworkInfo(ninfo);

	UtcTimeOffsetInfoList ulist = new UtcTimeOffsetInfoList();
	ninfo.setUtcTimeOffsetInfo(ulist);
	UtcTimeOffsetInfo uelt = new UtcTimeOffsetInfo();
	ulist.add(uelt);

	uelt.setUtcTimeOffsetCode(new UtcTimeOffsetCode(1));
	uelt.setUtcTimeOffset(
	    new UtcTimeOffset(
		make_octet_string("-0400")
	    )
	);
	RecEntityInfoList rlist = new RecEntityInfoList();
	ninfo.setRecEntityInfo(rlist);
	RecEntityInformation relt = new RecEntityInformation();
	rlist.add(relt);

	relt.setRecEntityCode(new RecEntityCode(0));
	relt.setRecEntityType(new RecEntityType(1));

	relt.setRecEntityId(
	    RecEntityId.createRecEntityIdWithMscId (
		new MscId (
		    make_octet_string("595991799503")
		)
	    )
	);

	relt = new RecEntityInformation();
	rlist.add(relt);

	relt.setRecEntityCode(new RecEntityCode(1));
	relt.setRecEntityType(new RecEntityType(1));

	relt.setRecEntityId(
	    RecEntityId.createRecEntityIdWithMscId (
		new MscId (
		    make_octet_string("595993269503")
		 )
	    )
	 );

	ninfo.setNetworkType(new NetworkType(1));

	CalledNumAnalysisList cnlist = new CalledNumAnalysisList();
	ninfo.setCalledNumAnalysis(cnlist);
	CalledNumAnalysis cnelt = new CalledNumAnalysis();
	cnlist.add(cnelt);

	CountryCodeList ccolist = new CountryCodeList();
	cnelt.setCountryCodeTable(ccolist);
	ccolist.add(
	    new CountryCode(
		make_octet_string("595")
	    )
	);

	IacList iaclist = new IacList();
	cnelt.setIacTable(iaclist);
	iaclist.add(
	    new Iac(
		make_octet_string("002")
	    )
	);
	tap3.tap_0310.VasInfoList vlist = new tap3.tap_0310.VasInfoList();
	batch.setVasInfo(vlist);
	VasInformation velt = new VasInformation();
	vlist.add(velt);

	velt.setVasCode(new VasCode(1));
	velt.setVasShortDesc(
	    new VasShortDescription(
	       make_octet_string( "VD")
	    )
	);
	velt.setVasDesc(
	    new VasDescription(
	       make_octet_string( "Voice Mail  Retrie")
	    )
	);

	velt = new VasInformation();
	vlist.add(velt);

	velt.setVasCode(new VasCode(2));
	velt.setVasShortDesc(
	    new VasShortDescription(
	       make_octet_string( "VR")
	    )
	);
	velt.setVasDesc(
	    new VasDescription(
	       make_octet_string( "Voice Mail  Retrieval")
	    )
	);

	CallEventDetailList celist = new CallEventDetailList();
	batch.setCallEventDetails(celist);
	CallEventDetail ceelt = new CallEventDetail();
	celist.add(ceelt);
	MobileTerminatedCall call = new MobileTerminatedCall();
	ceelt.setMobileTerminatedCall(call);

	MtBasicCallInformation mtinfo = new MtBasicCallInformation();
	call.setBasicCallInformation(mtinfo);
	mtinfo.setChargeableSubscriber(
	    ChargeableSubscriber.createChargeableSubscriberWithSimChargeableSubscriber(
		new SimChargeableSubscriber(
		    new Imsi(
			new byte[]
			{
			    (byte)0x45, (byte)0x40, (byte)0x42, (byte)0x00,
			    (byte)0x58, (byte)0x85, (byte)0x45, (byte)0x5F
			}

		    ),
		    new Msisdn(
			new byte[]
			{
			    (byte)0x85, (byte)0x29, (byte)0x04, (byte)0x69,
			    (byte)0x64, (byte)0x1F
			}
		    )
		)
	    )
	);
	CallOriginator orig = new CallOriginator();
	mtinfo.setCallOriginator(orig);
	orig.setCallingNumber(
	    new AddressStringDigits( new byte[] { (byte) 0x0F })
	);

	CallEventStartTimeStamp cest = new CallEventStartTimeStamp();
	mtinfo.setCallEventStartTimeStamp(cest);
	cest.setLocalTimeStamp(
	    new LocalTimeStamp(
		make_octet_string("20040130160701")
	    )
	);
	cest.setUtcTimeOffsetCode(new UtcTimeOffsetCode(1));
	mtinfo.setTotalCallEventDuration(new TotalCallEventDuration(91));

	LocationInformation loinfo = new LocationInformation();
	call.setLocationInformation(loinfo);
	NetworkLocation nl = new NetworkLocation();
	loinfo.setNetworkLocation(nl);
	nl.setRecEntityCode(new RecEntityCode(0));
	nl.setLocationArea(new LocationArea(101));
	nl.setCellId(new CellId(11011));

	EquipmentInformation eqp = new EquipmentInformation();
	call.setEquipmentInformation(eqp);
	eqp.setMobileStationClassMark(new MobileStationClassMark(2));

	BasicServiceUsedList bslist = new BasicServiceUsedList();
	call.setBasicServiceUsedList(bslist);
	BasicServiceUsed bselt = new BasicServiceUsed();
	bslist.add(bselt);

	BasicService bs = new BasicService();
	bselt.setBasicService(bs);

	bs.setServiceCode(
	    BasicServiceCode.createBasicServiceCodeWithTeleServiceCode(
		new TeleServiceCode(
		    make_octet_string("11")
		)
	    )
	);
	bs.setRadioChannelRequested(new RadioChannelRequested(0));
	bs.setRadioChannelUsed(new RadioChannelUsed(1));
	bs.setSpeechVersionRequested(new SpeechVersionRequested(1));
	bs.setSpeechVersionUsed(new SpeechVersionUsed(1));
	bs.setTransparencyIndicator(new TransparencyIndicator(1));

	ChargeInformationList chlist = new ChargeInformationList();
	bselt.setChargeInformationList(chlist);
	ChargeInformation chelt = new ChargeInformation();
	chlist.add(chelt);

	chelt.setChargedItem(
	    new ChargedItem(
		make_octet_string("D")
	    )
	);
	chelt.setExchangeRateCode(new ExchangeRateCode(1));
	CallTypeGroup ctg = new CallTypeGroup();
	chelt.setCallTypeGroup(ctg);
	ctg.setCallTypeLevel1(new CallTypeLevel1(1));
	ctg.setCallTypeLevel2(new CallTypeLevel2(0));
	ctg.setCallTypeLevel3(new CallTypeLevel3(1));

	ChargeDetailList cdl = new ChargeDetailList();
	chelt.setChargeDetailList(cdl);
	ChargeDetail cdelt = new ChargeDetail();
	cdl.add(cdelt);

	cdelt.setChargeType(
	    new ChargeType(
		make_octet_string("00")
	    )
	);
	cdelt.setCharge(new Charge(0));
	cdelt.setChargeableUnits(new ChargeableUnits(91));
	cdelt.setChargedUnits(new ChargedUnits(120));
	cdelt.setDayCategory(
	    new DayCategory(
		make_octet_string("N")
	    )
	);
	cdelt.setTimeBand(
	    new TimeBand(
		make_octet_string("I")
	    )
	);

	cdelt = new ChargeDetail();
	cdl.add(cdelt);

	cdelt.setChargeType(
	    new ChargeType(
		make_octet_string("01")
	    )
	);
	cdelt.setCharge(new Charge(0));
	cdelt.setChargeableUnits(new ChargeableUnits(91));
	cdelt.setChargedUnits(new ChargedUnits(120));
	cdelt.setDayCategory(
	    new DayCategory(
		make_octet_string("N")
	    )
	);
	cdelt.setTimeBand(
	    new TimeBand(
		make_octet_string("I")
	    )
	);

	TaxInformationList tilist = new TaxInformationList();
	chelt.setTaxInformation(tilist);
	TaxInformation tielt = new TaxInformation();
	tilist.add(tielt);

	tielt.setTaxCode(new TaxCode(1));
	tielt.setTaxValue(new TaxValue(0));

	AuditControlInfo auinfo = new AuditControlInfo();
	batch.setAuditControlInfo(auinfo);
	EarliestCallTimeStamp ecs = new EarliestCallTimeStamp();
	auinfo.setEarliestCallTimeStamp(ecs);

	ecs.setLocalTimeStamp(
	    new LocalTimeStamp(
		make_octet_string("20040130160701")
	    )
	);
	ecs.setUtcTimeOffset(
	    new UtcTimeOffset(
		make_octet_string("-0400")
	    )
	);

	LatestCallTimeStamp lcs = new LatestCallTimeStamp();
	auinfo.setLatestCallTimeStamp(lcs);

	lcs.setLocalTimeStamp(
	    new LocalTimeStamp(
		make_octet_string("20040130172805")
	    )
	);
	lcs.setUtcTimeOffset(
	    new UtcTimeOffset(
		make_octet_string("-0400")
	    )
	);

	TotalChargeValueList tcvl = new TotalChargeValueList();
	auinfo.setTotalChargeValueList(tcvl);
	TotalChargeValue tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	    new ChargeType(
		make_octet_string("00")
	    )
	);
	tcv.setTotalCharge(new AbsoluteAmount(1161135));

	tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	    new ChargeType(
		make_octet_string("01")
	    )
	);
	tcv.setTotalCharge(new AbsoluteAmount(322273));

	tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	    new ChargeType(
		make_octet_string("02")
	    )
	);
	tcv.setTotalCharge(new AbsoluteAmount(838862));

	auinfo.setTotalTaxValue(new TotalTaxValue(116113));
	auinfo.setTotalDiscountValue(new TotalDiscountValue(0));
	auinfo.setCallEventDetailsCount(new CallEventDetailsCount(7));

	return pdu;
    }

    static RapDataInterChange  fill_RapDataInterChange_PDU()
    {
	RapDataInterChange pdu = new RapDataInterChange();
	ReturnBatch batch = new ReturnBatch();
	pdu.setReturnBatch(batch);

	RapBatchControlInfo rbi = new RapBatchControlInfo();
	batch.setRapBatchControlInfo(rbi);

	rbi.setSender(new Sender(make_octet_string("INDSC")));
	rbi.setRecipient(new Recipient(make_octet_string("INDAT")));
	rbi.setRapFileSequenceNumber(
	    new RapFileSequenceNumber(make_octet_string("00001")));

	rbi.setRapFileCreationTimeStamp(
	    new RapFileCreationTimeStamp(
		new LocalTimeStamp(make_octet_string("20031121163942")),
		new UtcTimeOffset(make_octet_string("+0530"))
	    )
	);

	rbi.setRapFileAvailableTimeStamp(
	    new RapFileAvailableTimeStamp(
		new LocalTimeStamp(make_octet_string("20031121163942")),
		new UtcTimeOffset(make_octet_string("+0530"))
	    )
	);

	rbi.setSpecificationVersionNumber(new SpecificationVersionNumber(3));
	rbi.setReleaseVersionNumber(new ReleaseVersionNumber(10));
	rbi.setRapSpecificationVersionNumber(new RapSpecificationVersionNumber(1));
	rbi.setRapReleaseVersionNumber(new RapReleaseVersionNumber(2));

	ReturnDetailList detail = new ReturnDetailList();
	batch.setReturnDetails(detail);
	ReturnDetail delt = new ReturnDetail();
	detail.add(delt);
	FatalReturn fatal = new FatalReturn();
	delt.setFatalReturn(fatal);

	fatal.setFileSequenceNumber(
	    new FileSequenceNumber(
		make_octet_string("00003")
	    )
	);

	AuditControlInfoError ace = new AuditControlInfoError();
	fatal.setAuditControlInfoError(ace);
	AuditControlInfo aci = new AuditControlInfo();
	ace.setAuditControlInfo(aci);
	aci.setEarliestCallTimeStamp(
	    new EarliestCallTimeStamp(
		new LocalTimeStamp(
		    make_octet_string("20030901155522")
		),
		new UtcTimeOffset(
		    make_octet_string("+0530")
		)
	    )
	);
	aci.setLatestCallTimeStamp(
	    new LatestCallTimeStamp(
		new LocalTimeStamp(
		    make_octet_string("20030915151235")
		),
		new UtcTimeOffset(
		    make_octet_string("+0530")
		)
	    )
	);

	/* Fill the list of 4 elements */
	TotalChargeValueList tcvl = new TotalChargeValueList();
	aci.setTotalChargeValueList(tcvl);
	TotalChargeValue tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	   new ChargeType(make_octet_string("00"))
	);
	tcv.setTotalCharge(new AbsoluteAmount(955400));

	/* Second element */
	tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	   new ChargeType(make_octet_string("01"))
	);
	tcv.setTotalCharge(new AbsoluteAmount(401800));

	/* 3rd element */
	tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	   new ChargeType(make_octet_string("03"))
	);
	tcv.setTotalCharge(new AbsoluteAmount(259800));

	/* 4th element */
	tcv = new TotalChargeValue();
	tcvl.add(tcv);

	tcv.setChargeType(
	   new ChargeType(make_octet_string("21"))
	);
	tcv.setTotalCharge(new AbsoluteAmount(191080));

	aci.setTotalTaxValue(new TotalTaxValue(0));
	aci.setTotalDiscountValue(new TotalDiscountValue(0));
	aci.setCallEventDetailsCount(new CallEventDetailsCount(102));

	ErrorDetailList edl = new ErrorDetailList();
	ace.setErrorDetail(edl);
	ErrorDetail ed = new ErrorDetail();
	edl.add(ed);

	ErrorContextList ecl = new ErrorContextList();
	ed.setErrorContext(ecl);
	ErrorContext ec = new ErrorContext();
	ecl.add(ec);
	ec.setPathItemId(new PathItemId(1));
	ec.setItemLevel(new ItemLevel(1));

	ec = new ErrorContext();
	ecl.add(ec);
	ec.setPathItemId(new PathItemId(15));
	ec.setItemLevel(new ItemLevel(2));

	ec = new ErrorContext();
	ecl.add(ec);
	ec.setPathItemId(new PathItemId(71));
	ec.setItemLevel(new ItemLevel(3));


	ed.setErrorCode(new ErrorCode(100));

	RapAuditControlInfo rauci = new RapAuditControlInfo();
	batch.setRapAuditControlInfo(rauci);
	rauci.setTotalSevereReturnValue(new TotalSevereReturnValue(0));
	rauci.setReturnDetailsCount(new ReturnDetailsCount(1));

	return pdu;
    }


    static byte[] make_octet_string(String str)
    {
	int length = str.length();
	byte[] ret = new byte[length];

	for (int i = 0; i < length; i++)
	    ret[i] = (byte)str.charAt(i);

	return ret;
    }

}
