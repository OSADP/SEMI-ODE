#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)cleanup.sh	16.2 14/02/08
#***************************************************************************

echo Cleaning all intermediate files in the entire samples directory...

curr_dir=$PWD

dir_list=`find . -type d`

for dir in $dir_list; do
    if [ -f $dir/run.sh ]; then
	cd $dir
	echo "    " $dir
	sh run.sh cleanup
    fi
    cd $curr_dir
done;

echo Done with cleanup.
