/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Encoder.java	16.2 14/02/08
 */

/*
 * Demonstrates NBAP PDU encoding.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import nbap.*;
import nbap.nbap_pdu_discriptions.*;
import nbap.nbap_commondatatypes.*;
import nbap.nbap_pdu_contents.*;
import nbap.nbap_containers.*;
import nbap.nbap_constants.*;
import nbap.nbap_ies.*;

public class Encoder {

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Nbap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Nbap.getPERAlignedCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	/*
	 * Construct the PDU for encoding.
	 */
	AbstractData msg = fill_NBAP_PDU();

	System.out.println("PDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);

    }


    /*
     * Helper methods to set up the PDU for encoding.
     */
    static AbstractData fill_NBAP_PDU()
    {
	NBAP_PDU npdu = new NBAP_PDU();

	/* Indicate Initiating Message type */
	InitiatingMessage message = new InitiatingMessage();
	npdu.setInitiatingMessage(message);
	/* Indicate preparation of a new configuration of Radio Link(s)
	 * related to one Node B Communication Context */
	message.setProcedureID(
	    new ProcedureID (
		new ProcedureCode(31),
		ProcedureID.DdMode.fdd
	    )
	);

	/* Indicate procedure criticality */
	message.setCriticality(Criticality.reject);

	/* Indicate Transaction ID (chose long variant) */
	message.setTransactionID(
	    TransactionID.createTransactionIDWithLongTransActionId(1)
	);

	/* Indicate Dedicated NBAP message */
	message.setMessageDiscriminator(MessageDiscriminator.dedicated);

	/* Create an unencoded value for OpenType field initiatingMessage.value */
	message.setValue(
	    new OpenType(
		fill_RadioLinkReconfigurationPrepareFDD_PDU()
	    )
	 );

	return npdu;
    }

    static RadioLinkReconfigurationPrepareFDD fill_RadioLinkReconfigurationPrepareFDD_PDU()
    {
	RadioLinkReconfigurationPrepareFDD   pdu =
	    new RadioLinkReconfigurationPrepareFDD();
	ProtocolIE_Container ie = new ProtocolIE_Container();

	/* Create unencoded value for the PDU, it consists
	 * of 4 Information Elements (IEs) */
	pdu.setProtocolIEs(ie);

	/* First IE is a NodeB CommunicationContextID */
	ie.add(
	    new ProtocolIE_Field (
		 NBAP_Constants.id_NodeB_CommunicationContextID,
		 Criticality.reject,
		 new com.oss.asn1.OpenType (
		     new nbap.nbap_ies.NodeB_CommunicationContextID(2)
		 )
	    )
	);

	/* Create the second IE - UL DPCH Information */
	ie.add(
	    new ProtocolIE_Field (
		 NBAP_Constants.id_UL_DPCH_Information_RL_ReconfPrepFDD,
		 Criticality.reject,
		 new com.oss.asn1.OpenType (
		     fill_UL_DPCH_Information_RL_ReconfPrepFDD_PDU()
		 )
	    )
	);

    /* Create the third IE - DL DPCH Information */
	ie.add(
	    new ProtocolIE_Field (
		 NBAP_Constants.id_DL_DPCH_Information_RL_ReconfPrepFDD,
		 Criticality.reject,
		 new com.oss.asn1.OpenType (
		     fill_DL_DPCH_Information_RL_ReconfPrepFDD_PDU()
		 )
	    )
	);

    /* Create the fourth IE - DSCH ModifyList */
	ie.add(
	    new ProtocolIE_Field (
		 NBAP_Constants.id_DSCH_ModifyList_RL_ReconfPrepFDD,
		 Criticality.reject,
		 new com.oss.asn1.OpenType (
		     fill_DSCH_ModifyList_RL_ReconfPrepFDD_PDU()
		 )
	    )
	);
	return pdu;
    }

    static UL_DPCH_Information_RL_ReconfPrepFDD fill_UL_DPCH_Information_RL_ReconfPrepFDD_PDU()
    {
	UL_DPCH_Information_RL_ReconfPrepFDD ul_dpch =
	    new UL_DPCH_Information_RL_ReconfPrepFDD();

	UL_ScramblingCode code = new UL_ScramblingCode();
	ul_dpch.setUl_ScramblingCode(code);

	code.setUL_ScramblingCodeNumber(new UL_ScramblingCodeNumber(1234));
	code.setUL_ScramblingCodeLength(UL_ScramblingCodeLength._short);

	ul_dpch.setUl_SIR_Target(new UL_SIR(11));
	ul_dpch.setMinUL_ChannelisationCodeLength(MinUL_ChannelisationCodeLength.v4);
	ul_dpch.setMaxNrOfUL_DPDCHs(new MaxNrOfUL_DPDCHs(5));
	ul_dpch.setUl_PunctureLimit(new PunctureLimit(8));
	ul_dpch.setUl_DPCCH_SlotFormat(new UL_DPCCH_SlotFormat(2));
	ul_dpch.setSSDT_CellIDLength(SSDT_CellID_Length._short);
	ul_dpch.setS_FieldLength(S_FieldLength.v2);

	TFCS tfcs = new TFCS();
	ul_dpch.setTFCS(tfcs);

	TFCS.TFCSvalues tfcsValues = new TFCS.TFCSvalues();
	tfcs.setTFCSvalues(tfcsValues);

	/* no_Split_in_TFCI alternative is a list of 3 elements */
	TFCS_TFCSList list = new TFCS_TFCSList();
	tfcsValues.setNo_Split_in_TFCI(list);

	/* Init first element of the list */
	TFCS_TFCSList.Sequence_ element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc2bit(0)
	);
	TransportFormatCombination_Beta beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	TransportFormatCombination_Beta.SignalledGainFactors factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	TransportFormatCombination_Beta.SignalledGainFactors.GainFactor factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(1));
	fdd.setBetaD(new BetaCD(2));

	/* Second element */
	element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc2bit(1)
	);
	beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(3));
	fdd.setBetaD(new BetaCD(4));

	/* Third element*/
	element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc4bit(4)
	);
	beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(5));
	fdd.setBetaD(new BetaCD(6));

	return ul_dpch;
    }

    static DL_DPCH_Information_RL_ReconfPrepFDD fill_DL_DPCH_Information_RL_ReconfPrepFDD_PDU()
    {
	DL_DPCH_Information_RL_ReconfPrepFDD dl_dpch =
	    new DL_DPCH_Information_RL_ReconfPrepFDD();

	dl_dpch.setDl_DPCH_SlotFormat(new DL_DPCH_SlotFormat(10));
	TFCI_SignallingMode mode = new TFCI_SignallingMode();
	dl_dpch.setTFCI_SignallingMode(mode);
	mode.setTFCI_SignallingOption(TFCI_SignallingMode_TFCI_SignallingOption.split);
	dl_dpch.setTFCI_Presence(TFCI_Presence.present);
	dl_dpch.setMultiplexingPosition(MultiplexingPosition.fixed);

	TFCS tfcs = new TFCS();
	dl_dpch.setTFCS(tfcs);

	TFCS.TFCSvalues tfcsValues = new TFCS.TFCSvalues();
	tfcs.setTFCSvalues(tfcsValues);

	/* no_Split_in_TFCI alternative is a list of 3 elements */
	TFCS_TFCSList list = new TFCS_TFCSList();
	tfcsValues.setNo_Split_in_TFCI(list);

	/* Init first element of the list */
	TFCS_TFCSList.Sequence_ element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc2bit(0)
	);
	TransportFormatCombination_Beta beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	TransportFormatCombination_Beta.SignalledGainFactors factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	TransportFormatCombination_Beta.SignalledGainFactors.GainFactor factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(7));
	fdd.setBetaD(new BetaCD(8));

	/* Second element */
	element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc2bit(1)
	);
	beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(6));
	fdd.setBetaD(new BetaCD(5));

	/* Third element*/
	element = new TFCS_TFCSList.Sequence_();
	list.add(element);
	element.setCTFC(
	    TFCS_CTFC.createTFCS_CTFCWithCtfc4bit(4)
	);
	beta =
	    new TransportFormatCombination_Beta();
	element.setTFC_Beta(beta);
	factors =
	    new TransportFormatCombination_Beta.SignalledGainFactors();
	beta.setSignalledGainFactors(factors);
	factor =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor();
	factors.setGainFactor(factor);
	fdd =
	    new TransportFormatCombination_Beta.SignalledGainFactors.GainFactor.Fdd();
	factor.setFdd(fdd);
	fdd.setBetaC(new BetaCD(4));
	fdd.setBetaD(new BetaCD(3));

	return dl_dpch;
    }

    static DSCH_ModifyList_RL_ReconfPrepFDD fill_DSCH_ModifyList_RL_ReconfPrepFDD_PDU()
    {
	DSCH_ModifyList_RL_ReconfPrepFDD    m_list =
	    new DSCH_ModifyList_RL_ReconfPrepFDD();

	ProtocolIE_Field element = new ProtocolIE_Field();
	m_list.add(element);

	/* Init value of the element */
	element.setId(NBAP_Constants.id_DSCH_ModifyItem_RL_ReconfPrepFDD);
	element.setCriticality(Criticality.reject);
	element.setValue(
	    new OpenType(
		fill_DSCH_ModifyItem_RL_ReconfPrepFDD_PDU()
	    )
	);
	return m_list;
    }

    static DSCH_ModifyItem_RL_ReconfPrepFDD fill_DSCH_ModifyItem_RL_ReconfPrepFDD_PDU()
    {
	DSCH_ModifyItem_RL_ReconfPrepFDD m_item =
	    new DSCH_ModifyItem_RL_ReconfPrepFDD();

	m_item.setDSCH_ID(new DSCH_ID(2));
	m_item.setFrameHandlingPriority(new FrameHandlingPriority(3));
	m_item.setToAWS(new ToAWS(123));
	m_item.setToAWE(new ToAWE(456));
	m_item.setTransportBearerRequestIndicator(TransportBearerRequestIndicator.bearerRequested);

	TransportFormatSet set = new TransportFormatSet();
	m_item.setDl_TransportFormatSet(set);

	TransportFormatSet_Semi_staticPart part =
	    new TransportFormatSet_Semi_staticPart();
	set.setSemi_staticPart(part);

	part.setTransmissionTimeInterval(
	   TransportFormatSet_TransmissionTimeIntervalSemiStatic.msec_20
	);
	part.setChannelCoding(
	    TransportFormatSet_ChannelCodingType.convolutional_coding
	);
	part.setCodingRate(TransportFormatSet_CodingRate.half);
	part.setRateMatchingAttribute(
	    new TransportFormatSet_RateMatchingAttribute(3)
	);
	part.setCRC_Size(TransportFormatSet_CRC_Size.v8);
	part.setMode(
	    TransportFormatSet_ModeSSP.createTransportFormatSet_ModeSSPWithNotApplicable(
		new com.oss.asn1.Null()
	    )
	);

       /* dynamicParts is a list of two elements.
	* Create the first one */
       TransportFormatSet_DynamicPartList list =
	   new TransportFormatSet_DynamicPartList();
       set.setDynamicParts(list);
       TransportFormatSet_DynamicPartList.Sequence_ element =
	   new TransportFormatSet_DynamicPartList.Sequence_();
       list.add(element);
       element.setNrOfTransportBlocks(
	   new TransportFormatSet_NrOfTransportBlocks(1)
       );
       element.setTransportBlockSize(
	   new TransportFormatSet_TransportBlockSize(25)
       );
       element.setMode(
	   TransportFormatSet_ModeDP.createTransportFormatSet_ModeDPWithNotApplicable(
	       new com.oss.asn1.Null()
	   )
       );

       /* Create the second element */
       element =
	   new TransportFormatSet_DynamicPartList.Sequence_();
       list.add(element);
       element.setNrOfTransportBlocks(
	   new TransportFormatSet_NrOfTransportBlocks(5)
       );
       element.setTransportBlockSize(
	   new TransportFormatSet_TransportBlockSize(280)
       );
       element.setMode(
	   TransportFormatSet_ModeDP.createTransportFormatSet_ModeDPWithNotApplicable(
	       new com.oss.asn1.Null()
	   )
       );
       return m_item;
    }

}
