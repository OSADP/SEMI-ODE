/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Runme.java	16.2 14/02/08 */

import hugeint.*;
import hugeint.sample_security.*;

import com.oss.asn1.*;
import java.math.BigInteger;
import java.io.*;

public class Runme {
    public static void main(String[] args)
    {
	// Initialize the project
	try {
	    Hugeint.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization error: " + e);
	    System.exit(1);
	}
	
	// Create the coder
	Coder coder = Hugeint.getDERCoder();
	// Set the decoder to emit trace output
	coder.enableDecoderDebugging();
	
	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	try {
	    // Create the InputStream to read the encoding from the file
	    FileInputStream source = new FileInputStream("dsaparms.der");
	    // Decode the value of Dsa-Parms where 'p', 'q' and 'g' are huge
	    // 1024-bit numbers.
	    Dsa_Parms parms = (Dsa_Parms)coder.decode(source, new Dsa_Parms());
	    source.close();
	    System.out.println();
	    // Print the decoded parameters of the DSA algorithm
	    System.out.println("Decoded parameters of DSA algorithm:");
	    System.out.println();
	    System.out.println("p = " + parms.getP().bigIntegerValue());
	    System.out.println("q = " + parms.getQ().bigIntegerValue());
	    System.out.println("g = " + parms.getG().bigIntegerValue());
	} catch (Exception e) {
	    System.out.println("Unexpected exception: " + e);
	}
    }
}
