#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)runall.sh	16.3 14/02/08
#***************************************************************************

echo Running all the samples...

dir_list=`find basic advanced standards cldc -type d`
curr_dir=$PWD

for dir in $dir_list; do
    cd $dir;
    if [ -f run.sh ]; then
        echo "    " $dir
	sh run.sh > run.log
    fi
    cd $curr_dir
done;

echo Done with running all the samples.
