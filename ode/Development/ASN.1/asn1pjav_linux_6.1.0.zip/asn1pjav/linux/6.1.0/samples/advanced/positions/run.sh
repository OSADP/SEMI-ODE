#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	1.3 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -fr baseball
	rm -f *.log
	rm -f *.class
	break;;
	
    "javac")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the baseball.asn abstract syntax and run the Tpos

	echo "----- Compiling the bcd.asn specification -----"
	$ASN1 $COMMON_ASN1_OPTIONS baseball -err compile.log
	if [ $? -eq 0 ]; then 
	    cd baseball
	    echo "----- Compiling generated classes -----"
	    sh baseball.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g Tpos.java 2>&1 >> compile.log
	    if [ -f Tpos.class ]; then
		echo "----- Running the Tpos sample -----";
		$JAVA $COMMON_JAVA_OPTIONS Tpos;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac
