/***************************************************************************
 *  Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
 ***************************************************************************
 *  THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 *  AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 *  THIS FILE MAY NOT BE DISTRIBUTED.
 *  THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 ***************************************************************************
 * FILE: @(#)H245.java	16.1 07/01/23
 ***************************************************************************
 *
 * Simple Java program that demonstrates the support for H.245 by the OSS ASN.1
 * tools. It illustrates communication between terminals according to H.245
 * control protocol. The following messages are supported by this sample:
 * - Receiving and transmitting capabilities;
 * - Master-slave determination.
 * When the program is executed with '-s' argument it listens for incoming
 * connections on localhost:2123; when it is executed with '-c' argument it
 * connects to localhost:2123 and initiates terminal capability exchange by
 * sending a TerminalCapabilitySet request.
 */

import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.SocketException;
import java.util.Random;
import java.util.Date;

import com.oss.asn1.*;
import com.oss.util.HexTool;
import com.oss.util.ExceptionDescriptor;

import h245v10.*;
import h245v10.multimedia_system_control.*;

public class H245 {

    static String host = "127.0.0.1";
    static int port = 2123;
    static OutputStream out = null;
    static InputStream in = null;
    static ControlChannel controlChannel;
    
    static int timeouts[] = { 
	0,  /* s_Idle */
	30000, /* s_waitingCapsResponse */
	30000, /* s_outgoingWaitingMsResponse */
	30000, /* s_incomingWaitingMsResponse */
	10000  /* s_ClosingConnection */
    };
    
    static String stateNames[] = {
	"IDLE",
	"WAITING CAPABILITIES RESPONSE",
	"OUTGOING WAITING MASTER-SLAVE RESPONSE",
	"INCOMING WAITING MASTER-SLAVE RESPONSE",
	"CLOSING CONNECTION"
    };
    
    static boolean USE_RANDOM_NUMBERS = false;
    static final int MASTER_SLAVE_DETERMINATION_MAX_RETRIES = 10;
    
    static Coder coder;

    public static void main(String[] args) {
	controlChannel = new ControlChannel();
	boolean 	usage = (args.length != 1);
	boolean ok = true;

	coder = H245v10.getPERAlignedCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	
	if (!usage) {
	/* Check command line arguments */
	    if (args[0].equals("-c"))
		controlChannel.caller = true;
	    else if (args[0].equals("-s"))
		controlChannel.caller = false;
	    else
		usage = true;
	}

	if (usage) {
	    System.out.println("Usage: H245 [ -c | -s ]\n" +
		"\t-c   client mode: initiate Terminal Capability Set exchange\n" +
		"\t-s   server mode: listen for client connections\n");
	}

	startControlChannel(host);

	MultimediaSystemControlMessage controlPDU = null;	
	
	while (ok) {
	    try {
		controlChannel.socket.setSoTimeout(timeouts[controlChannel.state]);
	    } catch (SocketException e) {
		System.out.println(e.getMessage());
		System.exit(1);
	    }
	    
	    if (controlChannel.state == controlChannel.s_Idle) {
		printActionStart("Listen for the peer's messages");
		printActionSeparator();
	    }

	    printState();
	    System.out.println("Action:            receiving PDU");

	    System.out.println("\nDecoding...");
	    try {
		controlPDU = (MultimediaSystemControlMessage)
		    coder.decode(in, new MultimediaSystemControlMessage());
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoding failed: " + e);
		System.exit(2);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoding failed: " + e);
		if (e.getReason() == ExceptionDescriptor.FATAL_ERROR) 
		    ok = handleTimeOut();
		else {
		    System.out.println("Decoding failed: " + e);
		    ok = false;	    
		}
	    }
	    
	    if (controlPDU != null) {
		/*
	         * Print the PDU.
	         */
	        System.out.println("PDU received:");
		System.out.println(controlPDU);
	    
		System.out.print("PDU processed:     ");
		ok = handleControlPDU(controlPDU);
	    	controlPDU = null;
	    }
	}
	stopControlChannel();
    }

    /* 
     * Initializes the control channel, including TCP socket
     */
    static void startControlChannel(String host)
    {
	controlChannel.msStatus = ControlChannel.s_Indeterminate;
	/* 
        * set terminal type to "Terminal only" as per H.323 terminal
        * types for H.245 master-slave determination
        */
	controlChannel.terminalType = 50;
	controlChannel.capsSent = false;
	controlChannel.capsReceived = false;
	controlChannel.state = ControlChannel.s_Idle;
	controlChannel.tcs_inSeqNumber = new SequenceNumber(Short.MAX_VALUE);
	controlChannel.tcs_outSeqNumber = new SequenceNumber(0);
	controlChannel.remoteCaps = null;
	controlChannel.msDeterminationNumber = 0;
	controlChannel.step = 1;
	controlChannel.localCaps = createLocalCapabilities();
	if ( controlChannel.localCaps == null) {
	    System.err.println("Couldn't create LocalCapabilities");
	    System.exit(1);
	}
	    
	if (controlChannel.caller) {
	    /* Create socket and Input/Output Streams */
	    try {
		controlChannel.socket = new Socket(host, port);
		out = controlChannel.socket.getOutputStream();
		in = controlChannel.socket.getInputStream();
	    } catch (UnknownHostException e) {
		System.err.println("Don't know about host: " + host);
		System.exit(1);
	    } catch (IOException e) {
		System.err.println("Couldn't get I/O for "
	                       + "the connection to: " + host);
		System.exit(1);
	    }

	    printActionStart("Send a TerminalCapabilitySet");
	    startTerminalCapabilityExchange();
	}
	else {
	    ServerSocket serverSocket = null;
	    try {
    		serverSocket =  
    		    new ServerSocket(port, 1, InetAddress.getByName(host));
	    }
	    catch (IOException e) {
    		e.printStackTrace();
    		System.exit(1);
	    }

    	    try {
    		controlChannel.socket = serverSocket.accept();
    		in = controlChannel.socket.getInputStream();
    		out = controlChannel.socket.getOutputStream();
    		serverSocket.close();
    	    }
    	    catch (Exception e) {
    		e.printStackTrace();
    		System.exit(1);
            }
	}
    }

    /* Creates terminal capabilities specification. */
    static TerminalCapabilitySet createLocalCapabilities()
    {
	TerminalCapabilitySet.CapabilityTable capTable = 
		new TerminalCapabilitySet.CapabilityTable();
	CapabilityDescriptor.SimultaneousCapabilities simultaneousCaps =
		new CapabilityDescriptor.SimultaneousCapabilities();

	int i, aCount = 0;
	for (i = 0, aCount = 0; i < SupportedCapabilities.CAPABILITIES_COUNT; i++) {
	    Capability cap = SupportedCapabilities.cfn(i);
	    /* Append capability to the table */
	    CapabilityTableEntry capEntry = 
		new CapabilityTableEntry(new CapabilityTableEntryNumber(i + 1), cap);
    	    capTable.add(capEntry);
    	    
	    /* Fill in the capability descriptor */
	    if (SupportedCapabilities.newAltSet(i)) {
		/* Should we create new AlternativeCapabilitySet */
		if (aCount > 0) { /* Number of alternatives is not zero */
		    /* append  new AlternativeCapabilitySet to the simultaneousCaps */
		    simultaneousCaps.add(createAlternativeCaps(aCount, i - aCount + 1));
		    aCount = 0;
		}
	    }
	    aCount++;
	}

	if (aCount > 0) { /* Number of alternatives is not zero */
	    /* append  new AlternativeCapabilitySet to the simultaneousCaps */
	    simultaneousCaps.add(createAlternativeCaps(aCount, i - aCount + 1));
	}
	
	CapabilityDescriptor capDescriptor = 
		new CapabilityDescriptor(new CapabilityDescriptorNumber(1), simultaneousCaps);
	TerminalCapabilitySet.CapabilityDescriptors capDescriptorsSet = 
		new TerminalCapabilitySet.CapabilityDescriptors();
	capDescriptorsSet.add(capDescriptor);
	
	TerminalCapabilitySet capSet = new TerminalCapabilitySet();	
	capSet.setProtocolIdentifier(new ObjectIdentifier(
		new byte[] {
		    (byte)0x00, (byte)0x08, (byte)0x81, (byte)0x75,
		    (byte)0x00, (byte)0x0A
		}));
	capSet.setMultiplexCapability(createMultiplexCapability());
	capSet.setCapabilityTable(capTable);
	capSet.setCapabilityDescriptors(capDescriptorsSet);
	
	return capSet;
    }

    /* 
     * Starts Terminal Capabilities exchange by sending TerminalCapabilitySet
     * H.245 request message.
     */
    public static boolean startTerminalCapabilityExchange()
    {
	if (controlChannel.state == controlChannel.s_waitingCapsResponse) {
	    printActionSeparator();
	    System.out.println(
		"Capability exchange is already in progress: outSeq = " +
		controlChannel.tcs_outSeqNumber);
	    return true;
	}
	
	controlChannel.tcs_outSeqNumber = new SequenceNumber(
	    (controlChannel.tcs_outSeqNumber.intValue() + 1) % 256);
	controlChannel.localCaps.setSequenceNumber(controlChannel.tcs_outSeqNumber);
	RequestMessage request = 
	    RequestMessage.createRequestMessageWithTerminalCapabilitySet(controlChannel.localCaps);

	/* Create H.245 Control message */
	MultimediaSystemControlMessage controlPDU = 
	    MultimediaSystemControlMessage.createMultimediaSystemControlMessageWithRequest(request);
	printActionState();
	controlChannel.state = ControlChannel.s_waitingCapsResponse;
	/* Send the message to the peer terminal */
	return encodeAndSendControlMessage(controlPDU);
    }

    /* 
     * Handles a timeout on TCP socket - sends a release indication or 
     * terminates the connection.
     */
    static boolean handleTimeOut()
    {
	switch (controlChannel.state) {
	    case ControlChannel.s_waitingCapsResponse:
		return releaseIndication(RequestMessage.terminalCapabilitySet_chosen,
		    "TimeOut on TerminalCapabilitySet exchange\n");
	    case ControlChannel.s_outgoingWaitingMsResponse:
		return releaseIndication(IndicationMessage.masterSlaveDeterminationRelease_chosen,
		    "TimeOut on Master-Slave determination\n");
	    default:
		return releaseControlChannel(null);
	}
    }

    /* Encodes given H.245 message to the ControlChannel TCP socket. */
    public static boolean encodeAndSendControlMessage(
					MultimediaSystemControlMessage controlPDU)
    {
	System.out.println("Action:            sending PDU\nPDU to send:");
	System.out.println(controlPDU);

	try {
	    coder.encode(controlPDU, out);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    if (controlChannel.state != ControlChannel.s_ClosingConnection) {
	    	return releaseControlChannel(null);
	    }
	    return false;
	}
	
	System.out.println("PDU sent; new state: " + stateNames[controlChannel.state]);
	printActionSeparator();
	return true;
    }

    /*
     * Handles incoming H.245 messages - dispatches them to corresponding
     * handler functions based on the message type.
     */
    static boolean handleControlPDU(MultimediaSystemControlMessage controlPDU)
    {
	switch (controlPDU.getChosenFlag()) {
	    case MultimediaSystemControlMessage.request_chosen:
		return handleControlRequest((RequestMessage)controlPDU.getChosenValue());
	    case MultimediaSystemControlMessage.response_chosen:
		return handleControlResponse((ResponseMessage)controlPDU.getChosenValue());
	    case MultimediaSystemControlMessage.command_chosen:
		return handleControlCommand((CommandMessage)controlPDU.getChosenValue());
	    case MultimediaSystemControlMessage.indication_chosen:
		return handleControlIndication((IndicationMessage)controlPDU.getChosenValue());
	    default:
    		System.out.println("FAILED\n");
		return releaseControlChannel("Unknown H.245 PDU received\n");
	}
    }

    /*
     * Handles incoming H.245 Request messages - dispatches them to corresponding
     * handler functions based on the Request type.
     */
    static boolean handleControlRequest(RequestMessage request)
    {
	switch (request.getChosenFlag()) {
	    case RequestMessage.terminalCapabilitySet_chosen:
		return handleTerminalCapsIncoming(
		    (TerminalCapabilitySet)request.getChosenValue());
	    case RequestMessage.masterSlaveDetermination_chosen:
    		return handleMSDeterminationIncoming(
    		    (MasterSlaveDetermination)request.getChosenValue());
	    case RequestMessage.openLogicalChannel_chosen:
	    case RequestMessage.closeLogicalChannel_chosen:
	    case RequestMessage.requestChannelClose_chosen:
	    case RequestMessage.multiplexEntrySend_chosen:
	    case RequestMessage.requestMultiplexEntry_chosen:
	    case RequestMessage.requestMode_chosen:
	    case RequestMessage.roundTripDelayRequest_chosen:
	    case RequestMessage.maintenanceLoopRequest_chosen:
	    case RequestMessage.communicationModeRequest_chosen:
	    case RequestMessage.conferenceRequest_chosen:
	    case RequestMessage.multilinkRequest_chosen:
	    case RequestMessage.logicalChannelRateRequest_chosen:
	    case RequestMessage.genericRequest_chosen:
		H245_UNSUPPORTED("request", request);
		return true;
	    default:
		return funcNotUnderstoodIndication(
		    MultimediaSystemControlMessage.request_chosen, request);
	}
    }

    /*
     * Handles incoming H.245 Response messages - dispatches them to corresponding
     * handler functions based on the Response type.
     */
    static boolean handleControlResponse(ResponseMessage response)
    {
        switch (response.getChosenFlag()) {
    	    case ResponseMessage.masterSlaveDeterminationAck_chosen:
    		return handleMSDeterminationAckResponse(
    		    (MasterSlaveDeterminationAck)response.getChosenValue());
    	    case ResponseMessage.masterSlaveDeterminationReject_chosen:
		System.out.println("Master-Slave determination Request rejected");
		if (controlChannel.state == ControlChannel.s_Idle)
		    return true;
		return restartMasterSlaveDetermination();
    	    case ResponseMessage.terminalCapabilitySetAck_chosen:
	    case ResponseMessage.terminalCapabilitySetReject_chosen:
		return handletermCapsAckOrRejectResponse(response);
	    case ResponseMessage.openLogicalChannelAck_chosen:
	    case ResponseMessage.openLogicalChannelReject_chosen:
	    case ResponseMessage.closeLogicalChannelAck_chosen:
	    case ResponseMessage.requestChannelCloseAck_chosen:
	    case ResponseMessage.requestChannelCloseReject_chosen:
	    case ResponseMessage.multiplexEntrySendAck_chosen:
	    case ResponseMessage.requestMultiplexEntryReject_chosen:
	    case ResponseMessage.requestModeAck_chosen:
	    case ResponseMessage.requestModeReject_chosen:
	    case ResponseMessage.roundTripDelayResponse_chosen:
	    case ResponseMessage.maintenanceLoopAck_chosen:
	    case ResponseMessage.maintenanceLoopReject_chosen:
	    case ResponseMessage.communicationModeResponse_chosen:
	    case ResponseMessage.conferenceResponse_chosen:
	    case ResponseMessage.multilinkResponse_chosen:
	    case ResponseMessage.logicalChannelRateAcknowledge_chosen:
	    case ResponseMessage.logicalChannelRateReject_chosen:
	    case ResponseMessage.genericResponse_chosen:
    		H245_UNSUPPORTED("response", response);
		return true;
	    default:
		return funcNotUnderstoodIndication(
		    MultimediaSystemControlMessage.response_chosen, response);
	}
    }

    /*
     * Handles incoming H.245 Command messages - dispatches them to corresponding
     * handler functions based on the Command type.
     */
    static boolean handleControlCommand(CommandMessage command)
    {
	switch (command.getChosenFlag()) {
	    case CommandMessage.endSessionCommand_chosen:
		System.out.println("OK");
		if (controlChannel.state != ControlChannel.s_ClosingConnection)
		    return endSessionCommand();
		return false;
	    case CommandMessage.sendTerminalCapabilitySet_chosen: {
		SendTerminalCapabilitySet capsCommand = 
		    (SendTerminalCapabilitySet)command.getChosenValue();
		if (capsCommand.getChosenFlag() == SendTerminalCapabilitySet.genericRequest_chosen) {
		    System.out.println("OK");
		    return startTerminalCapabilityExchange();
		} else {
		    System.out.println("IGNORED");
		    printActionSeparator();
		}
	    }
	    case CommandMessage.maintenanceLoopOffCommand_chosen:
	    case CommandMessage.encryptionCommand_chosen:
	    case CommandMessage.miscellaneousCommand_chosen:
    	    case CommandMessage.communicationModeCommand_chosen:
    	    case CommandMessage.conferenceCommand_chosen:
	    case CommandMessage.h223MultiplexReconfiguration_chosen:
	    case CommandMessage.newATMVCCommand_chosen:
	    case CommandMessage.mobileMultilinkReconfigurationCommand_chosen:
	    case CommandMessage.genericCommand_chosen:
		H245_UNSUPPORTED("command", command);
		return true;
	    default:
		return funcNotUnderstoodIndication(
	    	    MultimediaSystemControlMessage.command_chosen, command);
	}
    }
    
    /*
     * Handles incoming H.245 Indication messages - dispatches them to corresponding
     * handler functions based on the Indication type.
     */
    static boolean handleControlIndication(IndicationMessage indication)
    {
	switch (indication.getChosenFlag()) {
	    case IndicationMessage.terminalCapabilitySetRelease_chosen:
		System.out.println("OK");
		return releaseControlChannel("TerminaCapabilitySet exchange aborted.\n");
	    case IndicationMessage.masterSlaveDeterminationRelease_chosen:
		System.out.println("OK");
    		return releaseControlChannel("Master-Slave determination aborted.\n");
	    default:
		H245_UNSUPPORTED("indication", indication);
		return true;
	}
    }

    /*
     * Terminates the connection.
     */
    static boolean releaseControlChannel(String msg)
    {
        if (msg != null) {
	    printActionSeparator();
	    System.out.println(msg);
	}
	printActionStart("Close connection");
	if (controlChannel.capsSent && controlChannel.capsReceived &&
		controlChannel.msStatus != ControlChannel.s_Indeterminate)
	    return endSessionCommand();
	printActionSeparator();
	return false;
    }

    /* 
     * Creates the H.245 CapabilitySetReject message and sends it to the
     * peer terminal.
     */
    static void terminalCapabilitySetRejectResponse()
    {
	printActionState();
	TerminalCapabilitySetReject.Cause cause = 
	    TerminalCapabilitySetReject.Cause.createCauseWithUndefinedTableEntryUsed(Null.VALUE);
	TerminalCapabilitySetReject tcsReject = 
	    new TerminalCapabilitySetReject(controlChannel.tcs_inSeqNumber, cause);	
	ResponseMessage response = 
	    ResponseMessage.createResponseMessageWithTerminalCapabilitySetReject(tcsReject);	
	sendMmSystemControlMessage(
	    MultimediaSystemControlMessage.response_chosen, response);
    }

    /* Handles incoming Terminal capabilities. */
    static boolean handleTerminalCapsIncoming(TerminalCapabilitySet receivedCaps)
    {
	if (controlChannel.tcs_inSeqNumber == receivedCaps.getSequenceNumber() ||
		    !handleTerminalCapabilitySet(receivedCaps)) {
	    terminalCapabilitySetRejectResponse();
	    return releaseControlChannel("Reject Terminal capabilities");
	}
	
	System.out.println("OK\nTerminal capabilities received:");
	controlChannel.capsReceived = true;
	System.out.println(controlChannel.remoteCaps);
	updateActionState(ControlChannel.s_Idle);
	/* Acknowledge TCS to the peer terminal */
	boolean ret = terminalCapabilitySetAckResponse();
	if (!ret) 
	    return ret;	
	if (!controlChannel.capsSent) {
	/* If we did not sent Capabilities yet do it now */
	    printActionStart("Send a TerminalCapabilitySet");
    	    return startTerminalCapabilityExchange();
	}
	return true;
    }

    /* 
     * Creates the H.245 CapabilitySetAck message and sends it to the
     * peer terminal.
     */
    static boolean terminalCapabilitySetAckResponse()
    {    
	printActionState();
	TerminalCapabilitySetAck tcsAck = 
	    new TerminalCapabilitySetAck(controlChannel.tcs_inSeqNumber);
	ResponseMessage response = 
	    ResponseMessage.createResponseMessageWithTerminalCapabilitySetAck(tcsAck);	
	boolean ret = sendMmSystemControlMessage(
		    MultimediaSystemControlMessage.response_chosen, response);
	if (ret)
    	    System.out.println("Terminal capabilities received\n");
	return ret;
    }


    /* Handles incoming TerminalCapabilitySet. */
    static boolean handleTerminalCapabilitySet(TerminalCapabilitySet receivedCaps)
    {	
	TerminalCapabilitySet.CapabilityDescriptors receivedDescriptors = 
		receivedCaps.getCapabilityDescriptors();
	TerminalCapabilitySet.CapabilityTable receivedTable = 
		receivedCaps.getCapabilityTable();
	controlChannel.tcs_inSeqNumber = receivedCaps.getSequenceNumber();
		
	if ((receivedCaps.getMultiplexCapability() == null) && (receivedTable == null) &&
		(receivedDescriptors == null))
	    /*
	     * Empty TCS indicates third-party pause; We should close
	     * open logical channels and Knowledge of the remote EP's
	     * capabilities should be completely removed. This is out of 
	     * scope of this sample - just return TRUE
	     */
	    return true;
	    
	if (controlChannel.remoteCaps == null) {
	    /*
	     * This is the first time we receive TCS - create the remoteCaps.
	     */
	    controlChannel.remoteCaps = new TerminalCapabilitySet(
			controlChannel.tcs_outSeqNumber,
			(ObjectIdentifier)receivedCaps.getProtocolIdentifier().clone());
	    controlChannel.remoteCaps.setCapabilityTable(
					new TerminalCapabilitySet.CapabilityTable());
	    controlChannel.remoteCaps.setCapabilityDescriptors(
				    new TerminalCapabilitySet.CapabilityDescriptors());
	}

	if (receivedTable != null) {
	    /* capabilityTable is present */	
    	    if (receivedTable.getSize() == 0)
		return false;
	    /* Handle Capability table */
	    handleCapabilityTable(receivedTable);
	}
	
	if (receivedDescriptors != null) 
	    /* capabilityDescriptors are present */
	    handleCapabilityDescriptors(receivedDescriptors);

	/* 
	 * return FALSE if no one of the capabilities is supported by the
	 * terminal.
	 */
	return (controlChannel.remoteCaps.getCapabilityTable().getSize() != 0);
    }

    /*
     * Handles incoming Capabilities table - checks that every capability in
     * the table is supported by the terminal and appends it or removes it 
     * from the table containing remote capabilities.
     */
    static void handleCapabilityTable(TerminalCapabilitySet.CapabilityTable receivedTable)
    {
	TerminalCapabilitySet.CapabilityTable remoteTable = 
		controlChannel.remoteCaps.getCapabilityTable();

	/* For every entry in the table */
        for (int i = 0; i < receivedTable.getSize(); i++)
        {
    	    Capability newCapability = null;
    	    CapabilityTableEntry cNode = 
    		(CapabilityTableEntry) receivedTable.get(i);
    	    CapabilityTableEntry fNode = findCapability(remoteTable,
			    cNode.getCapabilityTableEntryNumber());
            if (fNode != null) {
    		/* Previously received CapabilityTableEntry is found */
		if (cNode.getCapability() != null) {
		/*
		 * When a CapabilityTableEntry is received, it replaces 
		 * previously received CapabilityTableEntry with the same 
		 * CapabilityTableEntryNumber. (If this capability is
		 * supported by the terminal)
		 */
		    newCapability = oNReceiveCapability(cNode.getCapability());

		    if (newCapability != null) {
			fNode.setCapability(newCapability);
		    } else {
			remoteTable.remove(fNode);
		    }
		} else {
		/*
		 * A CapabilityTableEntry without a Capability may be
		 * used to remove the previously received CapabilityTableEntry
		 * with the same CapabilityTableEntryNumber
		 */
		    remoteTable.remove(fNode);
		}
	    /* Check if the Capability is supported by given Terminal */
	    } else {
		newCapability = oNReceiveCapability(cNode.getCapability());
		
		if (newCapability != null) {
		    /* 
		     * The Capability is supported by given Terminal,
		     * append corresponding entry to the table containing
		     * remote capabilities
		     */
    		    CapabilityTableEntry newEntry = 
    			new CapabilityTableEntry(cNode.getCapabilityTableEntryNumber(), 
    						 newCapability);
    		    remoteTable.add(newEntry);
		}
	    }
	} /* for */
    }

    /*
     * Checks if the received capability is supported by the
     * terminal. Returns copy of the 'Capability' if it is
     * supported and NULL otherwise.
     */
    static Capability oNReceiveCapability(Capability capability)
    {
	Capability ret = null;
	/* For every capability supported by the terminal */
	for (int i = 0; i < SupportedCapabilities.CAPABILITIES_COUNT; i++) {
	    /* call appropriate function */
    	    ret = SupportedCapabilities.rfn(i, capability);
    	    if (ret != null) /* Capability supported */
    		return ret;
	}
	return null; /* Unsupported capability */
    }

    /* 
     * This function is called through the rfn pointer in the 
     * 'st_supportedCapabilities' structure whenever remote terminal 
     * Capability is received. If the Capability received is a GSM 
     * AudioCapability it allocates memory for the new capability and sets 
     * its fields according to the values in the received capability.
     * If it is not a GSM AudioCapability it returns NULL.
     */
    static Capability oNReceiveGSMAudioCapability(Capability capability)
    {
	/* get received AudioCapability */
	AudioCapability audioCap = getAudioCapability(capability);
	/* check if it is GSM AudioCapability */
	if (audioCap == null || audioCap.getChosenFlag() 
				!= AudioCapability.gsmFullRate_chosen)
	    return null;
    
	/* get received GSM AudioCapability */
	GSMAudioCapability gsmCap = (GSMAudioCapability)audioCap.getChosenValue();
	/* 
	 * set new GSM capability fields according to values in the
	 * received GSM capability
	 */
	GSMAudioCapability newGsmCap = new GSMAudioCapability(
					    gsmCap.getAudioUnitSize(),
					    gsmCap.getComfortNoise(),
					    gsmCap.getScrambled());
					    
	AudioCapability newAudioCap = 
	    AudioCapability.createAudioCapabilityWithGsmFullRate(newGsmCap);
	
	Capability newCap =  new Capability();    
	newCap.setChosenFlag(capability.getChosenFlag());//setAudioCapability
	newCap.setChosenValue(newAudioCap);//setAudioCapability	
	return newCap;
    }

    /* 
     * This function is called through the rfn pointer in the 
     * 'st_supportedCapabilities' structure whenever remote terminal 
     * Capability is received. If the Capability received is g7231 
     * AudioCapability it allocates memory for the new capability and sets 
     * its fields according to the values in the received capability.
     * If it is not g7231 AudioCapability it returns NULL.
     */
    static Capability oNReceiveg7231AudioCapability(Capability capability)
    {
	/* get received AudioCapability */
	AudioCapability audioCap = getAudioCapability(capability);
	/* check if it is g7231 AudioCapability */
	if (audioCap == null || audioCap.getChosenFlag() != AudioCapability.g7231_chosen)
	    return null;

	/* get received g7231 AudioCapability */
	AudioCapability.G7231 g7231Cap = 
		(AudioCapability.G7231)audioCap.getChosenValue();
	/* 
	 * set new g7231 capability fields according to values in the
	 * received g7231 capability
	 */
	AudioCapability.G7231 newg7231Cap = new AudioCapability.G7231(
					    g7231Cap.getMaxAl_sduAudioFrames(),
					    g7231Cap.getSilenceSuppression());
	AudioCapability newAudioCap = 
	    AudioCapability.createAudioCapabilityWithG7231(newg7231Cap);
	
	Capability newCap =  new Capability();
	newCap.setChosenFlag(capability.getChosenFlag());//setAudioCapability
	newCap.setChosenValue(newAudioCap);//setAudioCapability	
	return newCap;
    }

    /* 
     * This function is called through the 'rfn' pointer in the 
     * 'st_supportedCapabilities' structure whenever remote terminal 
     * Capability is received. If the Capability received is H.263 
     * VideCapability it allocates memory for the new capability and sets 
     * its fields according to the values in the received capability.
     * If it is not H.263 VideoCapability it returns NULL.
     */
    static Capability oNReceiveH263VideoCapability(Capability capability)
    {
	/* get received VideoCapability */
        VideoCapability videoCap = getVideoCapability(capability);
	/* check if it is H.263 VideoCapability */
	if (videoCap == null || videoCap.getChosenFlag() != 
			VideoCapability.h263VideoCapability_chosen)
	    return null;
 
	/* get received H.263 VideoCapability */
	H263VideoCapability h263Cap = (H263VideoCapability)videoCap.getChosenValue();
	/* 
	 * set new H.263 capability fields according to values in the
	 * received H.263 capability
	 */
	H263VideoCapability newH263Cap = (H263VideoCapability)h263Cap.clone();
	/* omit enhancementLayerInfo and options fields for simplicity */
	newH263Cap.setEnhancementLayerInfo(null);
	newH263Cap.setH263Options(null);

	VideoCapability newVideoCap = 
	    VideoCapability.createVideoCapabilityWithH263VideoCapability(newH263Cap);
	Capability newCap =  new Capability();
	newCap.setChosenFlag(capability.getChosenFlag());//setVideoCapability
	newCap.setChosenValue(newVideoCap);//setVideoCapability	
	return newCap;
    }

    /* Creates and initializes AlternativeCapabilitySet. */
    static AlternativeCapabilitySet createAlternativeCaps(int aCount, int first)
    {
	AlternativeCapabilitySet altCaps = new AlternativeCapabilitySet();
	for (int i = 0; i < aCount; i++)
	    altCaps.add(new CapabilityTableEntryNumber(first + i));
	return altCaps;
    }

    /* Creates the MultiplexCapability and sets its fields. */
    static MultiplexCapability createMultiplexCapability()
    {
	H2250Capability.McCapability mcCapability = 
	    new H2250Capability.McCapability(false, false);

	H2250Capability h2250Cap = new H2250Capability (
		20,				/* maximumAudioDelayJitter 20, */
		createMultipointCapability(),	/* receiveMultipointCapability */
		createMultipointCapability(),	/* transmitMultipointCapability */
		createMultipointCapability(),	/* receiveAndTransmitMultipointCapability */
		mcCapability,			/* mcCapability */
		false,				/* rtcpVideoControlCapability */
		new MediaPacketizationCapability(false) /* mediaPacketizationCapability */
	);
	
	MultiplexCapability multiplexCap = 
	    MultiplexCapability.createMultiplexCapabilityWithH2250Capability(h2250Cap);
	return multiplexCap;
    }

    /* Creates the MultipointCapability and sets its fields. */
    static MultipointCapability createMultipointCapability()
    {
	/*
	 * {
	 *   multicastCapability FALSE,
	 *   multiUniCastConference FALSE,
	 *   mediaDistributionCapability
	 *   {
	 *     {
	 *        centralizedControl FALSE,
	 *        distributedControl FALSE,
	 *        centralizedAudio FALSE,
	 *        distributedAudio FALSE,
	 *        centralizedVideo FALSE,
	 *        distributedVideo FALSE
	 *     }
	 *   }
	 * }
	 */
	MultipointCapability.MediaDistributionCapability mediaDistribCap = 
		new MultipointCapability.MediaDistributionCapability();
	mediaDistribCap.add(new MediaDistributionCapability(
	                            false, false, false, false, false, false));
	MultipointCapability multipointCap = 
		new MultipointCapability(false, false, mediaDistribCap);
	return multipointCap;
    }

    /* 
     * Utility function - returns pointer to the AudioCapability
     * structure if given Capability value contains capability of 
     * this type.
     */
    static AudioCapability getAudioCapability(Capability capability)
    {
	switch (capability.getChosenFlag()) {
	    case Capability.receiveAudioCapability_chosen:
	    case Capability.transmitAudioCapability_chosen:
	    case Capability.receiveAndTransmitAudioCapability_chosen:
		return (AudioCapability)capability.getChosenValue();
	}
	return null;
    }

    /* 
     * Utility function - returns pointer to the VideoCapability
     * structure if given Capability contains capability of this 
     * type or NULL otherwise.
     */
    static VideoCapability getVideoCapability(Capability capability)
    {
	switch (capability.getChosenFlag()) {
	    case Capability.receiveVideoCapability_chosen:
	    case Capability.transmitVideoCapability_chosen:
	    case Capability.receiveAndTransmitVideoCapability_chosen:
		return (VideoCapability)capability.getChosenValue();
	}
	return null;
    }

    /* Finds the Capability with given number in given table. */
    static CapabilityTableEntry findCapability(
			    TerminalCapabilitySet.CapabilityTable table,
			    CapabilityTableEntryNumber number)
    {
	/* For every capability in the table */
        for (int i = 0; i < table.getSize(); i++) {
    	    CapabilityTableEntry value = (CapabilityTableEntry)(table.get(i));
	    if (value.getCapabilityTableEntryNumber().equals(number))
		return value;
	}
	/* No Capabilities found */
	return null;
    }

    /* Handles incoming Capability descriptors. */
    static void handleCapabilityDescriptors(
	    TerminalCapabilitySet.CapabilityDescriptors receivedDescriptors)
    {
	TerminalCapabilitySet.CapabilityDescriptors remoteDescriptors =
		     controlChannel.remoteCaps.getCapabilityDescriptors();

        for (int i = 0; i < receivedDescriptors.getSize(); i++)
        {
	    CapabilityDescriptor.SimultaneousCapabilities newSimultaneous = null;
	    CapabilityDescriptor dNode = (CapabilityDescriptor)receivedDescriptors.get(i);
	    CapabilityDescriptor fdNode = findDescriptor(remoteDescriptors,
					dNode.getCapabilityDescriptorNumber());	    
    	    if (fdNode != null) {
		/* Previously received CapabilityDescriptor is found */
		if (fdNode.getSimultaneousCapabilities() != null) {
		    /*
		     * Replace simultaneousCapabilities in the CapabilityDescriptor
		     * with the new ones
		     */
		    fdNode.setSimultaneousCapabilities(
			    handleSimultaneousCapabilities(dNode.getSimultaneousCapabilities()));
		} else {
		    /* 
		     * delete the CapabilityDescriptor from the list of 
		     * received descriptors
		     */
		    remoteDescriptors.remove(fdNode);
		}
	    } else {
		newSimultaneous = handleSimultaneousCapabilities(
		            		    dNode.getSimultaneousCapabilities());
		if (newSimultaneous != null) {
		    /* Append descriptor to the list of received descriptors */
		    CapabilityDescriptor newDescriptor =
			new CapabilityDescriptor(dNode.getCapabilityDescriptorNumber(),
						 newSimultaneous);
		    remoteDescriptors.add(newDescriptor);
		}
	    }
	} /* for */
    }

    /* Finds descriptor with given number. */
    static CapabilityDescriptor findDescriptor(
		    TerminalCapabilitySet.CapabilityDescriptors capabilityDescriptors,
		    CapabilityDescriptorNumber number)
    {
	/* For every descriptor */
        for (int i = 0; i < capabilityDescriptors.getSize(); i++) {
    	    /* Check the Descriptor number */        
    	    CapabilityDescriptor value = (CapabilityDescriptor)capabilityDescriptors.get(i);
	    if (value.getCapabilityDescriptorNumber().equals(number))
		return value; /* Return the found descriptor */
	}
	/* No descriptors found */
	return null;
    }

    /* 
     * Handles incoming simultaneous capabilities - checks that
     * CapabilityTableEntryNumbers in the simultaneousCapabilities
     * correspond to the capabilities supported by the terminal.
     */
    static CapabilityDescriptor.SimultaneousCapabilities handleSimultaneousCapabilities(
				CapabilityDescriptor.SimultaneousCapabilities simulCaps)
    {
	CapabilityDescriptor.SimultaneousCapabilities ret = 
	    new CapabilityDescriptor.SimultaneousCapabilities();
	TerminalCapabilitySet.CapabilityTable remoteTable = 
	    controlChannel.remoteCaps.getCapabilityTable();

        for (int j = 0; j < simulCaps.getSize(); j++) {
	    AlternativeCapabilitySet cNode = 
		(AlternativeCapabilitySet)simulCaps.get(j);
	    /* 
	     * Create new AlternativeCapabilitySet containing only
	     * those CapabilityTableEntryNumbers that are supported 
	     * by the terminal
	     */
	    AlternativeCapabilitySet altSet = new AlternativeCapabilitySet();
	    
	    for (int i = 0; i < cNode.getSize(); i++)
		if (findCapability(remoteTable, cNode.get(i)) != null) 
		    altSet.add(cNode.get(i));		
		
	    if (altSet.getSize()>0)
		ret.add(altSet);
	}
	return ret;
    }

    /* Handles incoming Master-slave determination message. */
    static boolean handleMSDeterminationIncoming(MasterSlaveDetermination msDetermination)
    {
	int newStatus;
	long receivedTt = msDetermination.getTerminalType();
	if (controlChannel.state == ControlChannel.s_incomingWaitingMsResponse) {
	    System.out.println("Unexpected (duplicated) Master-Slave determination message");
	    return false;
	}
	/* Determine the status */
	if (controlChannel.terminalType == receivedTt) {
	    long diff;
	    /* (MasterSlaveDetermination.statusDeterminationNumber - sv_SDNUM) MOD 2^24 */
	    diff = (msDetermination.getStatusDeterminationNumber() - 
			    controlChannel.msDeterminationNumber) & 0xFFFFFF;
	    if (diff != 0 && diff != 0x800000 /* 2^23 */)
		newStatus = (diff < 0x800000 /* 2^23*/) ? 
				ControlChannel.s_Master : 
				ControlChannel.s_Slave; 
	    else
		newStatus = ControlChannel.s_Indeterminate;
	} else if (controlChannel.terminalType > receivedTt)
	    newStatus = ControlChannel.s_Master;
	else
	    newStatus = ControlChannel.s_Slave;

	if (newStatus != ControlChannel.s_Indeterminate) {
	    controlChannel.msStatus = newStatus;
	    if (newStatus == ControlChannel.s_Master)
		System.out.println("Master-Slave determination - local is: MASTER");
	    else
		System.out.println("Master-Slave determination - local is: SLAVE");
	    printActionState();
	    controlChannel.state = ControlChannel.s_incomingWaitingMsResponse;
	    return msDeterminationAckResponse(newStatus);
	} else {
	    System.out.println("Master-Slave determination - local is: indeterminate\n");
	    if (controlChannel.state == ControlChannel.s_outgoingWaitingMsResponse)
    		return restartMasterSlaveDetermination();
	    printActionState();
	    return msDeterminationRejectResponse();
	}
    }

    /* 
     * Creates the H.245 Function Not Understood indication message 
     * and sends it to the peer terminal.
     */
    static boolean funcNotUnderstoodIndication(int funcType, Object func)
    {
	if (funcType < MultimediaSystemControlMessage.request_chosen ||
		funcType > MultimediaSystemControlMessage.command_chosen)
	    return false;
	System.out.println("Not understood");
	printActionState();
	FunctionNotUnderstood funcNotUnderstood = new FunctionNotUnderstood();

	switch (funcType) {
	    case MultimediaSystemControlMessage.request_chosen:
		funcNotUnderstood.setRequest((RequestMessage)func);
		break;
	    case MultimediaSystemControlMessage.response_chosen:
		funcNotUnderstood.setResponse((ResponseMessage)func);
		break;
	    case MultimediaSystemControlMessage.command_chosen:
		funcNotUnderstood.setCommand((CommandMessage)func);
	}
	IndicationMessage indicationMessage =
	    IndicationMessage.createIndicationMessageWithFunctionNotUnderstood(funcNotUnderstood);
	return sendMmSystemControlMessage( 
					MultimediaSystemControlMessage.indication_chosen,
					indicationMessage);
    }

    /* Handles incoming Master-slave determination Ack response. */
    static boolean handleMSDeterminationAckResponse(
				MasterSlaveDeterminationAck msDeterminationAck)
    {
	int newStatus;

	if (controlChannel.state == ControlChannel.s_Idle) /* ignore the message */
	    return true;

    	MasterSlaveDeterminationAck.Decision decision = msDeterminationAck.getDecision();

	if (decision.getChosenFlag() == MasterSlaveDeterminationAck.Decision.master_chosen)
	    newStatus = ControlChannel.s_Master;
	else
	    newStatus = ControlChannel.s_Slave;
    
	if (controlChannel.state == ControlChannel.s_outgoingWaitingMsResponse) {
	    if (newStatus == ControlChannel.s_Master)
		System.out.println("Master-Slave determination remote is: MASTER");
	    else
		System.out.println("Master-Slave determination remote is: SLAVE");
    	    controlChannel.msStatus = newStatus;
	    printActionState();
	    controlChannel.state = ControlChannel.s_Idle;
	    /* decision = opposite of MasterSlaveDeterminationAck.decision */
	    msDeterminationAckResponse(newStatus);
	} else {
	    if (controlChannel.msStatus != newStatus) {
		System.out.println("Master-Slave determination failed: inconsistent MASTER/SLAVE value");
		controlChannel.msStatus = ControlChannel.s_Indeterminate;
	    } else
		System.out.println("OK\n");
	    updateActionState(ControlChannel.s_Idle);
	    printActionSeparator();
        }
    
	System.out.println("Master/Slave determination finished\n");  
	return releaseControlChannel(null);
    }


    /* Handles incoming CapabilitySetReject and CapabilitySetAck responses. */
    static boolean handletermCapsAckOrRejectResponse(ResponseMessage response)
    {
	boolean ret = true;

	if (controlChannel.state != ControlChannel.s_waitingCapsResponse)
	    return true;
 
	if (response.getChosenFlag() == ResponseMessage.terminalCapabilitySetAck_chosen) {
	    /* Capabilities are acknowledged by the remote terminal */
	    TerminalCapabilitySetAck tcsAck = 
		    (TerminalCapabilitySetAck)response.getChosenValue();
		    
	    if (!controlChannel.tcs_outSeqNumber.equals(tcsAck.getSequenceNumber())) {
		System.out.println("Unexpected sequenceNumber " + 
			    tcsAck.getSequenceNumber() + " - ignored;");
		printActionSeparator();
		return true; /* Non fatal - just ignore the message */
	    }
	    
	    System.out.println("OK");
	    updateActionState(ControlChannel.s_Idle);
	    printActionSeparator();
	    System.out.println("Terminal capabilities sent\n");
	    controlChannel.capsSent = true;
	    
	    if (controlChannel.capsReceived == true)
	    /* 
	     * Start Master-slave determination if Capabilities exchange
	     * procedures are finished. In real-life applications Capability
	     * exchange and Master-Slave determination could be performed
	     * simultaneously - for simplicity we perform these procedures
	     * in series.
	     */
    		ret = startMasterSlaveDetermination();
	} else {
	    /* Capabilities are rejected by the remote terminal */
    	    System.out.println("OK");
	    updateActionState(ControlChannel.s_Idle);
	    printActionSeparator();
	    System.out.println("Terminal capabilities rejected");
	    ret = false; /* Close connection */
	}
	return ret;
    }

    /* 
     * Creates the H.245 DeterminationReject message and sends it to the
     * peer terminal.
     */
    static boolean msDeterminationRejectResponse()
    {
	MasterSlaveDeterminationReject.Cause cause = 
	    MasterSlaveDeterminationReject.Cause.createCauseWithIdenticalNumbers(Null.VALUE);
	MasterSlaveDeterminationReject msdReject = 
	    new MasterSlaveDeterminationReject(cause);
	ResponseMessage response = 
	    ResponseMessage.createResponseMessageWithMasterSlaveDeterminationReject(msdReject);
	sendMmSystemControlMessage(
	    MultimediaSystemControlMessage.response_chosen, response);
	return releaseControlChannel(null);
    }

    /*
     * Starts Master-Slave determination procedure by sending
     * MasterSlaveDetermination Request.
     */
    static boolean startMasterSlaveDetermination()
    {
	if (controlChannel.state != ControlChannel.s_Idle) {
	    System.out.println("Master-Slave determination is already in progress");
	    return true;
	}
	controlChannel.msRetryCount = 0;
	printActionStart("Send Master-Slave determination");
	return restartMasterSlaveDetermination();
    }

    /* 
     * Restarts Master-Slave determination procedure with the
     * new master/slave determination number (if retries limit
     * is exceeded).
     */
    static boolean restartMasterSlaveDetermination()
    {
	if (controlChannel.msRetryCount >= MASTER_SLAVE_DETERMINATION_MAX_RETRIES)
	    return releaseControlChannel("Master-Slave determination retries exceeded\n");
	printActionState();
	controlChannel.msRetryCount++;
	if (controlChannel.msRetryCount > 1)
	    System.out.println("Retry:             " + controlChannel.msRetryCount);
	/* generate a master/slave determination number */
	if (USE_RANDOM_NUMBERS == true) {
	    /* In the real life applications use random numbers */
	    int random = (new Random((new Date()).getTime())).nextInt();
	    if (random < 0)
		random = (-random); 
	    controlChannel.msDeterminationNumber = random & 0xFFFFFF;
	} else
	    /* For the purposes of this sample use hardcoded value. */
	    controlChannel.msDeterminationNumber = 11711627;

	MasterSlaveDetermination msDetermination = new MasterSlaveDetermination(
		    controlChannel.terminalType, controlChannel.msDeterminationNumber);
	RequestMessage request = 
	    RequestMessage.createRequestMessageWithMasterSlaveDetermination(msDetermination);
	controlChannel.state = ControlChannel.s_outgoingWaitingMsResponse;
	return sendMmSystemControlMessage(
		MultimediaSystemControlMessage.request_chosen, request);
    }

    /* Createss H.245 message and sets its fields. */
    static MultimediaSystemControlMessage createControlPDU(int msgType, Object msg)
    {
	if (msgType < MultimediaSystemControlMessage.request_chosen ||
		msgType > MultimediaSystemControlMessage.indication_chosen)
	    return null;
	MultimediaSystemControlMessage controlPDU = new MultimediaSystemControlMessage();

	switch (msgType) {
	    case MultimediaSystemControlMessage.request_chosen:
		controlPDU.setRequest((RequestMessage)msg);
		break;
	    case MultimediaSystemControlMessage.response_chosen:
		controlPDU.setResponse((ResponseMessage)msg);
		break;
	    case MultimediaSystemControlMessage.command_chosen:
		controlPDU.setCommand((CommandMessage)msg);
		break;
	    case MultimediaSystemControlMessage.indication_chosen:
		controlPDU.setIndication((IndicationMessage)msg);
    		break;
	    default:
		break;
	}
	return controlPDU;
    }

    /* Creates H.245 Message and sends it to the ControlChannel socket. */
    static boolean sendMmSystemControlMessage(int msgType, Object msg)
    {
	MultimediaSystemControlMessage controlPDU = createControlPDU(msgType, msg);
	if (controlPDU == null)
	    return false;
	return encodeAndSendControlMessage(controlPDU);
    }

    /* 
     * Creates the H.245 Release indication message and sends it to the
     * peer terminal.
     */
    static boolean releaseIndication(int releaseType, String msg)
    {
	System.out.println(msg);
        printActionState();
        IndicationMessage indication = new IndicationMessage();
	switch (releaseType) {
	    case IndicationMessage.masterSlaveDeterminationRelease_chosen:
		indication.setMasterSlaveDeterminationRelease(
			new MasterSlaveDeterminationRelease());
		break;
    	    case IndicationMessage.terminalCapabilitySetRelease_chosen:
		indication.setTerminalCapabilitySetRelease(new TerminalCapabilitySetRelease());
		break;
	}

	sendMmSystemControlMessage( 
			MultimediaSystemControlMessage.indication_chosen, indication);
	return releaseControlChannel(null);
    }

    /* 
     * Creates the H.245 DeterminationAck message and sends it to the
     * peer terminal.
     */
    static boolean msDeterminationAckResponse(int status)
    {
	MasterSlaveDeterminationAck.Decision decision;

	if (status == ControlChannel.s_Master)
	    decision = 
		MasterSlaveDeterminationAck.Decision.createDecisionWithSlave(Null.VALUE);
	else
	    decision = 
		MasterSlaveDeterminationAck.Decision.createDecisionWithMaster(Null.VALUE);
	    
	MasterSlaveDeterminationAck msDeterminationAck = 
		    new MasterSlaveDeterminationAck(decision);
	ResponseMessage response = 
	    ResponseMessage.createResponseMessageWithMasterSlaveDeterminationAck(msDeterminationAck);	    
	/* send MasterSlaveDeterminationAck message to the peer MSDSE */
	return sendMmSystemControlMessage(
	    MultimediaSystemControlMessage.response_chosen, response);
    }

    /* 
     * Creates the H.245 EndSession command message and sends it to the
     * peer terminal.
     */
    static boolean endSessionCommand()
    {
	EndSessionCommand endSession = 
	    EndSessionCommand.createEndSessionCommandWithDisconnect(Null.VALUE);
	CommandMessage commandMsg =
	    CommandMessage.createCommandMessageWithEndSessionCommand(endSession);
        printActionState();
	controlChannel.state = ControlChannel.s_ClosingConnection;
	
	return sendMmSystemControlMessage(
		MultimediaSystemControlMessage.command_chosen, commandMsg);
    }

    public static void stopControlChannel() 
    {
	try {
    	    out.close();
    	    in.close();
    	    controlChannel.socket.close();
    	    printActionSeparator();    
    	    System.out.println("Connection closed");
    	} catch (IOException e) {
    	    System.out.println(e.getMessage());
    	}
    }

    static void H245_UNSUPPORTED(String type, Choice value)
    {
	System.out.println("This type of H.245 " + type + 
	    " (CHOICE indicator is " + value.getChosenValue() + 
	    " is not supported by the sample.");
	printActionSeparator();
    }

    public static void printActionSeparator()
    {
	System.out.println(
	    "------------------------------------------------------------------------------"
	);
    }

    public static void printActionState()
    {	
	printActionSeparator();
	printState();
    }
    
    public static void printState()
    {
	System.out.println("State:             " + stateNames[controlChannel.state]);
	if (controlChannel.state != controlChannel.s_Idle) 
	    System.out.println("Timeout:           " 
				+ timeouts[controlChannel.state]/1000 + " sec");
    }

    public static void printActionStart(String action)
    {
	System.out.println(controlChannel.step++ + ")" + action);
    }

    public static void updateActionState(int state)
    {	
	controlChannel.state = state;
	System.out.println("Updated state:     " + stateNames[state]);
    }

    public static class ControlChannel {

	/**
        * Identifies the states of the ContriolChannel.
        */
	public static final int s_Idle = 0;
	public static final int s_waitingCapsResponse = 1;
	public static final int s_outgoingWaitingMsResponse = 2;
	public static final int s_incomingWaitingMsResponse = 3;
	public static final int s_ClosingConnection  = 4;

	/**
        * Identifies the Master-slave status.
        */
	public static final int s_Indeterminate = 0;
	public static final int s_Master = 1;
	public static final int s_Slave = 2;

	Socket     socket; /* TCP socket */
	int   	state; /* current ControlChannel state */
	/*
        * the value of the sequenceNumber field of the most recently
        * received TerminalCapabilitySet message
        */
	SequenceNumber         tcs_inSeqNumber;
	/* to indicate the most recent TerminalCapabilitySet message */
	SequenceNumber         tcs_outSeqNumber;
	TerminalCapabilitySet  localCaps; /* This terminal Capabilities */
	TerminalCapabilitySet  remoteCaps; /* Remote terminal Capabilities */
	/* holds the status determination number for this terminal */
	long           msDeterminationNumber;
	int           msStatus; /* Master/Slave determination status */
	/* holds the terminal type number for this terminal */
	short                  terminalType;
	/*
        * counts the number of MasterSlaveDetermination messages 
        * that have been sent in OUTGOING AWAITING RESPONSE state
        */
	short                  msRetryCount;
	short                  step; /* Step number */
	/* Indicates that terminal should initiate Terminal Capability exchange */
	boolean             caller;
	/* Indicates Capabilities sent */
	boolean             capsSent;
	/* Indicates Capabilities received */
	boolean             capsReceived;
    } // End class definition for ControlChannel;

    static class SupportedCapabilities
    {
	public static final int CAPABILITIES_COUNT = 3;

        public static Capability cfn(int i) {
    	    Capability capability = null;
    	    AudioCapability audioCap;
	    switch (i) {
		case 0:
		/* creates the GSMAudioCapability and sets its fields.
		 * capability receiveAndTransmitAudioCapability : gsmFullRate :
		 *     {
		 *        audioUnitSize 132,
		 *	  comfortNoise TRUE,
		 *	  scrambled TRUE
		 *     }
		 */
		    GSMAudioCapability gsmFullRate = 
			new GSMAudioCapability(132, true, true);
		    audioCap = 
			AudioCapability.createAudioCapabilityWithGsmFullRate(gsmFullRate);
		    capability = 
			Capability.createCapabilityWithReceiveAndTransmitAudioCapability(audioCap);
		    break;	
		case 1:
		/* creates the g7231 AudioCapability and sets its fields.
		 *  capability receiveAndTransmitAudioCapability : g7231 :
		 *     {
		 *        maxAl-sduAudioFrames 2,
		 *        silenceSuppression TRUE
		 *     }
		 */
		    AudioCapability.G7231 g7231 = new AudioCapability.G7231(2, true);
		    audioCap =  AudioCapability.createAudioCapabilityWithG7231(g7231);		
		    capability = 
			Capability.createCapabilityWithReceiveAndTransmitAudioCapability(audioCap);
		    break;	
		case 2:
		/* Allocates memory for the H.263 Video Capability and sets its fields. 
		 * capability receiveAndTransmitVideoCapability : h263VideoCapability :
		 *    {
		 *        qcifMPI 4,
		 *        maxBitRate 1999,
		 *        unrestrictedVector FALSE,
		 *	  arithmeticCoding FALSE,
		 *	  advancedPrediction FALSE,
		 *	  pbFrames FALSE,
		 *	  temporalSpatialTradeOffCapability FALSE
		 *    }
		 */
		    H263VideoCapability h263VideoCapability =
			new H263VideoCapability(1999, false, false, false, false, false);
		    h263VideoCapability.setQcifMPI(4);
		    VideoCapability videoCap = 
			VideoCapability.createVideoCapabilityWithH263VideoCapability(h263VideoCapability);
		    capability = 
			Capability.createCapabilityWithReceiveAndTransmitVideoCapability(videoCap);
	    }		
	    return capability;	
	}
	
	public static Capability rfn(int i, Capability capability) {
	    switch (i) {
		case 0:
		    return oNReceiveGSMAudioCapability(capability);
		case 1:
		    return oNReceiveg7231AudioCapability(capability);
		case 2:	
		    return oNReceiveH263VideoCapability(capability);	
	    }	    	    
	    return null;
	}
	
	public static boolean newAltSet(int i) {
	    if (i == 0 || i == 2)
		return true;
	    return false;
	}
    }
}
