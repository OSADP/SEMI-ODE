
/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Benchmark.java	16.3 14/02/08
 */
import com.oss.asn1.AbstractData;
import com.oss.asn1.Coder;
import j2735.J2735;
import j2735.dsrc.BasicSafetyMessage;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * The sample demonstrates the relative encoding/decoding speed
 * and size of a BSM encoded message for three encoding rules, OER,
 * PER, and BER.
 */

/**
 * The class implements the benchmark for particular coder and sample message.
 */
public class Benchmark {
    /**
     * The sample message.
     */
    protected AbstractData message;
    /**
     * The coder to benchmark.
     */
    protected Coder coder;
    /**
     * The flag used to terminate the profiling loop after the specified
     * duration.
     */
    volatile boolean moreIterations = true;
    /**
     * The class represents the result of running the benchmark.
     */
    public static class Result
    {
        /**
         * The size of the encoded message (bytes).
         */
        int size;
        /**
         * The total time that was spent in encode (in milliseconds).
         */
        long t_encode;
        /**
         * The total time that was spent in decode (in milliseconds).
         */
        long t_decode;
        /*
         * The total number of encode operations executed by the benchmark.
         */
        long n_encode;
        /*
         * The total number of decode operations executed by the benchmark.
         */
        long n_decode;
        
        /**
         * Constructs the benchmark result from components.
         * 
         * @param size The size of the encoded message (bytes).
         * @param t_encode The total time that was spent in encode (in milliseconds).
         * @param t_decode The total time that was spent in decode (in milliseconds).
         * @param n_encode The total number of encode operations executed by the benchmark.
         * @param n_decode The total number of decode operations executed by the benchmark.
         */
        public Result(int size, long t_encode, long t_decode, 
                long n_encode, long n_decode)
        {
            this.size = size;
            this.t_encode = t_encode;
            this.t_decode = t_decode;
            this.n_encode = n_encode;
            this.n_decode = n_decode;
        }
        
        /**
         * 
         * @return The size of the encoded message (bytes).
         */
        public int messageSize()
        {
            return size;
        }
        
        /**
         *
         * @return The average time that was spent in encode (in milliseconds).
         */
        public double averageEncodeTime()
        {
            return ((double)t_encode)/((double)n_encode);
        }

        /**
         *
         * @return The average time that was spent in decode (in milliseconds).
         */
        public double averageDecodeTime()
        {
            return ((double)t_decode)/((double)n_decode);
        }

        /**
         * Prints the benchmark result.
         * 
         * @param out Specifies the output where the result is printed. 
         */
        public void print(PrintStream out) 
        {
            out.printf("Message size (bytes): %d\n", size);
            out.printf("encode() time   (ms): %f\n", averageEncodeTime());
            out.printf("decode() time   (ms): %f\n", averageDecodeTime());
            out.printf("elapsed time    (ms): %d\n", t_encode+t_decode);
        }
    }
    
    /**
     * The constructor.
     * 
     * @param c The coder for the benchmark.
     * @param v The sample message for the benchmark.
     */
    public Benchmark(Coder c, AbstractData v)
    {
        coder = c;
        message = (AbstractData)v.clone();
    }
    
    /**
     * Returns the description of coder selected for the benchmark.
     *
     * @return The description of the coder, 
     * like "Octet Encoding Rules (OER) Coder"
     */
    public String toString()
    {
        return coder.toString();
    }
    
    /**
     * Runs the benchmark. The benchmark includes the following steps: 
     * (1) - compute the size of encoded message; (2) - compute average time
     * of the encode() operation; (3) - compute average time of the decode()
     * operation. Steps (2) and (3) include the warmup and profiling phases.
     *  
     * @param warmup Specifies the number of iterations for the warmup phase.
     * @param duration Specifies the duration in milliseconds of the profiling
     * phase.
     * @return The object representing the result of this benchmark or null if
     * an error has occurred. 
     */
    public Result run(int warmup, int duration)
    {
        // Step 1. Compute the size of encoded message
        int size = -1;
        try {
            ByteBuffer enc = coder.encode(message);
            size = enc.position();
        } catch (Exception e) {
            logError("The encoder failed", e);
            return null;
        }
        // Create the timer to run encode/decode in a loop for the specified 
        // number of milliseconds.     
        Timer timer = new Timer();
        // Step 2. Compute the performance of the encoder
        // Use preallocated buffer for faster speed
        ByteBuffer enc = ByteBuffer.allocate(size);
        long t1 = 0, n_encode = 0; 
        moreIterations = true;
        while (moreIterations) {
            if (n_encode == warmup) {
                // Exit the warmup and proceed to the profiling phase
                scheduleLoopTermination(timer, duration);
                t1 = System.currentTimeMillis();
            }
            try {
                enc.position(0);
                coder.encode(message, enc);
            } catch (Exception e) {
                logError("The encoder failed", e);
                timer.cancel();
                return null;
            }
            ++n_encode;
        }
        long t2 = System.currentTimeMillis();
        // Step 3. Compute the performance of the decoder
        enc.flip();
        long t3 = 0, n_decode = 0; 
        moreIterations = true;
        while (moreIterations) {
            if (n_decode == warmup) {
                // Exit the warmup and proceed to the profiling phase
                scheduleLoopTermination(timer, duration);
                t3 = System.currentTimeMillis();
            }
            try {
                enc.position(0);
                coder.decode(enc, message);
            } catch (Exception e) {
                logError("The decoder failed", e);
                timer.cancel();
                return null;
            }
            ++n_decode;
        }
        long t4 = System.currentTimeMillis();
        timer.cancel();
        
        return new Result(size, t2-t1, t4-t3, n_encode-warmup, n_decode-warmup);
    }
    
    /**
     * Setup the timer to terminate the profiling loop.
     * 
     * @param t The timer object.
     * @param duration Time in milliseconds.
     */
    private void scheduleLoopTermination(Timer t, long duration)
    {
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                moreIterations = false;
            }}, duration);
    }
    
    /**
     * Log an error that occurred during the benchmark.
     * 
     * @param prefix The string identifying the failing component.
     * @param e The exception object representing an error.
     */
    private void logError(String prefix, Exception e)
    {
        System.err.printf("%s: %s\n", prefix, e);
        e.printStackTrace(System.err);
    }
    
    /**
     * The main method of the sample application.
     */
    public static void main(String[] args) {
        // The sample BasicSafetyMessage for the benchmark (BER-encoded).
        final byte[] bsm_ber_message = new byte[] {
            (byte) 0x30, (byte) 0x82, (byte) 0x02, (byte) 0x54, (byte) 0x80,
            (byte) 0x01, (byte) 0x02, (byte) 0x81, (byte) 0x26, (byte) 0x01,
            (byte) 0xC0, (byte) 0xA8, (byte) 0x01, (byte) 0x15, (byte) 0x4A,
            (byte) 0x38, (byte) 0x18, (byte) 0xBC, (byte) 0x4D, (byte) 0x4F,
            (byte) 0x21, (byte) 0xCB, (byte) 0x39, (byte) 0xED, (byte) 0xC1,
            (byte) 0x5B, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x2C, (byte) 0x8D, (byte) 0xB6,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x20,
            (byte) 0x89, (byte) 0x39, (byte) 0xA2, (byte) 0x82, (byte) 0x01,
            (byte) 0x76, (byte) 0x80, (byte) 0x01, (byte) 0x00, (byte) 0xA1,
            (byte) 0x82, (byte) 0x01, (byte) 0x5E, (byte) 0xA0, (byte) 0x3D,
            (byte) 0xA0, (byte) 0x14, (byte) 0x80, (byte) 0x02, (byte) 0x07,
            (byte) 0xDA, (byte) 0x81, (byte) 0x01, (byte) 0x01, (byte) 0x82,
            (byte) 0x01, (byte) 0x10, (byte) 0x83, (byte) 0x01, (byte) 0x15,
            (byte) 0x84, (byte) 0x01, (byte) 0x05, (byte) 0x85, (byte) 0x02,
            (byte) 0x75, (byte) 0x30, (byte) 0x81, (byte) 0x04, (byte) 0xCB,
            (byte) 0x21, (byte) 0x53, (byte) 0xF2, (byte) 0x82, (byte) 0x04,
            (byte) 0xF6, (byte) 0xC9, (byte) 0xAD, (byte) 0xF9, (byte) 0x83,
            (byte) 0x02, (byte) 0xBF, (byte) 0xBA, (byte) 0x84, (byte) 0x02,
            (byte) 0x2C, (byte) 0xB1, (byte) 0x85, (byte) 0x02, (byte) 0x00,
            (byte) 0x00, (byte) 0x86, (byte) 0x04, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x87, (byte) 0x01, (byte) 0x00,
            (byte) 0x88, (byte) 0x01, (byte) 0x00, (byte) 0x89, (byte) 0x01,
            (byte) 0x00, (byte) 0x82, (byte) 0x01, (byte) 0x17, (byte) 0xA3,
            (byte) 0x82, (byte) 0x01, (byte) 0x18, (byte) 0x82, (byte) 0x82,
            (byte) 0x01, (byte) 0x14, (byte) 0x00, (byte) 0x01, (byte) 0x02,
            (byte) 0x03, (byte) 0x04, (byte) 0x05, (byte) 0x06, (byte) 0x07,
            (byte) 0x08, (byte) 0x09, (byte) 0x0A, (byte) 0x0B, (byte) 0x0C,
            (byte) 0x0D, (byte) 0x0E, (byte) 0x0F, (byte) 0x10, (byte) 0x11,
            (byte) 0x12, (byte) 0x13, (byte) 0x14, (byte) 0x15, (byte) 0x16,
            (byte) 0x17, (byte) 0x18, (byte) 0x19, (byte) 0x1A, (byte) 0x1B,
            (byte) 0x1C, (byte) 0x1D, (byte) 0x1E, (byte) 0x1F, (byte) 0x20,
            (byte) 0x21, (byte) 0x22, (byte) 0x23, (byte) 0x24, (byte) 0x25,
            (byte) 0x26, (byte) 0x27, (byte) 0x28, (byte) 0x29, (byte) 0x2A,
            (byte) 0x2B, (byte) 0x2C, (byte) 0x2D, (byte) 0x2E, (byte) 0x2F,
            (byte) 0x30, (byte) 0x31, (byte) 0x32, (byte) 0x33, (byte) 0x34,
            (byte) 0x35, (byte) 0x36, (byte) 0x37, (byte) 0x38, (byte) 0x39,
            (byte) 0x3A, (byte) 0x3B, (byte) 0x3C, (byte) 0x3D, (byte) 0x3E,
            (byte) 0x3F, (byte) 0x40, (byte) 0x41, (byte) 0x42, (byte) 0x43,
            (byte) 0x44, (byte) 0x45, (byte) 0x46, (byte) 0x47, (byte) 0x48,
            (byte) 0x49, (byte) 0x4A, (byte) 0x4B, (byte) 0x4C, (byte) 0x4D,
            (byte) 0x4E, (byte) 0x4F, (byte) 0x50, (byte) 0x51, (byte) 0x52,
            (byte) 0x53, (byte) 0x54, (byte) 0x55, (byte) 0x56, (byte) 0x57,
            (byte) 0x58, (byte) 0x59, (byte) 0x5A, (byte) 0x5B, (byte) 0x5C,
            (byte) 0x5D, (byte) 0x5E, (byte) 0x5F, (byte) 0x60, (byte) 0x61,
            (byte) 0x62, (byte) 0x63, (byte) 0x64, (byte) 0x65, (byte) 0x66,
            (byte) 0x67, (byte) 0x68, (byte) 0x69, (byte) 0x6A, (byte) 0x6B,
            (byte) 0x6C, (byte) 0x6D, (byte) 0x6E, (byte) 0x6F, (byte) 0x70,
            (byte) 0x71, (byte) 0x72, (byte) 0x73, (byte) 0x74, (byte) 0x75,
            (byte) 0x76, (byte) 0x77, (byte) 0x78, (byte) 0x79, (byte) 0x7A,
            (byte) 0x7B, (byte) 0x7C, (byte) 0x7D, (byte) 0x7E, (byte) 0x7F,
            (byte) 0x80, (byte) 0x81, (byte) 0x82, (byte) 0x83, (byte) 0x84,
            (byte) 0x85, (byte) 0x86, (byte) 0x87, (byte) 0x88, (byte) 0x89,
            (byte) 0x8A, (byte) 0x8B, (byte) 0x8C, (byte) 0x8D, (byte) 0x8E,
            (byte) 0x8F, (byte) 0x90, (byte) 0x91, (byte) 0x92, (byte) 0x93,
            (byte) 0x94, (byte) 0x95, (byte) 0x96, (byte) 0x97, (byte) 0x98,
            (byte) 0x99, (byte) 0x9A, (byte) 0x9B, (byte) 0x9C, (byte) 0x9D,
            (byte) 0x9E, (byte) 0x9F, (byte) 0xA0, (byte) 0xA1, (byte) 0xA2,
            (byte) 0xA3, (byte) 0xA4, (byte) 0xA5, (byte) 0xA6, (byte) 0xA7,
            (byte) 0xA8, (byte) 0xA9, (byte) 0xAA, (byte) 0xAB, (byte) 0xAC,
            (byte) 0xAD, (byte) 0xAE, (byte) 0xAF, (byte) 0xB0, (byte) 0xB1,
            (byte) 0xB2, (byte) 0xB3, (byte) 0xB4, (byte) 0xB5, (byte) 0xB6,
            (byte) 0xB7, (byte) 0xB8, (byte) 0xB9, (byte) 0xBA, (byte) 0xBB,
            (byte) 0xBC, (byte) 0xBD, (byte) 0xBE, (byte) 0xBF, (byte) 0xC0,
            (byte) 0xC1, (byte) 0xC2, (byte) 0xC3, (byte) 0xC4, (byte) 0xC5,
            (byte) 0xC6, (byte) 0xC7, (byte) 0xC8, (byte) 0xC9, (byte) 0xCA,
            (byte) 0xCB, (byte) 0xCC, (byte) 0xCD, (byte) 0xCE, (byte) 0xCF,
            (byte) 0xD0, (byte) 0xD1, (byte) 0xD2, (byte) 0xD3, (byte) 0xD4,
            (byte) 0xD5, (byte) 0xD6, (byte) 0xD7, (byte) 0xD8, (byte) 0xD9,
            (byte) 0xDA, (byte) 0xDB, (byte) 0xDC, (byte) 0xDD, (byte) 0xDE,
            (byte) 0xDF, (byte) 0xE0, (byte) 0xE1, (byte) 0xE2, (byte) 0xE3,
            (byte) 0xE4, (byte) 0xE5, (byte) 0xE6, (byte) 0xE7, (byte) 0xE8,
            (byte) 0xE9, (byte) 0xEA, (byte) 0xEB, (byte) 0xEC, (byte) 0xED,
            (byte) 0xEE, (byte) 0xEF, (byte) 0xF0, (byte) 0xF1, (byte) 0xF2,
            (byte) 0xF3, (byte) 0xF4, (byte) 0xF5, (byte) 0xF6, (byte) 0xF7,
            (byte) 0xF8, (byte) 0xF9, (byte) 0xFA, (byte) 0xFB, (byte) 0xFC,
            (byte) 0xFD, (byte) 0xFE, (byte) 0xFF, (byte) 0x00, (byte) 0x01,
            (byte) 0x02, (byte) 0x03, (byte) 0x04, (byte) 0x05, (byte) 0x06,
            (byte) 0x07, (byte) 0x08, (byte) 0x09, (byte) 0x0A, (byte) 0x0B,
            (byte) 0x0C, (byte) 0x0D, (byte) 0x0E, (byte) 0x0F, (byte) 0x10,
            (byte) 0x11, (byte) 0x12, (byte) 0x13, (byte) 0xA2, (byte) 0x06,
            (byte) 0x80, (byte) 0x01, (byte) 0x00, (byte) 0x81, (byte) 0x01,
            (byte) 0x00, (byte) 0xA3, (byte) 0x07, (byte) 0x81, (byte) 0x05,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0xA3, (byte) 0x81, (byte) 0xAC, (byte) 0x80, (byte) 0x01,
            (byte) 0x00, (byte) 0xA2, (byte) 0x06, (byte) 0x80, (byte) 0x01,
            (byte) 0x00, (byte) 0x81, (byte) 0x01, (byte) 0x00, (byte) 0x83,
            (byte) 0x02, (byte) 0x00, (byte) 0x00, (byte) 0xAD, (byte) 0x3D,
            (byte) 0xA0, (byte) 0x14, (byte) 0x80, (byte) 0x02, (byte) 0x07,
            (byte) 0xDA, (byte) 0x81, (byte) 0x01, (byte) 0x01, (byte) 0x82,
            (byte) 0x01, (byte) 0x10, (byte) 0x83, (byte) 0x01, (byte) 0x15,
            (byte) 0x84, (byte) 0x01, (byte) 0x06, (byte) 0x85, (byte) 0x02,
            (byte) 0x79, (byte) 0x18, (byte) 0x81, (byte) 0x04, (byte) 0xB3,
            (byte) 0xD7, (byte) 0xEF, (byte) 0xBB, (byte) 0x82, (byte) 0x04,
            (byte) 0x1B, (byte) 0x83, (byte) 0xF2, (byte) 0x81, (byte) 0x83,
            (byte) 0x02, (byte) 0x4D, (byte) 0x7C, (byte) 0x84, (byte) 0x02,
            (byte) 0x61, (byte) 0x45, (byte) 0x85, (byte) 0x02, (byte) 0x00,
            (byte) 0x00, (byte) 0x86, (byte) 0x04, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x87, (byte) 0x01, (byte) 0x00,
            (byte) 0x88, (byte) 0x01, (byte) 0x00, (byte) 0x89, (byte) 0x01,
            (byte) 0x00, (byte) 0xB2, (byte) 0x5C, (byte) 0x80, (byte) 0x33,
            (byte) 0x41, (byte) 0x61, (byte) 0x42, (byte) 0x62, (byte) 0x43,
            (byte) 0x63, (byte) 0x44, (byte) 0x64, (byte) 0x45, (byte) 0x65,
            (byte) 0x46, (byte) 0x66, (byte) 0x47, (byte) 0x67, (byte) 0x48,
            (byte) 0x68, (byte) 0x49, (byte) 0x69, (byte) 0x4A, (byte) 0x6A,
            (byte) 0x4B, (byte) 0x6B, (byte) 0x4C, (byte) 0x6C, (byte) 0x4D,
            (byte) 0x6D, (byte) 0x4E, (byte) 0x6E, (byte) 0x4F, (byte) 0x6F,
            (byte) 0x50, (byte) 0x70, (byte) 0x51, (byte) 0x71, (byte) 0x52,
            (byte) 0x72, (byte) 0x53, (byte) 0x73, (byte) 0x54, (byte) 0x74,
            (byte) 0x55, (byte) 0x75, (byte) 0x56, (byte) 0x76, (byte) 0x57,
            (byte) 0x77, (byte) 0x58, (byte) 0x78, (byte) 0x59, (byte) 0x79,
            (byte) 0x5A, (byte) 0x81, (byte) 0x05, (byte) 0x41, (byte) 0x61,
            (byte) 0x42, (byte) 0x62, (byte) 0x43, (byte) 0x82, (byte) 0x15,
            (byte) 0x41, (byte) 0x61, (byte) 0x42, (byte) 0x62, (byte) 0x43,
            (byte) 0x63, (byte) 0x44, (byte) 0x64, (byte) 0x45, (byte) 0x65,
            (byte) 0x46, (byte) 0x66, (byte) 0x47, (byte) 0x67, (byte) 0x48,
            (byte) 0x68, (byte) 0x49, (byte) 0x69, (byte) 0x4A, (byte) 0x6A,
            (byte) 0x4B, (byte) 0x83, (byte) 0x04, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x84, (byte) 0x01, (byte) 0x02
        };
	
	// Initialize the project
	try {
	    J2735.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

        // Load the sample BasicSafetyMessage
        BasicSafetyMessage message = makeMessage(J2735.getBERCoder(), 
            bsm_ber_message);

        if (message != null) {
            // The  number of iterations for the warmup phase
            int warmup = 100000;
            // The duration of profiling in milliseconds
            int duration = 5000;
 
            System.out.printf("Loaded the sample message:\n %s\n", message);
            // Create the set of benchmarks. It includes OER, BASIC-PER (ALIGNED)
            // and BER
            Benchmark[] benchmarks = new Benchmark[] {
                new Benchmark(configureCoder(J2735.getOERCoder()), message),
                new Benchmark(configureCoder(J2735.getPERAlignedCoder()), message),
                new Benchmark(configureCoder(J2735.getPERUnalignedCoder()), message),
                new Benchmark(configureCoder(J2735.getBERCoder()), message)
            };
            // Run benchmarks
            for (Benchmark b:benchmarks) {
                System.out.printf("Running %s ...\n", b);
                Result r = b.run(warmup, duration);
                if (r != null) {
                    r.print(System.out);
                }
            }
         }
    }
    /**
     * Create Java object representing the BasicSafetyMessage from the
     * encoding.
     */
    private static BasicSafetyMessage makeMessage(Coder c, byte[] encoding)
    {
        try {
            ByteBuffer source = ByteBuffer.wrap(encoding);
            return 
                (BasicSafetyMessage)c.decode(source, new BasicSafetyMessage());
        } catch (Exception e) {
            System.out.printf("Unable to load the sample message: %s\n", e);
            e.printStackTrace(System.out);
            return null;
        }
    }

    /**
     * Configure the coder for fastest performance.
     */
    private static Coder configureCoder(Coder c)
    {
        c.disableEncoderConstraints();
        c.disableDecoderConstraints();
        c.disableEncoderDebugging();
        c.disableDecoderDebugging();
        c.enableAutomaticDecoding();
        c.enableAutomaticEncoding();
        
        return c;
    }
}
