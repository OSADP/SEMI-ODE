/*************************************************************/
/* Copyright (C) 2014 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)Tperf.java	16.3 14/02/08 */
/* Prepared by OSS Nokalva, Inc.  */

/* Application Program: Tperf.java

    The performance test sample illustrates a way to measure the runtime 
    performance of the coder.encode() and coder.decode() methods
    The program takes a binary or XML message, decodes it in a loop while 
    collecting execution time statistics, and then reencodes it back, again 
    measuring the execution time. 
*/
 
/* Compiler-generated classes */
import asn1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.Benchmark;
import com.oss.util.HexTool;

/* Java I/O classes */
import java.io.*;
import java.util.Properties;


public class Tperf {

    public static void main(String[] args)
    {
	// Read configuration settings from the 'benchmark.properties' file
	Properties settings = new Properties();
	try {
	    FileInputStream bpf = new FileInputStream("benchmark.properties");
	    settings.load(bpf);
	    bpf.close();
	} catch (IOException e) {
	    System.out.println("Unable to read 'benchmark.properties' file: " + e);
	}

	// Command-line arguments override settings in the benchmark.properties
	for (int i = 0; i < args.length; i++) {
	    int eqpos = args[i].indexOf('=');
	    if (eqpos > 0 && eqpos < args[i].length() - 1) {
		settings.setProperty(args[i].substring(0, eqpos), args[i].substring(eqpos + 1));
	    } else {
		System.out.println("Unexpected argument '" + args[i] + "'");
		System.exit(2);
	    }
	}	

	// Read the name of the file containing test messages
	String testData = settings.getProperty("benchmark.data");
	if (testData == null) {
	    System.out.println("The 'benchmark.data' property is missing.");
	    System.out.println(
		"This setting specifies the location of the file containing test messages.");
	    System.out.println("Loading test message from 'message.bin' file");
	    testData = "message.bin";
	}

	// Initialize the project
	try {
	    Asn1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization error: " + e);
	    System.exit(1);
	}
	
	Coder coder = Asn1.getDefaultCoder();
        // Enable automatic encode/decode. Information object set lookups
        // are done if automatic decoding of open types is enabled 
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	// Determine the type of the test messages
	String messageType = settings.getProperty("benchmark.oss.message.type");
	if (messageType == null) {
	    System.out.println("The 'benchmark.oss.message.type' property is missing.");
	    System.exit(1);
	}

	// Split qualified name to package name and class name
	int separator = messageType.lastIndexOf('.');
	if (separator == -1) {
	    System.out.println("The 'benchmark.oss.message.type' should specify qualified name.");
	    System.exit(1);
	}

	ASN1Type asn1Type = new ASN1Type(messageType.substring(0, separator),
				         messageType.substring(separator+1));
	// Verify that benchmark.oss.message.type specifies the name of 
	// valid Java class that is subclass of AbstractData
	try {
	    asn1Type.getTypeInfo();
	} catch (Exception e) {
	    System.out.println(
	    "The 'benchmark.oss.message.type' specifies invalid Java class: " + e);
	    System.exit(1);
	}

	// Decode the value from the "message.bin" file
	System.out.println("Loading test message...");
	AbstractData data = null;
	try {
	    FileInputStream source = new FileInputStream(testData);
	    data = coder.decode(source, asn1Type);
	    source.close();
	    System.out.println("Message loaded.");
	    System.out.println("Data " + data);	    
	} catch (DecodeFailedException e) {
	    System.out.println("Decoder exception: " + e);
	} catch (DecodeNotSupportedException e) {
		System.out.println("Decoder exception: " + e);
	} catch (IOException e) {
	    System.out.println("I/O exception: " + e);
	    System.exit(1);
	}

	// Constructs the testcase providing the Coder object that will
	// perform encoding and decoding.
	Benchmark bench = new Benchmark(data, coder);

	String name = null;
	// Read the time to warmup the JVM
	try {
	    name = "benchmark.warmup";
	    int warmup = getIntProperty(settings, name);
	    if (warmup > 0)
		bench.setWarmupTime(warmup);
	} catch (NumberFormatException e) {
	    System.out.println("Invalid setting for '" + name +
			    "'. A number is expected. Default setting is used");
	}

	// Read the  current setting for the sampling interval
	try {
	    name = "benchmark.sampling";
	    int sampling = getIntProperty(settings, name);
	    if (sampling > 0)
		bench.setSamplingTime(sampling);
	} catch (NumberFormatException e) {
	    System.out.println("Invalid setting for '" + name +
			    "'. A number is expected. Default setting is used");
	}


	System.out.println("Warmup   time is " + bench.warmupTime() + " msec.");
	System.out.println("Sampling time is " + bench.samplingTime() + " msec.");
	// Run the encoder and decoder performance tests
	bench.run();

	java.lang.Exception e = bench.encodeExitStatus();
	if (e != null)
    	    System.out.println("Encoder exception: " + e);

	e = bench.decodeExitStatus();
	if (e != null)
    	    System.out.println("Decoder exception: " + e);
	
	int count = (int)(1/bench.averageEncodeTiming());
	System.out.println("Average encode time is " + (float)bench.averageEncodeTiming() 
			    + " sec. (" + count + " encodes per sec.)");
	count = (int)(1/bench.averageDecodeTiming());
        System.out.println("Average decode time is " + (float)bench.averageDecodeTiming()
			    + " sec. (" + count + " decodes per sec.)");

	Asn1.deinitialize();
    }

    /**
     * The helper method to get a value of numeric property from the
     * property list.
     * 
     * @param settins - the property list.
     * @param name - the name that identifies the numeric property.
     * @exception NumberFormatException if the setting of the property is not a
     *	valid number.
     */
    protected static int getIntProperty(Properties settings, String name) 
	throws NumberFormatException
    {
	String decimal = settings.getProperty(name);
	int value = 0;
	if (decimal != null)
		value = Integer.parseInt(decimal);
	if (value < 1)
	    System.out.println("Invalid setting for '" + name + 
			"'. A positive number is expected. Default setting is used");
	return value;
    }
}
