#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	16.6 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLDC_HOME and
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh
LANG=C              # Circumvent CLDC 1.1's preverify crash on Linux

case ${ACTION} in
    "cleanup")
	rm -fr build classes
	rm -f *.log
	break;;
	
    "javac")
	CURDIR=`pwd`
	CLASSPATH=$CURDIR/build:$OSS_ASN1_JAVA/lib/ossmicro.jar; export CLASSPATH

	# Check for environment sanity
        if [ -z "$CLDC_HOME" ] || [ -z "$OSS_ASN1_JAVA" ]; then
	    echo "Please make sure that OSS_ASN1_JAVA and CLDC_HOME environment variables"
	    echo "are set prior to running the CLDC samples."
	    exit 1
	fi
	type $KVM $PREVERIFY > /dev/null 2>&1
	if [ $? -ne 0 ]; then
	    echo "Please make sure that $KVM and $PREVERIFY executables are in your PATH."
	    exit 2
	fi

	# Compile the csample.asn abstract syntax and run the Tcsample

	echo "----- Compiling the csample.asn specification -----"
	rm -rf build classes
	mkdir build
	$ASN1 $COMMON_ASN1_OPTIONS csample -microedition -path build -err compile.log
	if [ $? -eq 0 ]; then 
	    cd build/csample
	    echo "----- Compiling generated classes -----"
	    echo "--Sun's CLDC 1.1 reference implementation is not compatible with JDK 1.5 or later.--"
	    echo "--If you encounter compilation errors when running this sample, please use JDK 1.3 or 1.4.--"
	    sh csample.sh "$JAVAC -source 1.4 -target 1.4 -bootclasspath $CLDC_CLASSES $JFLAGS" 2>&1 >> ../../compile.log
	    cd ..
	    cp ../Tcsample.java .
	    $JAVAC -source 1.4 -target 1.4 -bootclasspath $CLDC_CLASSES $JFLAGS -g Tcsample.java 2>&1 >> ../compile.log
	    if [ -f Tcsample.class ]; then
		echo "----- Preverifying the Tcsample sample -----";
		cd ..
		$PREVERIFY -classpath $CLASSPATH:$CLDC_CLASSES -d classes build 2>&1 >> compile.log
		if [ $? -eq 0 ]; then
		    cd classes
		    echo "----- Running the Tcsample sample -----";
		    $KVM -classpath .:$OSS_ASN1_JAVA/lib/ossmicro.jar:$CLDC_CLASSES $COMMON_KVM_OPTIONS Tcsample;
		    cd ..
		fi
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac
