/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Agent.java	16.3 14/02/08
 */

/*
 * Demonstrates a sample of CMIP protocol exchange:
 * the agent receives an M-GET request from the manager and forms a GetResult reply.
 * Interaction between the manager and agent is emulated only - the agent decodes
 * the M-GET request from a predefined buffer as if it were just received from the
 * manager.
 */


import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;
import com.oss.util.BadTimeFormatException;
   
import cmip.*;
import cmip.cmip_1.*;
import cmip.cmip_sample.*;
import cmip.remote_operations_generic_ros_pdus.*;
import cmip.remote_operations_information_objects.*;

public class Agent {

    /* Predefined M-GET requests message as if it were received from the manager */
    static byte request[] = new byte[] {
    (byte)0x10, (byte)0x01, (byte)0x0A, (byte)0x00, (byte)0x01, (byte)0x03, (byte)0x12, (byte)0x04,
    (byte)0x06, (byte)0x2B, (byte)0x06, (byte)0x01, (byte)0x02, (byte)0x01, (byte)0x04, (byte)0x00,
    (byte)0x01, (byte)0x00, (byte)0x02, (byte)0x80, (byte)0x01, (byte)0x04, (byte)0x80, (byte)0x01,
    (byte)0x05
    };

    static InvokeId        mget_invokeId;
    static Code            mget_opcode;
    static ObjectClass     mget_inv_arg_baseManagedObjectClass;
    static ObjectInstance  mget_inv_arg_baseManagedObjectInstance;
    static GetArgument.AttributeIdList mget_atids;

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Cmip.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Cmip.getPERAlignedCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	System.out.println("Original PER-encoded PDU...\n");
	HexTool.printHex(request);
	System.out.println("\nDecoding...");

	ByteArrayInputStream source = new ByteArrayInputStream(request);

	/*
	 * Decode the PDU.
	 */
	ROSEapdus reqmsg = null;

	try {
	    reqmsg = (ROSEapdus)
		coder.decode(source, new ROSEapdus());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(reqmsg);
	
	System.out.println("\n----- Processing request PDU from the manager -----");
	analyze_request(reqmsg);

	System.out.println("\n----- Forming and encoding M-GET reply -----");
	
        /*
         * Create reply
         */
	ROSEapdus replymsg = fill_mget_reply();

	System.out.println("\nPDU for encoding...\n");
	System.out.println(replymsg);
	System.out.println("\nEncoding...");

	CMIP_1.attributeSet.addElement(CMIP_Sample.attribute1);
	CMIP_1.attributeSet.addElement(CMIP_Sample.attribute2);

	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(replymsg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);
	
    }

    static ROSEapdus fill_mget_reply()
    {
	ROSEapdus pdu = new ROSEapdus();
	GetResult getres = new GetResult();
	
	/* ManagedObject definitions are moved from request: */
	getres.setManagedObjectClass(mget_inv_arg_baseManagedObjectClass);
	getres.setManagedObjectInstance(mget_inv_arg_baseManagedObjectInstance);
	
	fill_mget_result(getres);
	
	OpenType ogetres = new OpenType(getres);
	ReturnResult.Result resres = new ReturnResult.Result(mget_opcode, ogetres);

	ReturnResult res = new ReturnResult(mget_invokeId, resres);
	
	pdu.setReturnResult(res);
	return (ROSEapdus)pdu;    
    }

    static void fill_mget_result(GetResult res)
    {	
	int attrValues[] = {0, 2};
    
	try {
	    res.setCurrentTime(new GeneralizedTime("20020821222541.987Z"));
	} catch (BadTimeFormatException e) {
	    // Parser detected that string has invalid format
	    System.out.println("Bad time value: " + e.getMessage());
	}

	GetResult.AttributeList attributes = new GetResult.AttributeList();
	res.setAttributeList(attributes);

        for (int i = 0; i < mget_atids.getSize(); i++)
        {
	    AttributeId attrid = (AttributeId) mget_atids.get(i).clone();
	    AttributeValueType val;

    	    if (i < attrValues.length)
        	val = new AttributeValueType(attrValues[i]);
    	    else
        	val = new AttributeValueType(0);

	    OpenType oval = new OpenType(val);
	    
    	    Attribute attr = new Attribute(attrid, oval);
    	    attributes.add(attr);
        }
    }

    /* Demonstrates how to access fields of decoded ROS type */
    static void analyze_request(ROS req)
    {
	switch (req.getChosenFlag()) {
	    case ROS.invoke_chosen:
    		analyze_invoke((Invoke)req.getChosenValue());
    		break;
	    case ROS.returnResult_chosen:
	    case ROS.returnError_chosen:
	    case ROS.reject_chosen:
	        break;
	    default:
	}
    }

    /* Demonstrates how to access fields of decoded Invoke type */
    static void analyze_invoke(Invoke inv)
    {
	switch (inv.getInvokeId().getChosenFlag()) {
	    case InvokeId.present_chosen:
		INTEGER invokeId_present = (INTEGER)inv.getInvokeId().getChosenValue();
    		mget_invokeId = InvokeId.createInvokeIdWithPresent(invokeId_present); 
    		break;
	    case InvokeId.absent_chosen:
    		break;
	    default:
	}

	switch (inv.getOpcode().getChosenFlag()) {
	    case Code.local_chosen:
		INTEGER opcode = (INTEGER) inv.getOpcode().getChosenValue();
		mget_opcode = Code.createCodeWithLocal(opcode);
	}

	analyze_OpenType(inv.getArgument());
    }
    
    /* Demonstrates how to access fields of decoded OpenType */
    static void analyze_OpenType(OpenType otp)
    {
	if (otp.getDecodedValue() != null) {
	    if (otp.getDecodedValue() instanceof GetArgument)
		analyze_mget((GetArgument)otp.getDecodedValue());
	}    
    }

    /* Demonstrates how to access fields of decoded GetArgument */
    static void analyze_mget(GetArgument garg)
    {
	ObjectClass objcls = garg.getBaseManagedObjectClass();
	switch (objcls.getChosenFlag()) {
	    case ObjectClass.globalForm_chosen:
		mget_inv_arg_baseManagedObjectClass = (ObjectClass)objcls.clone();
	}
	
	ObjectInstance objinst = garg.getBaseManagedObjectInstance();
	switch (objinst.getChosenFlag()) {
	    case ObjectInstance.distinguishedName_chosen:
		analyze_distinguishedName((DistinguishedName)objinst.getChosenValue());
	}
	
	if (garg.getAttributeIdList() != null) {
	    mget_atids = garg.getAttributeIdList();
	}
    }
    
    /* Demonstrates how to access fields of decoded DistinguishedName type */
    static void analyze_distinguishedName(DistinguishedName dname)
    {	
	DistinguishedName clone_dname = new DistinguishedName();
	mget_inv_arg_baseManagedObjectInstance =
		ObjectInstance.createObjectInstanceWithDistinguishedName(clone_dname);
	
        for (int i = 0; i < dname.getSize(); i++)
        {
	    RelativeDistinguishedName rel_dis_name = dname.get(i);
    	    RelativeDistinguishedName clone_rel_dis_name = new RelativeDistinguishedName();
    	    for (int j = 0; j < rel_dis_name.getSize(); j++)
    	    {
    		AttributeValueAssertion att_val_ass = 
    		    (AttributeValueAssertion)rel_dis_name.get(j).clone();
    		clone_rel_dis_name.add(att_val_ass);
    	    }
    	    clone_dname.add(clone_rel_dis_name);
	}    
    }    
}
