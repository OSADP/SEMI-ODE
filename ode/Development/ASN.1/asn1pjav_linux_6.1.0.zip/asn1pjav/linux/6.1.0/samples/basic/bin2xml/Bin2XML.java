/*
 * Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)Bin2XML.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.  */

/**
    Application program Bin2XML.java
    Demonstrates PER-->XML conversion.
*/

/* To run the program:

asn1pjav product.asn -exer -per
cd product
product.bat javac
cd ..
javac -g Bin2XML.java
java Bin2XML

If you experience difficulties running or compiling this program, carefully read
through the Installing section of the quickstart.html guide in the doc/guide
directory of your shipment. If that doesn't help contact support@oss.com. Be
sure to submit your license number, as well as a description of the problem.
*/

/* main() shows how to convert PER-->XML */

/* Compiler-generated classes */
import product.*;
import product.productinfo.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Bin2XML {

    /**
     * Constructor.
     */
    public Bin2XML () {
    }

    public static void main(String args[]) {

	// Parse the command line options.
	if (args.length != 2) {
	    System.out.println("Usage: java Bin2XML <src>.bin <dest>.xml\n");
	    System.exit(1);
	}

	// Initialize the project
	try {
	    product.Product.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Initialize Binary2XMLConvertor to perform PER-->XML
	Binary2XMLConvertor convertor = new Binary2XMLConvertor(
	    product.Product.getPERAlignedCoder(),
	    product.Product.getEXERCoder()
	);

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    convertor.disableDecoderConstraints();
	    convertor.disableEncoderConstraints();
	    convertor.enableRelaxedDecoding();
	}

	System.out.println("Printing the original PER-encoded message...\n");
	printFile(args[0], true);

	System.out.println("\nEncoding using XML (Extended XER)...\n");
	try {
	    FileInputStream source = new FileInputStream(args[0]);
	    FileOutputStream sink  = new FileOutputStream(args[1]);

	    convertor.convert(source, sink, new ProductList());
	    source.close();
	    sink.close();

	} catch (IOException e) {
	    System.out.println("IO exception: " + e);
	    System.exit(3);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	    System.exit(4);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoder exception: " + e);
	    System.exit(4);
	}
	System.out.println("Converted successfully.");
	System.out.println("\nPrinting the XML encoded message...\n");
	printFile(args[1], false);
    }

    // Prints file contents to System.out
    static void printFile(String fname, boolean hex) {
	File file = new File(fname);

	int length = (int)file.length();
	byte[] buf = new byte[length];

	try {
	    FileInputStream source = new FileInputStream(file);

	    for (int i = 0; i < length; i++)
		buf[i] = (byte)source.read();
	    source.close();
	} catch (IOException e) {
	    System.out.println("IO exception: " + e);
	    System.exit(2);
	}

	if (hex)
	    HexTool.printHex(buf);
	else {
	    System.out.write(buf, 0, length);
	    System.out.println("");
	}
    }
}
