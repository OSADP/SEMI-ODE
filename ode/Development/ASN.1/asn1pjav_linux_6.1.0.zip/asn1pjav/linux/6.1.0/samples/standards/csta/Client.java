/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Client.java	16.3 14/02/08
 */

/*
 * Demonstrates a sample of CSTA protocol exchange:
 * the client creats makeCall request using the MakeCallArgument PDU and
 * sends it to the service. The service sends a response using a MakeCallResult
 * PDU back to the client.
 * Interaction between the service and client is bi-directional and requires
 * TCP/IP or some other form of connection. In this example it is emulated:
 * the client decodes a predefined MakeCallResult message as if it were just
 * received from the service.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import csta.*;
import csta.header.*;
import csta.remote_operations_generic_ros_pdus.*;
import csta.remote_operations_information_objects.*;
import csta.csta_make_call.*;
import csta.csta_device_identifiers.*;

public class Client {

/*
 * Predefined MakeCallResult reply message as if it were received from
 * the service.
 */
    static byte reply[] = new byte[] {
    (byte)0xA2, (byte)0x24, (byte)0x02, (byte)0x01, (byte)0x06, (byte)0x30, 
    (byte)0x1F, (byte)0x02, (byte)0x01, (byte)0x0A, (byte)0x30, (byte)0x1A,
    (byte)0x6B, (byte)0x18, (byte)0x30, (byte)0x16, (byte)0x80, (byte)0x04, 
    (byte)0x41, (byte)0x42, (byte)0x43, (byte)0x44, (byte)0xA1, (byte)0x0E,
    (byte)0x30, (byte)0x0C, (byte)0x80, (byte)0x0A, (byte)0x37, (byte)0x33, 
    (byte)0x32, (byte)0x33, (byte)0x30, (byte)0x32, (byte)0x39, (byte)0x36,
    (byte)0x36, (byte)0x39
};

    public static void main(String[] args) {

	/* Sending message */
	// Initialize the project
	try {
	    Csta.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Csta.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	
	AbstractData msg = fill_MakeCall_Request();
	System.out.println("\nPDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);
	
	/* Reseiving response */
	
	System.out.println("Original BER-encoded PDU...\n");
	HexTool.printHex(reply);
	System.out.println("\nDecoding...");

	ByteArrayInputStream source = new ByteArrayInputStream(reply);

	/*
	 * Decode the PDU.
	 */
	msg = null;
	try {
	    msg = (ROSHeader)
		coder.decode(source, new ROSHeader());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(msg);	
    }

    /*
     * Construct makeCall request.
     */
    static ROSHeader fill_MakeCall_Request()
    {
	/* Allocate top-level object for the message */
	ROSHeader pdu = new ROSHeader();
	
	Invoke invoke = new Invoke(); 
	
	/* this is an Invoke request */
	pdu.setInvoke(invoke);

	/* invokeId */
	InvokeId invoke_id = new InvokeId();
	invoke_id.setPresent(6);
	invoke.setInvokeId(invoke_id);
	/* Note: linkedId is left uninitialized */

	/* opcode */
	Code invoke_opcode = new Code();
	invoke_opcode.setLocal(10 /*makeCall*/);
	invoke.setOpcode(invoke_opcode);

	/* argument */
	fill_mc_argument(invoke);

	return (ROSHeader)pdu;
    }

    /* Construct Invoke arguments */
    static void fill_mc_argument(Invoke invoke)
    {
	/* create the number */
	NumberDigits dnumber = new NumberDigits("7323029669");

	/* set the DeviceID with dialingNumber for callingDevice */
	DeviceID.DeviceIdentifier calling_id =
	    DeviceID.DeviceIdentifier.createDeviceIdentifierWithDialingNumber(dnumber);

        /* set callingDevice for the argument by creating new DeviceID */
	DeviceID callingdev = new DeviceID(calling_id);

	/* set the value of DeviceID for calledDirectoryNumber */
	DeviceID.DeviceIdentifier called_id = 
	    DeviceID.DeviceIdentifier.createDeviceIdentifierWithDeviceNumber(12345);
	DeviceID calleddev = new DeviceID(called_id);
	
	MakeCallArgument getarg = new MakeCallArgument(callingdev, calleddev);

	OpenType invarg = new OpenType(getarg);
	
	invoke.setArgument(invarg);
    }
}
