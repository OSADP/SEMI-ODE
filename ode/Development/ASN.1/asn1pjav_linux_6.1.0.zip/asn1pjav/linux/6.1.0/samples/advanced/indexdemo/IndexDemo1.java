/*
 * Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)IndexDemo1.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program IndexDemo1.java
    Demonstrates OSS ASN.1/Java Tools API for indexing information
    object sets. This demo uses DefaultIndex implementation of an
    index.
*/

/* To run the program:

asn1pjav index1.asn -indexinfoobjectsets
cd index1
index1.bat javac
cd ..
javac -g IndexDemo1.java
java IndexDemo1

If you experience difficulties running or compiling this program, carefully
read through the Installing section of the quickstart.html guide in the
doc/guide directory of your shipment. If that doesn't help contact
support@oss.com. Be sure to submit your license number, as well as a
description of the problem.
*/

/* main() shows how to index information object sets  */
/*    using OSS provided DefaultIndex implementation. */
/*    The IndexDemo1 encodes a value of Procedure     */
/*    type which uses component relation constraint.  */
/*    Decoding the value with automatic decoding      */
/*    feature enabled requires lookup in the info     */
/*    object set which is used in the component       */
/*    relation constraint. The demo program compares  */
/*    decode performance with and without using       */
/*    index.                                          */

/* Compiler-generated classes */
import index1.*;
import index1.ind1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;
import java.util.*;


public class IndexDemo1 {

    private static int LOOP_COUNT = 10000;


    public static void main(String args[]) {

	// Initialize the project
	try {
	    Index1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

        // Use default coder to encode/decode 'proc' value from 'Ind1' module
	Coder coder = Index1.getDefaultCoder();
        AbstractData data = Ind1.proc;

        // Enable automatic encode/decode. Information object set lookups
        // are done if automatic decoding of open types is enabled 
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

        // Disable utility code to get clean performance figures
	coder.enableEncoderDebugging();
        coder.disableDecoderDebugging();
        coder.disableDecoderConstraints();
        coder.disableEncoderConstraints();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	try {
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();

	    // Print the input to the encoder
	    System.out.println("\nThe input to the encoder\n");
	    System.out.println(data);

	    // Encode sample value
	    System.out.println("\nThe encoder's trace messages ...");
	    coder.encode(data, sink);

	    // Extract the encoding from the sink stream
	    byte[] encoding = sink.toByteArray();

	    // Print the encoding using the HexTool utility
	    System.out.println("Value encoded into " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);

            // Prepare to decode without indexing information object set.

            // We use custom Input stream as decoder source. The stream
            // extends ByteArrayInputStream and allows fast repositioning
            // to the beginning of the stream with reread() method.
	    Procedure newProc = new Procedure(); // create type for expected value
	    InputStream source = new Input(encoding);
	    AbstractData decoded = null;

            // Decode without indexing
	    System.out.println("\nDecode " + LOOP_COUNT + " times without using an index");
	    long elapsed = System.currentTimeMillis();
	    try {
		for (int i = 0; i < LOOP_COUNT; i++) {
		    ((Input)source).reread();
		    decoded = coder.decode(source, newProc);
		}
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decode not supported.");
		return;
	    } catch (DecodeFailedException e) {
		System.out.println("Decode failed.");
		System.out.println("Error code: " + e.getReason());
		System.out.println(e);
		return;
	    }

            // Report elapsed time and print decoded value
	    elapsed = System.currentTimeMillis() - elapsed;
	    System.out.println("\nDone in " + elapsed + " millis");
	    System.out.println("\n\tDecoded PDU...\n");
	    System.out.println(decoded);

	    // Index the KNOWN-PARAMETERS information object set
	    // using anonymous inner class which extends DefaultIndex
          // the mapping used is the integer value of the key since it 
          // is in strictly increasing sequential order.
	    index1.ind1.Ind1.kNOWN_PARAMETERS.indexById(
                new DefaultIndex() {
                    public int mapKey(AbstractData key) {
                        return ((INTEGER)key).intValue();
                    }
                }
	     );

	    System.out.println("\nDecode " + LOOP_COUNT + " times using DefaultIndex");
	    elapsed = System.currentTimeMillis();
	    try {
		for (int i = 0; i < LOOP_COUNT; i++) {
		    ((Input)source).reread();
		    decoded = coder.decode(source, newProc);
		}
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decode not supported.");
		return;
	    } catch (DecodeFailedException e) {
		System.out.println("Decode failed.");
		System.out.println("Error code: " + e.getReason());
		System.out.println(e);
		return;
	    }

            // Report elapsed time and print decoded value
	    elapsed = System.currentTimeMillis() - elapsed;
	    System.out.println("\nDone in " + elapsed + " millis");
	    System.out.println("\n\tDecoded PDU...\n");
	    System.out.println(decoded);


	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}
    }


    /* The Input class extends ByteArrayInputStream */
    /* It allows fast repositioning of the stream to the */
    /* beginning with reread() method */

    static class Input extends ByteArrayInputStream {

	Input(byte[] b)
	{
	    super(b);
	}

	void reread()
	{
	    pos = 0;
	}

    }

}
