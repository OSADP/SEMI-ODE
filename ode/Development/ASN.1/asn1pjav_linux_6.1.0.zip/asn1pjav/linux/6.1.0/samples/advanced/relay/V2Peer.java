/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)V2Peer.java	16.3 14/02/08 */
/*
 * This example--see also V1Peer.java--demonstrates interoperation of two
 * peers that use different versions of the same extensible ASN.1 type.
 * It demonstrates the ability of the version-1 peer to safely relay the
 * extension additions added by the version-2 peer. In order to work
 * properly, the definitions in relay.asn should be compiled with the
 * -relaySafe command line option.  Also, since this sample uses PER,
 * the -per command line option should be also specified when ASN.1-compiling.
 *
 * To run the program say:
 *
 * asn1pjav -per -relay relay.asn
 * cd relay
 * relay.bat javac
 * cd ..
 * javac -g *.java
 * java TV2Peer
 */

/*
    V2Peer uses the following abstract syntax:

Transport-v2 DEFINITIONS AUTOMATIC TAGS ::= BEGIN
    Transport-ID ::= ENUMERATED {ipx, ip, ..., ip6}
    Address ::= CHOICE {
	iPXAddress	SEQUENCE
	{
	    node OCTET STRING (SIZE(6)),
	    netnum OCTET STRING (SIZE(4))
	},
	iPAddress SEQUENCE
	{
	    network OCTET STRING (SIZE(4))
	},
	...,
	iP6Address SEQUENCE
	{
	    network OCTET STRING (SIZE(16))
	}
    }
    Preferences ::= SEQUENCE {
	preferred-transport Transport-ID,
	address Address,
	...,
	supported-transports SEQUENCE OF SEQUENCE {
	    id Transport-ID,
	    address Address
	}
    }
    Route ::= SEQUENCE OF IA5String
    Envelope ::= SEQUENCE {
	route Route,
	data Preferences
    }
END

Note that version 2 defines the extra enumerator "ip6", an extra
alternative in "Address" (iP6Address), and the extra "supported-transports"
extension addition in "Preferences".

The main() method does the following:

1. Initializes the project and creates PER aligned coder
2. Instantiates the V2Peer and instructs it to encode the value of
   Envelope, using the type definitions from the version 2 of the protocol.
3. Instantiates the V1Peer that simulates the version 1 peer, and instructs
   V1Peer to relay (decode, modify and re-encode) the PDU object that was
   received from V2Peer.
4. Demonstrates that all the version-2 extensions were preserved in transit
   through V1Peer.  Note that no special code is required to relay the unknown
   extensions saved by the decoder (the encoder does it automatically).
5. Additionally, the code demonstrates how V1Peer can optionally process
   unknown extension additions in the message received.  For example, it can
   replace the unknown enumerator or unknown CHOICE alternative with a known
   one, or it can discard all unknown extension additions from the value of
   the SEQUENCE.
*/


/* Compiler-generated classes */
import relay.*;
import relay.transport_v2.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class V2Peer {

    public static void main(String args[])
    {

		//
		// Initialize the project.
		//
	try {
	    Relay.initialize();
	}
	catch (Exception e) {
	    System.out.println("Initialization failed with exception: " + e);
	    System.exit(1);
	}
		//
		// Instantiate the coder and the peers.
		//
	Coder coder = Relay.getPERAlignedCoder();
		//
		// The second parameter as "false" instructs V1Peer to avoid
		// optional processing of unknown extensions and simply relay
		// them.
		//
	V1Peer v1Peer = new V1Peer(coder, false);
	V2Peer v2Peer = new V2Peer(coder);
	try {
		//
		// Encode the sample value of Envelope and pass the encoded
		// message to V1Peer.
		//
	    byte[] encoding = v2Peer.send(Transport_v2.packet);
	    if (encoding == null)
		return;
	    System.out.println("\nV2Peer relaying the encoded Envelope PDU object...");
		//
		// Activate V1Peer and instruct it to relay the message
		// received from V2Peer.
		//
	    byte[] relayed_encoding = v1Peer.relay(encoding);
	    if (relayed_encoding != null)
		v2Peer.receive(relayed_encoding);
		//
		// Create another V1Peer and instruct it to process the unknown
		// extension additions.
		//
	    System.out.println("\nV2Peer relaying the encoded PDU with the unknown additions discarded...");
	    v1Peer = new V1Peer(coder, true);
		//
		// Relay the message through the V1Peer once again. This time
		// the V1Peer is instructed to discard any unknown extensions
		// from the input message.
		//
	    relayed_encoding = v1Peer.relay(encoding);
	    if (relayed_encoding != null)
		v2Peer.receive(relayed_encoding);
	}
	finally {
		//
		// Ensure that the project is deinitialized on exit.
		//
	    Relay.deinitialize();
	}
    }
	//
	// Coder object to encode/decode messages.
	//
    Coder mCoder = null;

	//
	// Initialize V2Peer providing the coder to encode/decode messages.
	//
    public V2Peer(Coder coder)
    {
	mCoder = coder;
	mCoder.enableEncoderDebugging();
	mCoder.enableDecoderDebugging();
	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}
    }

	//
	// Encode the PDU object of Envelope.
	//
    public byte[] send(Envelope data)
    {
		//
		// Update the "route" to reflect the fact that the message
		// was passed through the V2Peer encoder.
		//
	Route route = data.getRoute();
	route.add(new IA5String("Sent by V2Peer"));
	System.out.println("\n\tUnencoded PDU object about to be sent by V2Peer...\n");
	System.out.println(data);
	try {
		    //
		    // Encode the PDU object using the type from the
		    // version-2 protocol.
		    //
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();
	    System.out.println("\tV2Peer trace messages from the encoder...\n");
	    mCoder.encode(data, sink);
	    byte[] encoding = sink.toByteArray();
	    System.out.println("PDU encoded with a length of " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);
	    return encoding;
	}
	catch (Exception e) {
	    System.out.println("Encoding failed with exception: " + e);
	    return null;
	}
    }

	//
	// Decode the Envelope encoded PDU received from another peer.
	//
    public Envelope receive(byte[] message)
    {
	try {
		//
		// Decode the PDU using the type from the version-2 protocol.
		//
	    System.out.println("\nV2Peer receiving the re-encoded PDU...");
	    ByteArrayInputStream source = new ByteArrayInputStream(message);
	    System.out.println("\n\tV2Peer trace messages from the decoder ...\n");
	    Envelope data = (Envelope)mCoder.decode(source, new Envelope());
		//
		// Update the "route" to reflect the fact that the message
		// was passed through the V2Peer decoder.
		//
	    Route route = data.getRoute();
	    route.add(new IA5String("Received by V2Peer"));
	    System.out.println("\n\tDecoded PDU object received by V2Peer...\n");
	    System.out.println(data);
	    return data;
	}
	catch (Exception e) {
	    System.out.println("Decoding failed with exception: " + e);
	    return null;
	}
    }
}

