/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Topen.java	16.2 14/02/08 */
/*
 * This example demonstrates automatic and manual encoding/decoding a PDU
 * object that has an open type value field.
 *
 * To run the program say:
 *
 * asn1pjav open.asn
 * cd open
 * open.bat javac
 * cd ..
 * javac -g *.java
 * java Topen
 */



/*

The program uses following open.asn abstract syntax

Test DEFINITIONS ::= BEGIN

    OPERATION ::= CLASS {
	  &code INTEGER UNIQUE,
	  &Type
    }

    A ::= SEQUENCE {
	  opcode OPERATION.&code ({ASet}),
	  argument OPERATION.&Type ({ASet}{@opcode})
    }


    ASet OPERATION ::= { { &code 1, &Type INTEGER } |
			 { &code 2, &Type BOOLEAN } |
			 { &code 3, &Type SEQUENCE { a INTEGER }}
    }

END

The program does the following:

1. Initializes the project and creates a BER coder
2. Creates a PDU of type A with opcode 1 and argument INTEGER: 100
3. Encodes and decodes the PDU with automatic encoding/decoding
   of open type values enabled.
4. Encodes and decodes the PDU with automatic decoding
   of open type values disabled.  Manualy decodes the 'argument'
   field which was left undecoded after decoding the PDU object
   with automatic decoding disabled.

*/


/* Compiler-generated classes */
import open.*;
import open.test.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Topen {

    public static void main(String args[])
    {

	try {
	    Open.initialize();
    	}
    	catch (Exception e) {
    	    System.out.println("Initialization failed with exception: " + e);
    	    System.exit(1);
    	}

	Coder coder = Open.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

		//
		// enable relaxed decoding mode if needed
		//
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

		//
		// Create the value.
		//
	A pdu = new A(1, new OpenType(new INTEGER(100)));
	A decodedData = null;
        
		//
		// Print the input to the encoder.
		//
	System.out.println("\n\tUnencoded PDU....");
	System.out.println(pdu);

        ByteArrayOutputStream sink = new ByteArrayOutputStream();
	ByteArrayInputStream source = null;
        byte[] encoding = null;

	try {
		//
		// Encode the PDU.
		//
	    System.out.println("\nEncoding the A PDU...\n");
	    coder.encode(pdu, sink);

		//
		// Extract the encoded PDU from the sink stream.
		//
	    encoding = sink.toByteArray();

		//
		// Print the encoded PDU using the HexTool utility.
		//
	    System.out.println("\n\tEncoded PDU...\n");
	    HexTool.printHex(encoding);
	}
	catch (EncodeFailedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}
	catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}

	try {
	    source = new ByteArrayInputStream(encoding);

		//
		// Decode the PDU.
		//
	    System.out.println("\nDecoding the A PDU with automatic decoding turned on...\n");

	    //decodedData is a pdu decoded from the inputstream
	    decodedData = new A();

	    decodedData = (A) coder.decode(source, decodedData);

	    System.out.println("\n\tDecoded PDU...\n");
	    System.out.println(decodedData);
	}
	catch (DecodeFailedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	}
	catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	}
		//
		// Disable automatic decoding.
		//
	coder.disableAutomaticDecoding();

	sink = new ByteArrayOutputStream();
	encoding = null;

	try {
		//
		// Encode the PDU.
		//
	    System.out.println("\nEncoding the A PDU again...\n");
	    coder.encode(pdu, sink);

		//
		// Extract the encoding from the sink stream.
		//
	    encoding = sink.toByteArray();

		//
		// Print the encoding using the HexTool utility.
		//
	    System.out.println("\n\tEncoded PDU...\n");
	    HexTool.printHex(encoding);
	}
	catch (EncodeFailedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}
	catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}

		//
		// Decode with automatic decoding disabled.
		//
	try {
	    source = new ByteArrayInputStream(encoding);

		//
		// Decode the PDU.
		//
	    System.out.println("\nDecoding the A PDU with automatic decoding turned off...\n");

		//
		// The decodedData is one A PDU decoded from the input stream.
		//
	    decodedData = new A();

	    decodedData = (A) coder.decode(source, decodedData);

	    System.out.println("\nDecoded PDU...\n");
	    System.out.println(decodedData);

		//
		// Manually decode the open type component of the decoded
		// PDU object.
		//
	    System.out.println("\nDecoding the open type value...\n");
	    encoding = decodedData.getArgument().getEncodedValue();
	    source = new ByteArrayInputStream(encoding);
	    if (decodedData.getOpcode() == 1)
		decodedData.getArgument().setDecodedValue(
		    coder.decode(source, new INTEGER()));
	    else if (decodedData.getOpcode() == 2)
		decodedData.getArgument().setDecodedValue(
		    coder.decode(source, new BOOLEAN()));
	    else
		System.out.println("Opcode " + decodedData.getOpcode() + " not implemented");

	    System.out.println("\nDecoded data ...\n");
	    System.out.println(decodedData);

	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	}
    }
}

