/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Encoder.java	16.4  14/02/08
 */

/*
 * Demonstrates CAP PDU encoding.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import cap.*;
import cap.cap_gsmssf_gsmscf_pkgs_contracts_acs.*;
import cap.tcapmessages.*;
import cap.dialoguepdus.*;
import cap.remote_operations_generic_ros_pdus.*;
import cap.remote_operations_information_objects.*;
import cap.cs1_datatypes.*;
import cap.map_commondatatypes.*;
import cap.map_ms_datatypes.*;

public class Encoder {

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Cap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Cap.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	/*
	 * Construct the PDU for encoding.
	 */
	AbstractData msg = fill_GenericSSF_gsmSCF_PDUs_PDU();

	System.out.println("PDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);

    }

    /*
     * Helper methods to set up the PDU for encoding.
     */
    static AbstractData  fill_GenericSSF_gsmSCF_PDUs_PDU()
    {
	GenericSSF_gsmSCF_PDUs  pdu;

	/* Allocate top-level object for the message */
	pdu = new GenericSSF_gsmSCF_PDUs();

	/* Indicate begin type chosen*/
	GenericSSF_gsmSCF_PDUs.Begin begin =
	    new GenericSSF_gsmSCF_PDUs.Begin();
	pdu.setBegin(begin);

	/* Indicate Transaction ID */
	OrigTransactionID otid = new OrigTransactionID(
	    new byte[] { (byte)0x70, (byte)0x00, (byte)0x01, (byte)0xFD });
	begin.setOtid(otid);

	/* dialoguePortion carries the dialogue control PDUs as value of the
	 * external data type. Fill structure for external type with the
	 * structured dialogue control PDU.
	 * (use dialogue-as-id object identifier for direct-reference field)
	 */
	DialoguePortion dialoguePortion = new DialoguePortion();
	begin.setDialoguePortion(dialoguePortion);

	dialoguePortion.setDirect_reference(
	    (ObjectIdentifier)DialoguePDUs.dialogue_as_id.clone());
	External.Encoding encoding = new External.Encoding();
	dialoguePortion.setEncoding(encoding);

	encoding.setSingle_ASN1_type(new OpenType(
	    fill_DialoguePDU_PDU()));

	GenericSSF_gsmSCF_PDUs.Begin.Components components =
	    new GenericSSF_gsmSCF_PDUs.Begin.Components();
	begin.setComponents(components);

	GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_ element =
	    new GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_();

	components.add(element);

	GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_.BasicROS basicROS =
	    new GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_.BasicROS();
	element.setBasicROS(basicROS);

	GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_.BasicROS.Invoke invoke =
	    new GenericSSF_gsmSCF_PDUs.Begin.Components.Choice_.BasicROS.Invoke();
	basicROS.setInvoke(invoke);

	invoke.setArgument(new OpenType(
	    fill_InitialDPArg_PDU()));

	invoke.setInvokeId(cap.remote_operations_generic_ros_pdus.InvokeId.createInvokeIdWithPresent(0));
	invoke.setOpcode(Code.createCodeWithLocal(0));

	return pdu;
    }

    static SsfToScfGenericInvokable_ARGUMENT_15 fill_InitialDPArg_PDU()
    {
	SsfToScfGenericInvokable_ARGUMENT_15 pdu =
	    new SsfToScfGenericInvokable_ARGUMENT_15();

	pdu.setServiceKey(new cap.cs1_datatypes.ServiceKey(100));
	pdu.setCallingPartyNumber(new OctetString(
	    new byte[] { (byte)0x83, (byte)0x13, (byte)0x37, (byte)0x97,
			  (byte)0x01, (byte)0x04, (byte)0x02 }));

	pdu.setCallingPartysCategory(
	    new CallingPartysCategory(
		new byte[] { (byte)0x0A }
	    )
	);
	pdu.setLocationNumber(new OctetString(
	    new byte[] { (byte)0x84, (byte)0x93, (byte)0x64, (byte)0x37,
			 (byte)0x97, (byte)0x00, (byte)0x03, (byte)0x01 }));

	pdu.setBearerCapability(
	    SsfToScfGenericInvokable_ARGUMENT_15.BearerCapability.createBearerCapabilityWithBearerCap(
		new OctetString(
		    new byte[] { (byte)0x80, (byte)0x90, (byte)0xA3 }
		)
	    )
	);

	pdu.setEventTypeBCSM(cap.cap_datatypes.EventTypeBCSM.collectedInfo);

	pdu.setIMSI(
	    new IMSI(
		new byte[] { (byte)0x42, (byte)0x00, (byte)0x47,
			     (byte)0x26, (byte)0x00, (byte)0x00,
			     (byte)0x04, (byte)0xF2 }
	    )
	 );

	LocationInformation locationInformation = new LocationInformation();
	pdu.setLocationInformation(locationInformation);

	locationInformation.setAgeOfLocationInformation(
	    new AgeOfLocationInformation(0)
	);

	locationInformation.setVlr_number(
	    new ISDN_AddressString(
		new byte[] { (byte)0x91, (byte)0x64, (byte)0x37,
			     (byte)0x97, (byte)0x00, (byte)0x03,
			     (byte)0xF1
		}
	    )
	);

	locationInformation.setCellGlobalIdOrServiceAreaIdOrLAI(
	    CellGlobalIdOrServiceAreaIdOrLAI.createCellGlobalIdOrServiceAreaIdOrLAIWithCellGlobalIdOrServiceAreaIdFixedLength(
		new CellGlobalIdOrServiceAreaIdFixedLength(
		    new byte[] { (byte)0x42, (byte)0xF0, (byte)0x50,
				 (byte)0x00, (byte)0x2A, (byte)0x03,
				 (byte)0x60
		    }
		)
	    )
	);

	pdu.setExt_basicServiceCode(
	    Ext_BasicServiceCode.createExt_BasicServiceCodeWithExt_Teleservice(
		new cap.map_ts_code.Ext_TeleserviceCode (
		    new byte[]
		    {
			(byte)0x11
		    }
		)
	    )
	);

	pdu.setCallReferenceNumber(
	    new cap.map_ch_datatypes.CallReferenceNumber (
		new byte[]
		{
		    (byte)0x00, (byte)0x12, (byte)0x7B, (byte)0x00, (byte)0x00
		}
	    )
	);

	pdu.setMscAddress(
	    new ISDN_AddressString (
		new byte[]
		{
		    (byte)0x91, (byte)0x64, (byte)0x37, (byte)0x97, (byte)0x00,
		    (byte)0x03, (byte)0xF1
		}
	    )
	);

	pdu.setCalledPartyBCDNumber(
	    new OctetString (
		new byte[]
		{
		    (byte)0x81, (byte)0x70, (byte)0x40, (byte)0x62, (byte)0x34,
		    (byte)0x07
		}
	    )
	);

	pdu.setTimeAndTimezone(
	    new OctetString (
		new byte[]
		{
		    (byte)0x02, (byte)0x30, (byte)0x11, (byte)0x72, (byte)0x31,
		    (byte)0x95, (byte)0x84, (byte)0x00
		}
	    )
	);

	return pdu;
    }


    static DialoguePDU fill_DialoguePDU_PDU()
    {
	DialoguePDU pdu = new DialoguePDU();


	/* Indicate Request message */
	AARQ_apdu dialogueRequest = new AARQ_apdu();
	pdu.setDialogueRequest(dialogueRequest);

	dialogueRequest.setProtocol_version(
	    new AARQ_apdu.Protocol_version(
		new byte[]
		{
		    (byte)0x80
		},
		1
	    )
	);

	dialogueRequest.setApplication_context_name(
	    new ObjectIdentifier(
		new byte[] {
		    (byte)0x04, (byte)0x00, (byte)0x00, (byte)0x01,
		    (byte)0x00, (byte)0x32, (byte)0x01
		}
	    )
	);
	return pdu;
    }

}
