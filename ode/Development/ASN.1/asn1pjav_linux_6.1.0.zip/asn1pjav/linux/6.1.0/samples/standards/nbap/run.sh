#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# @(#)run.sh	16.2 14/02/08
#***************************************************************************
# Please use this script to run the sample. Make sure that you properly set
# up the OSS_ASN1_JAVA, CLASSPATH and PATH environment variables before running
# this script.  You can set up JAVAC and JAVA environment variables to
# customize Java compiler/interpreter.

ACTION=${1:-"javac"}

. ../../common.sh
JFLAGS="$JFLAGS -J-mx256m"

case ${ACTION} in
    "cleanup")
	rm -fr nbap
	rm -f *.log
	rm -f *.class
	;;
	
    "javac")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the abstract syntax and run the tests

	echo "----- ASN.1-compiling the syntax -----"
	echo ""
	$ASN1 $COMMON_ASN1_OPTIONS -commandfile nbap.cmd -err compile.log
	if [ $? -eq 0 ]; then 
	    cd nbap
	    echo "----- Compiling generated classes -----"
            echo ""
	    sh nbap.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g Encoder.java 2>&1 >> compile.log
	    if [ -f Encoder.class ]; then
		echo "----- Running the Encoder test -----";
                echo ""
		$JAVA $COMMON_JAVA_OPTIONS Encoder;
	    fi
	    $JAVAC $JFLAGS -g Decoder.java 2>&1 >> compile.log
	    if [ -f Decoder.class ]; then
		echo "----- Running the Decoder test -----";
                echo ""
		$JAVA $COMMON_JAVA_OPTIONS Decoder;
	    fi
	fi
	;;

    *)
	echo "Invalid argument \"$1\"."
        echo ""
	;;
    
esac
