#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE: @(#)run.sh	16.3 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -fr j2735
	rm -f *.log
	rm -f *.class
	;;
	
    "javac")
	CLASSPATH=`pwd`:$TOED_JARS; export CLASSPATH

	# Compile the abstract syntax

	echo "----- ASN.1-compiling the syntax -----"
	$ASN1 $COMMON_ASN1_OPTIONS -toed -debug 0 -oer -per -ber -root -err compile.log J2735.asn
	if [ $? -eq 0 ]; then 
	    cd j2735
	    echo "----- Compiling generated classes -----" 
	    sh j2735.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g Benchmark.java 2>&1 >> compile.log
	    if [ -f Benchmark.class ]; then
		echo "----- Running the compare_oer_per_ber test -----"
		$JAVA -server $COMMON_JAVA_OPTIONS Benchmark;
	    fi
	fi
	;;

    *)
	echo "Invalid argument \"$1\"."
	;;
    
esac
