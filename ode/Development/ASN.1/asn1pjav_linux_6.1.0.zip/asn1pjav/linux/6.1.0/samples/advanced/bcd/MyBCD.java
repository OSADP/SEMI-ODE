/*************************************************************/
/* Copyright (C) 2014 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)MyBCD.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.  */

/**
    Application program MyBCD.java
    Demonstrates the UserClass directive of the OSS ASN.1/Pure Java Tools
    API using bcd.asn and MyBCD.java. To run this program:

    asn1pjav bcd.asn
    move MyBCD.java bcd
    cd bcd
    bcd.bat javac
    cd ..
    javac -g Tbcd.java
    java Tbcd

    MyBCD.java extends the generated class that had the UserClass directive.
    It implements the Printable interface as an illustration.
    It is used as a replacement for the compiler-generated class BCDString.
    MyBCD allows the encoded version of the value to be in binary coded
    decimal (BCD) format, while allowing the value at any time to be printable
    in ascii (readable) format.

 */

package bcd;

import com.oss.asn1.*;
import com.oss.metadata.*;
import com.oss.util.ByteTool;
import bcd.a.BCDString;
import java.io.PrintWriter;

/**
 * Illustrates the com.oss.asn1.Printable interface by implementing the
 * print(int, PrintWriter) method.
 *
 * Contains conversion methods between BCD and ascii format: toBCD() and fromBCD().
 * @see OctetString
 */

public class MyBCD extends BCDString implements Printable {

    /**
     * The default constructor.
     */
    public MyBCD()
    {
    }

    /**
     * Construct from a byte[] type.
     * @param the byte[] to set this object to.
     */

    public MyBCD(byte[] value)
    {
	super(value);
    }

    /**
     * Construct BCD from the decimal number
     * @exception java.lang.NumberFormatException if BCD conversion error
     * occurs
     */
    public MyBCD(String number) throws NumberFormatException
    {
	super(MyBCD.toBCD(number));
    }

    /**
     * Construct BCD from the binary number (long)
     * @exception java.lang.NumberFormatException if BCD conversion error
     * occurs
     */
    public MyBCD(long number) throws NumberFormatException
    {
	super(MyBCD.toBCD(number));
    }

    // Converts binary number to its BCD encoding.
    public static byte[] toBCD(long number) throws NumberFormatException
    {
	return toBCD(Long.toString(number));
    }

    // Converts decimal number to its BCD encoding.
    public static byte[] toBCD(String number)
	throws NumberFormatException
    {
	return ByteTool.parseBCD(number);
    }

    // Converts BCD encoding to decimal number
    public static String fromBCD(byte[] number) throws NumberFormatException
    {
	return ByteTool.toBCD(number);
    }

    /**
     * Implement the print(int, PrintWriter) method of the Printable
     * interface. Special care should be taken if the code needs to call the
     * toString() method of the AbstractData in order to get the defailt value
     * notation. Since the toString() implicitly invokes the print() method,
     * it might result in infinite recursion.
     */
    public int print(int mode, PrintWriter s) throws UserPrintFailedException
    {
	if (mode == Printable.BEFORE) {
	    try {
		if (byteArrayValue() == null)
		    throw new NullPointerException();
		String bcdNumber = fromBCD(byteArrayValue());
		s.print(bcdNumber);
		return Printable.DONE;
	    } catch (NumberFormatException e) {
		// Report that the value has invalid format and
		// gracefully print the raw contents
		s.print(" -- " + e.getMessage() + " -- ");
		return Printable.CONTINUE;
	    } catch (Exception e) {
		// Throw an UserPrintFailedException in case of
		// serious error
		throw new UserPrintFailedException(e.toString());
	    }
	} else  // mode is Printable.AFTER
	    return Printable.DONE;
    }

} // End class definition for MyBCD
