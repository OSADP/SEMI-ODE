/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Tbcd.java	16.2 14/02/08 */
/*
 * This example demonstrates the UserClass directive of the OSS ASN.1 Tools
 * for pure Java using bcd.asn and MyBCD.java.  The user defined class MyBCD
 * is used as a replacement for the compiler-generated class BCDString.  MyBCD 
 * allows the encoded version of the value to be in binary coded decimal (BCD)
 * format, while allowing the value at any time to be printable in ASCII
 * readable format.
 *
 * This example creates, encodes, and decodes a SEQUENCE type called BBCard
 * which contains a MyBCD value.  The value is printed out at each step.
 * Then the example shows how the user class can be created with non-ASCII
 * values and how an illegal value will raise an exception.
 *
 * To run the program say:
 *
 * asn1pjav bcd.asn
 * move MyBCD.java bcd
 * cd bcd
 * bcd.bat javac
 * cd ..
 * javac -g *.java
 * java Tbcd
 */



/* Compiler-generated classes */
import bcd.*;
import bcd.a.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Tbcd {

    public static void main(String args[])
    {

	/*******************************/
	/* Do OSS API initializations. */
	/*******************************/
	try {
	    Bcd.initialize();
	}
	catch (Exception e) {
	    System.out.println("Initialization failed with exception: " + e);
	    System.exit(1);
	}

	Coder coder = Bcd.getBERCoder();

		/*
		 * Turn on trace capabilities.
		 */
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

		/*
		 * enable relaxed decoding mode if needed
		 */
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}
		/*
		 * Create the value to encode using decimal notation for
		 * the BCD number.
		 */
	BBCard myCard = new BBCard(
	    new MyBCD("12345678901"));

		/*
		 * Print the unencoded PDU object.  Note that the value of
		 * BBCard is printed in the custom display format.
		 */
	System.out.println("\n\tUnencoded PDU object\n");
	System.out.println(myCard);

		/*
		 * Print the value of the field in decimal notation.
		 */
	System.out.println("The value of field 'a' has been set to " +
	    myCard.getA());

		/*
		 * Call the encoder to encode myMsg.
		 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();

	System.out.println("\nTrace messages from the encoder...\n");
	try {
	    coder.encode(myCard, sink);
	}
	catch (Exception e) {
	    System.out.println(e);
	    System.exit(1);
	}

		/*
		 * Print the encoded data in hexadecimal.
		 */
	byte[] encoding = sink.toByteArray();
	System.out.println("\n\tEncoded PDU object\n");
	com.oss.util.HexTool.printHex(encoding);

		/*
		 * Call the decoder to decode myMsg.
		 */
	InputStream source = new ByteArrayInputStream(encoding);
	BBCard decodedData = new BBCard();

	System.out.println("\nTrace messages from the decoder...\n");
	try {
	    decodedData = (BBCard)coder.decode(source, decodedData);
	}
	catch (Exception e) {
	    System.out.println(e);
	    System.exit(2);
	}

		/*
		 * Print the decoded value of field a in decimal.
		 */
	System.out.print("\n\tThe decoded value of field 'a' (decimal)\n\n");
	System.out.println(
	    decodedData.getA());
	System.out.print(
	"\tThe Java class of the BBCard.a component created by the decoder...\n\n");
	System.out.println(decodedData.getA().getClass().getName());

	System.out.println("\nThe user class erroneously is created by a non-ASCII value...\n");
	decodedData.getA().
		setValue(new byte[] {(byte)0x12, (byte)0x34, (byte)0xAB});
	System.out.println(
	    decodedData.getA());

	System.out.println("\nThe resulting exception for the illegal value...\n");
	decodedData.getA().setValue(null);
	System.out.println(
	    decodedData.getA());

	Bcd.deinitialize();

    }
}
