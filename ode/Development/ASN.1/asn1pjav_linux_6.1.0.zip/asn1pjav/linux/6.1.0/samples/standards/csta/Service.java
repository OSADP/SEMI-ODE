/*****************************************************************************/
/* Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Service.java	16.3 14/02/08
 */

/*
 * Demonstrates a sample of CSTA protocol exchange:
 * the service receives a makeCall request from the client, analyzes
 * the input MakeCallArgument PDU and sends the response using the
 * MakeCallResult PDU.  Interaction between the service and client is
 * emulated - the service decodes the request PDU from a predefined buffer
 * as if it were just received from the client and it does not actually
 * send its response, just prepares it in encoded form.
 */
 
import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import csta.*;
import csta.header.*;
import csta.remote_operations_generic_ros_pdus.*;
import csta.remote_operations_information_objects.*;
import csta.csta_make_call.*;
import csta.csta_device_identifiers.*;
import csta.csta_call_connection_identifiers.*;

public class Service {

    /*
     * Predefined MakeCall requests message as if it were received from the client
     */
    static byte request[] = new byte[] {
    (byte)0xA1, (byte)0x1C, (byte)0x02, (byte)0x01, (byte)0x06, (byte)0x02, 
    (byte)0x01, (byte)0x0A, (byte)0x30, (byte)0x14, (byte)0x30, (byte)0x0C,
    (byte)0x80, (byte)0x0A, (byte)0x37, (byte)0x33, (byte)0x32, (byte)0x33, 
    (byte)0x30, (byte)0x32, (byte)0x39, (byte)0x36, (byte)0x36, (byte)0x39,
    (byte)0x30, (byte)0x04, (byte)0x81, (byte)0x02, (byte)0x30, (byte)0x39
    };

    static InvokeId	mc_invokeId;
    static Code		mc_opcode;
    static DeviceID	mc_deviceId;

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Csta.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Csta.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	System.out.println("Original BER-encoded PDU...\n");
	HexTool.printHex(request);
	System.out.println("\nDecoding...");

	ByteArrayInputStream source = new ByteArrayInputStream(request);

	/*
	 * Decode the PDU.
	 */
	ROSHeader msg = null;

	try {
	    msg = (ROSHeader)
		coder.decode(source, new ROSHeader());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(msg);

	analyze_request(msg);

	System.out.println("\n----- Forming and encoding makeCall reply -----");
	
        /*
         * Create reply
         */
	ROSHeader replymsg = fill_mc_reply();

	System.out.println("\nPDU for encoding...\n");
	System.out.println(replymsg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(replymsg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);
	
    }

    /* Construct makeCall reply */

    static ROSHeader fill_mc_reply()
    {
	ROSHeader pdu = new ROSHeader();
	MakeCallResult mkcarg = new MakeCallResult();
	/* argument */
	fill_mc_argument(mkcarg);
	
	OpenType omkarg = new OpenType(mkcarg);
	ReturnResult.Result resres = new ReturnResult.Result(mc_opcode, omkarg);

	ReturnResult res = new ReturnResult(mc_invokeId, resres);
	
	pdu.setReturnResult(res);
	return (ROSHeader)pdu;    
    }

    /* Construct MakeCallResult part of the reply */    
    static void fill_mc_argument(MakeCallResult mkcarg)
    {
	CallID callId = new CallID("ABCD".getBytes());
	LocalDeviceID deviceId = LocalDeviceID.createLocalDeviceIDWithStaticID(mc_deviceId);
	ConnectionID.Both both = new ConnectionID.Both(callId, deviceId);
	ConnectionID cid = ConnectionID.createConnectionIDWithBoth(both);
	mkcarg.setCallingDevice(cid);
    }
    
    /* Demonstrates how to access fields of decoded ROS type */
    static void analyze_request(ROS req)
    {
	switch (req.getChosenFlag()) {
	    case ROS.invoke_chosen:
    		analyze_invoke((Invoke)req.getChosenValue());
    		break;
	    case ROS.returnResult_chosen:
	    case ROS.returnError_chosen:
	    case ROS.reject_chosen:
	        break;
	    default:
	}
    }

    /* Demonstrates how to access fields of decoded Invoke type */
    static void analyze_invoke(Invoke inv)
    {
	switch (inv.getInvokeId().getChosenFlag()) {
	    case InvokeId.present_chosen:
    		mc_invokeId = (InvokeId) inv.getInvokeId(); /* remember for reply */
    		break;
	    case InvokeId.absent_chosen:
    		break;
	    default:
	}

	mc_opcode = inv.getOpcode();
	analyze_OpenType(inv.getArgument());
    }
    
    static void analyze_OpenType(OpenType otp)
    {
	if (otp.getDecodedValue() != null) {
	    if (otp.getDecodedValue() instanceof MakeCallArgument)
		mc_deviceId = ((MakeCallArgument)otp.getDecodedValue()).getCallingDevice();
	}    
    }
}
