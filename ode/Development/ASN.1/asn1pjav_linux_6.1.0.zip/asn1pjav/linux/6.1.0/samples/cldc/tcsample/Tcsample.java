/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Tcsample.java	16.3 14/02/08 */
/*
 * This example demonstrates how you can use the OSS ASN.1 Tools for Java
 * to manupulate with values of the types: NumericString, OCTET STRING,
 * SET OF, SEQUENCE, VisibleString, INTEGER, SET, CHOICE, BOOLEAN,
 * OBJECT IDENTIFIER, GeneralizedTime.
 *
 * To run the program say:
 *
 * asn1pjav csample.asn
 * cd csample
 * csample.bat javac
 * cd ..
 * javac -g Tcsample.java
 * java Tcsample
 *
 * NOTE:  Sun's CLDC 1.1 reference implementation is not compatible with JDK 1.5 or later.
 * If you encounter compilation errors when running this sample, please use JDK 1.3 or 1.4.
 */



/* Compiler-generated classes */
import csample.*;
import csample.myexample.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Tcsample {

	//
	// OCTET STRING values used for encoding.
	//
    static byte[] memNameOctStr = new byte[] {
	   0x52, 0x65, 0x61, 0x6C, 0x41, 0x64, 0x64, 0x72, 0x65, 0x73,
	   0x73, 0x52, 0x65, 0x61, 0x6C, 0x41, 0x64, 0x64, 0x72, 0x65,
	   0x73, 0x73, 0x52, 0x65, 0x61, 0x6C, 0x41, 0x64, 0x64, 0x72
    };

    static String returnMsg1 = "This is test 1.";

    static String returnMsg2 = "This is test 2.";

    static byte[] addrOctStr = new byte[] {
	   0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
	   0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
	   0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39
    };

    static byte[] commtOctStr = new byte[] {
	   0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A,
	   0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A,
	   0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A
    };

    static byte[] actionOctStr = new byte[] {
	   0x73, 0x74, 0x6F, 0x70, 0x2E
    };

    static byte[] fldNmOctStr = new byte[] {
	   0x61, 0x62, 0x63, 0x64, 0x65, 0x61, 0x62, 0x63, 0x64, 0x65,
	   0x61, 0x62, 0x63, 0x64, 0x65
    }; /* ASCII ==> "abcdeabcdeabcde" */

    public static void main(String args[]) {

		//
		// Initialize the runtime.
		//
	try {
	    Csample.initialize();
	}
	catch (Exception e) {
	    System.out.println("Initialization failed with error code: " + e);
	    System.exit(1);
	}

	Coder coder = Csample.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

		//
		// Construct PDU objects for encodin.
		//
	Msg1 myMsg = new Msg1();

	myMsg.setMin(new NUMSTR("1234567890"));             /* NumericString */
	myMsg.setMemName(new OctetString(memNameOctStr));   /* OCTET STRING */
	myMsg.setMsgs(new Msg1.Msgs(new RetMesg[] {         /* SET OF */
	    new RetMesg(new VisibleString(returnMsg1)),     /* 1st element */
	    new RetMesg(new VisibleString(returnMsg2))      /* 2nd element */
	}));
	myMsg.setAcntInfo(
	    new AcntInfo(                                   /* SEQUENCE */
		new OctetString(addrOctStr),                /* addr */
		new OctetString(commtOctStr)                /* commt */
	    )
	);
	myMsg.setMemNum(15);                                /* INTEGER */
	myMsg.setNetaddr(new Netaddr());                    /* SET */
	myMsg.getNetaddr().setNetworkid(233);               /* networkid */
	myMsg.getNetaddr().setSsn(215);                     /* ssn */
							    /* CHOICE */
	myMsg.setOperation(Msg1.Operation.createOperationWithCreateReqt(
	    new CreateReqt(                                /* CreateReqt */
		5432,                                      /* ordId */
		new OctetString(actionOctStr),             /* action */
		new OctetString(fldNmOctStr),              /* fldNm */
		true                                       /* creditChecked */
	)));

		//
		// OBJECT IDENTIFIER value is:
		//
		// {joint-iso-itu-t(2) internationalRA(23) set(42) 9 12}
		//
	try {
	    myMsg.setUniqId(new ObjectIdentifier("{ 0 0 8 2250 0 2 }"));
	}
	catch (BadObjectIdentifierException e) {
	    System.out.println("Bad object identifier: " + e);
	    System.exit(1);
	}

		//
		// GeneralizedTime value is:
		//
		// "19981106204702Z" or 1998/11/06 20:47:02 GMT
		//
	myMsg.setTime(new GeneralizedTime(
	    1998,       /* year */
	    11,         /* month */
	    6,          /* dat */
	    20,         /* hour */
	    47,         /* minute */
	    2,          /* second */
	    0,          /* minDiff */
	    0,          /* milisec */
	    true        /* isUTCTime */
	));

	/*****************************************************/
	/* Print to stdout the intended input to the encoder */
	/*****************************************************/
	System.out.println("\n\tUnencoded PDU object...\n");
	System.out.println(myMsg);

	ByteArrayOutputStream sink = new ByteArrayOutputStream();

	System.out.println("\tEncoding the PDU object...\n");
	try {
	    coder.encode(myMsg, sink);
	}
	catch (Exception e) {
	    System.out.println(e);
	    System.exit(1);
	}

	byte[] encoding = sink.toByteArray();
	System.out.println("\n\tPrinting the encoded PDU...\n");
	com.oss.util.HexTool.printHex(encoding);

	InputStream source = new ByteArrayInputStream(encoding);
	Msg1 decodedData = new Msg1();

	System.out.println("\n\tDecoding the encoded PDU...\n");
	try {
	    decodedData = (Msg1)coder.decode(source, decodedData);
	}
	catch (Exception e) {
	    System.out.println(e);
	    System.exit(2);
	}

	System.out.println("\n\tDecoded PDU object...\n");
	System.out.println(decodedData);

	myDecodedDataPrinter(decodedData);
	Csample.deinitialize();

    }

	//
	// Access the fields in the decoded PDU object.
	//
    static void myDecodedDataPrinter(Msg1 data)
    {

	System.out.println("\n\tAccessing individual fields of the decoded PDU object...\n");
	System.out.println("Msg1");
	System.out.println("\tmin:  " + 
	    '"' + data.getMin().stringValue() + '"');
	System.out.println("\tmemName:  " +
	    toHstring(data.getMemName().byteArrayValue()));

	System.out.println("\tmsgs:");
	for (int i = 0; i < data.getMsgs().getSize(); i++)
	    if (data.getMsgs().get(i).hasText())
		System.out.println("\t\t" + 
		    '"' + data.getMsgs().get(i).getText().stringValue() + '"');

	System.out.println("\tacntInfo:  ");
	System.out.println("\t\taddr:  " + 
	    toHstring(data.getAcntInfo().getAddr().byteArrayValue()));
	System.out.println("\t\tcommt:  " +
	    toHstring(data.getAcntInfo().getCommt().byteArrayValue()));

	if (data.hasMemNum())
	    System.out.println("\tmemNum:  " + data.getMemNum());

	if (data.hasNetaddr()) {
	   Netaddr netaddr = data.getNetaddr();

	   System.out.println("\tnetaddr:");
	   if (netaddr.hasNetworkid())
	       System.out.println("\t\tnetwork id:  " + netaddr.getNetworkid());
	   if (netaddr.hasCluster())
	       System.out.println("\t\tcluster:  " + netaddr.getCluster());
	   if (netaddr.hasMember())
	       System.out.println("\t\tmember: " + netaddr.getMember());
	   if (netaddr.hasSsn())
	       System.out.println("\t\tssn: " + netaddr.getSsn());
	}

	System.out.println("\toperation:");
	if (data.getOperation().hasCreateReqt())
	{
	    CreateReqt reqt = (CreateReqt)(data.getOperation().getChosenValue());

	    System.out.println("\t\tcreateReqt chosen.");
	    System.out.println("\t\tordId:  " + reqt.getOrdId());
	    System.out.println("\t\taction:  " + 
		toHstring(reqt.getAction().byteArrayValue()));
	    System.out.println("\t\tfldNm:  " + 
		toHstring(reqt.getFldNm().byteArrayValue()));

	    if (reqt.getCreditChecked())
		System.out.println("\t\tcreditChecked:  TRUE");
	    else
		System.out.println("\t\tcreditChecked:  FALSE");

	} else if (data.getOperation().hasUpdateReqt()) {
	    UpdateReqt reqt = (UpdateReqt)(data.getOperation().getChosenValue());

	    System.out.println("\t\tupdateReqtReqt chosen.");
	    System.out.println("\t\tordId:  " + reqt.getOrdId());
	    System.out.println("\t\taction:  " + 
		toHstring(reqt.getAction().byteArrayValue()));
	    System.out.println("\t\tfldNm:  " + 
		toHstring(reqt.getOldFldNm().byteArrayValue()));
	    System.out.println("\t\tnewFldNm:  " + 
		toHstring(reqt.getNewFldNm().byteArrayValue()));
	}

	System.out.println("\tuniqId:  " + 
	    rightHandOf(data.getUniqId().toString()));

	System.out.print("\ttime:  ");
	System.out.print(data.getTime().getYear() + ".");
	System.out.print(data.getTime().getMonth() + ".");
	System.out.print(data.getTime().getDay() + " ");
	System.out.print(data.getTime().getHour() + ":");
	System.out.print(data.getTime().getMinute() + ":");
	System.out.print(data.getTime().getSecond() + ".");
	System.out.print(data.getTime().getMillisecond());
	if (data.getTime().getIsUTCTime())
	     System.out.println(" GMT");
	else
	     System.out.println(data.getTime().getMinuteDifferential() / 60 + ":" +
		  data.getTime().getMinuteDifferential() % 60);

	System.out.println("Finished printing out decoded data.");

    }

	//
	// Helper method. Converts byte[] array to the Hstring format, like
	// '12345'H.
	//
    static String toHstring(byte[] value)
    {
	return "'" + HexTool.getHex(value) + "'H";
    }
    
	//
	// Helper method. Takes value notation in the format
	// name Type ::= value
	// and returns the right hand of the assignment, that follows
	// the '::=' assignment operator.
	
    static String rightHandOf(String valueAssignment)
    {
	final String assignment = " ::= ";
	int pos = valueAssignment.indexOf(assignment);
	if (pos != -1)
	    return valueAssignment.substring(pos + assignment.length());
	else
	    return valueAssignment;
    }
}
