/*
 * Copyright (C) 2014 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)V1Peer.java	16.3 14/02/08 */
/*
 * This example--see also V2Peer.java--demonstrates interoperation of two
 * peers that use different versions of the same extensible ASN.1 type.
 * It demonstrates the ability of the version-1 peer to safely relay the
 * extension additions added by the version-2 peer. In order to work
 * properly, the definitions in relay.asn should be compiled with the
 * -relaySafe command line option.  Also, since this sample uses PER,
 * the -per command line option should be also specified when ASN.1-compiling.
 *
 * To run the program say:
 *
 * asn1pjav -per -relay relay.asn
 * cd relay
 * relay.bat javac
 * cd ..
 * javac -g *.java
 * java TV2Peer
 */




/*
    The V1Peer uses the following abstract syntax:

Transport-v1 DEFINITIONS AUTOMATIC TAGS ::= BEGIN
    Transport-ID ::= ENUMERATED {ipx, ip, ...}
    Address ::= CHOICE {
	iPXAddress SEQUENCE
	{
	    node OCTET STRING (SIZE(6)),
	    netnum OCTET STRING (SIZE(4))
	},
	iPAddress SEQUENCE
	{
	    network OCTET STRING (SIZE(4))
	},
	...
    }
    Preferences ::= SEQUENCE {
	preferred-transport Transport-ID,
	address Address,
	...
    }
    Route ::= SEQUENCE OF IA5String
    Envelope ::= SEQUENCE {
	route Route,
	data Preferences
    }
END

If compared with version 2, the Transport-v1 abstract syntax does not define
the "ip6" enumerator, the "iP6Address" alternative of the "Address" and the
"supported-transports" extension addition of "Preferences".
*/


/* Compiler-generated classes */
import relay.*;
import relay.transport_v1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class V1Peer {

	//
	// Coder object to encode/decode messages.
	//
    Coder mCoder = null;
    boolean mDiscardUnknown = false;

	//
	// Instantiate V1Peer providing the coder to encode/decode
	// the messages and the boolean indicator, that instructs
	// V1Peer to process unknown extensions in the message.
	//
    public V1Peer(Coder coder, boolean discardUnknown)
    {
	mCoder = coder;
	mDiscardUnknown = discardUnknown;
	mCoder.enableEncoderDebugging();
	mCoder.enableDecoderDebugging();
	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}
    }

	//
	// Encode the Envelope PDU object.
	//
    public byte[] send(Envelope data)
    {
		//
		// Update the 'route' to reflect the fact that the message
		// was passed through V1Peer encoder.
		//
	Route route = data.getRoute();
	route.add(new IA5String("Sent by V1Peer"));
	System.out.println("V1Peer sending the re-encoded PDU object back...");
	System.out.println("\n\tDecoded PDU object about to be sent by V1Peer...\n");
	System.out.println(data);
	try {
		//
		// Encode the PDU object again using the type from the
		// version-1 protocol.
		//
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();
	    System.out.println("\tV1Peer trace messages from the encoder...\n");
	    mCoder.encode(data, sink);
	    byte[] encoding = sink.toByteArray();
	    System.out.println("PDU encoded into " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);
	    return encoding;
	}
	catch (Exception e) {
	    System.out.println("Exception: " + e);
	    return null;
	}
    }

	//
	// Decode the Envelope PDU received from V2Peer.
	//
    public Envelope receive(byte[] message)
    {
	try {
		//
		// Decode the encoded PDU using the type from the version-1
		// protocol.
		//
	    System.out.println("\nV1Peer receiving the encoded PDU...");
	    ByteArrayInputStream source = new ByteArrayInputStream(message);
	    System.out.println("\n\tV1Peer trace messages from the decoder...\n");
	    Envelope data = (Envelope)mCoder.decode(source, new Envelope());
		//
		// Update "route" to reflect the fact that the message was
		// passed through V1Peer.
		//
	    Route route = data.getRoute();
	    route.add(new IA5String("Received by V1Peer"));
	    System.out.println("\n\tDecoded PDU object received by V1Peer:\n");
	    System.out.println(data);
	    return data;
	}
	catch (Exception e) {
	    System.out.println("Decoding failed with exception: " + e);
	    return null;
	}
    }

	//
	// Relay the value of Envelope whose encoding is in "message".
	//
    public byte[] relay(byte[] message)
    {
	Envelope data = receive(message);
	if (data == null)
	    return null;
	if (mDiscardUnknown) {
		//
		// Demonstrate how V1Peer can process unknown extensions in
		// the message received from V2Peer.
		//
	    System.out.println("\nV1Peer discarding unknown extension additionms...");
	    Preferences prefs = data.getData();
	    if (prefs.getPreferred_transport().isUnknownEnumerator()) {
		//
		// If the message contains some unknown enumerator, V1Peer
		// replaces this unknown enumerator by some known enumerator.
		//
		prefs.setPreferred_transport(Transport_ID.ip);
		System.out.println("V1Peer replaced the unknown enumerator with \"ip\"");
	    }
	    if (prefs.getAddress().hasUnknownExtension()) {
		//
		// If the message contains some CHOICE with unknown selection,
		// V1Peer replaces this unknown selection by some known one.
		//
		Address address = prefs.getAddress();
		address.setIPAddress(new Address.IPAddress(
		    new OctetString(
			new byte[] {(byte)192, (byte)168, (byte)152, 103}
		    )
		));
	    	System.out.println("V1Peer replaced the unknown selection with \"iPAddress\"");
	    }
	    if (prefs.numberOfUnknownExtensions() > 0) {
		//
		// If the message contains some SEQUENCE value with unknown
		// extension additions, V1Peer discards them before re-encoding
		// the value.
		//
	    	System.out.println("V1Peer discarded " +
		    prefs.numberOfUnknownExtensions() +
		    " unknown extension(s) from \"Preferences\"");
		prefs.removeAllUnknownExtensions();
	    }
	}
	return send(data);
    }
}

