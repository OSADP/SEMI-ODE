#!/bin/sh
#***************************************************************************
# Copyright (C) 2014 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)common.sh	16.4 14/02/08
#***************************************************************************
# Common settings for samples

# ASN.1 Java Tools installation home
OSSASN1=$OSS_ASN1_JAVA

# ASN1 Compiler executable
ASN1=asn1pjav

# OSSTLV executable
TLV=osstlv

# Common options for ASN.1 compiler
COMMON_ASN1_OPTIONS=

# Java compiler
JAVAC=javac

# Java compiler flags
JFLAGS=

# JVM executable
JAVA=java

# Common JVM option flags
COMMON_JAVA_OPTIONS=

# SOED jar(s)
SOED_JARS=$OSSASN1/lib/oss.jar

# TOED jar(s)
TOED_JARS=$OSSASN1/lib/osstoed.jar

# Select SOED runtime by default
CLASSPATH=$SOED_JARS

# CLDC API classes
CLDC_CLASSES=$CLDC_HOME/bin/common/api/classes

# CLDC preverify tool executable
PREVERIFY=preverify

# CLDC KVM executable
KVM=kvm

# KVM options
COMMON_KVM_OPTIONS='-heapsize 1M'
