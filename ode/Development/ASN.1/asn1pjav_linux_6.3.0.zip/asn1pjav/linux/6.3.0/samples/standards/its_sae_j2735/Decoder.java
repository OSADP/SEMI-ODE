
/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.     	     */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Decoder.java	17.1 15/11/13
 */

/*
 * Demonstrates DSRC BasicSafetyMessage PDU decoding.
 */
import com.oss.asn1.Coder;
import com.oss.asn1.DecodeFailedException;
import com.oss.asn1.DecodeNotSupportedException;
import com.oss.asn1.OctetString;
import com.oss.util.HexTool;
import j2735.J2735;
import j2735.dsrc.BasicSafetyMessage;
import j2735.dsrc.PathHistory;
import j2735.dsrc.VehicleSafetyExtension;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Decoder {

    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    J2735.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = J2735.getBERCoder();

	coder.enableDecoderDebugging();

	// Enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}
        
        // Name of file containing encoded data
        final String fileName = "BSM_600bytes.ber";

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;
	File file = new File(path, fileName);

        dumpInputEncoding(file.toString());

	System.out.println("\nDecoding...");
        FileInputStream fis = null;
        try {
	    if (!file.exists()) {
		throw new IOException("Failed to open the " + file.toString() + " file. " +
		    "Restart the sample program using as input parameter the name of the directory " +
		    "where the '" + file.getName() + "' file is located.\n");
	    }
            fis = new FileInputStream(file);
        } catch (IOException e) {
            System.out.println("Error when opening input file '" + file.toString() + "'");
            System.out.println(e);
            System.exit(2);
        }
	BufferedInputStream source = new BufferedInputStream(fis);

	/*
	 * Decode the PDU.
	 */
	BasicSafetyMessage msg = null;
	try {
	    msg = (BasicSafetyMessage)
                coder.decode(source, new BasicSafetyMessage());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} finally {
            try {
                source.close();
            } catch (Exception e) {
            }
        }

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(msg);
        
        /*
         * Access crumb data
         */
        
        if (msg.hasSafetyExt()) {
            VehicleSafetyExtension ext = msg.getSafetyExt();
            if (ext.hasPathHistory()) {
                PathHistory pathHistory = ext.getPathHistory();
                PathHistory.CrumbData crumbData = pathHistory.getCrumbData();
                if (crumbData.hasPathHistoryPointSets_03()) {
                    System.out.println("Crumb data: ");
                    byte[] data = ((OctetString)crumbData.getChosenValue()).byteArrayValue();
                    HexTool.printHex(data);
                }
            }
        }
    }

    private static void dumpInputEncoding(String fileName)
    {
        File f = new File(fileName);
        long size = f.length();
        
	System.out.println("Original BER-encoded PDU...\n");
        if (size > Integer.MAX_VALUE) {
            System.out.println("File is too big: *dump skipped*");
            return;
        }
        
        byte[] data = new byte[(int)size];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(f);
            int offset = 0;
            while (offset < size) {
                int count = fis.read(data, offset, (int)size);
                if (count == -1) {
                    System.out.println("Unexpected EOF: *dump skipped*");
                    return;
                }
                offset += count;
            }
        } catch (IOException e) {
            System.out.println(e);
            System.out.println("Unexpected I/O error: *dump skipped*");
            return;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                }
            }
        }
	HexTool.printHex(data);
    }
}
