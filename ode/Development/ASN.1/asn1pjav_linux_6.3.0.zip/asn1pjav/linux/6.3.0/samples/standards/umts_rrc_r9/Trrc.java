/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.     	     */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Trrc.java	17.3 15/11/13
 */

/*
 * Demonstrates part of RRC protocol layer of an UE stack.
 */

import com.oss.asn1.*;
import com.oss.util.*;
import java.io.*;
import rrc.*;
import rrc.class_definitions.DL_DCCH_Message;
import rrc.class_definitions.DL_DCCH_MessageType;
import rrc.class_definitions.UL_DCCH_Message;
import rrc.class_definitions.UL_DCCH_MessageType;
import rrc.informationelements.CipheringAlgorithm_r7;
import rrc.informationelements.IntegrityProtectionAlgorithm_r7;
import rrc.informationelements.RRC_TransactionIdentifier;
import rrc.pdu_definitions.SecurityModeCommand;
import rrc.pdu_definitions.SecurityModeCommand.Later_than_r3;
import rrc.pdu_definitions.SecurityModeCommand_r7_IEs;
import rrc.pdu_definitions.SecurityModeComplete;

public class Trrc {

    static Coder coder;
    static String border = "-------------------------------------------------------";

    /*
     * Decodes and prints the input messages; creates, encodes and prints 
     * the output (response) messages.
     */
    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    Rrc.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = Rrc.getPERUnalignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;

	try {
	    testDL_DCCH_Message(path, "RRCConnectionRelease.uper");
	} catch (Exception e) {
	    System.out.println(e);
	}

	try {
	    testDL_DCCH_Message(path, "SecurityModeCommand.uper");
	} catch (Exception e) {
	    System.out.println(e);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * Represents am imcomplete implementation of UE-side function processing
     * a downlink DCCH message. It decodes the message, prints it, and creates
     * a response for some particular alternatives. The function can be used
     * to implement a complete LTE RRC UE-side dispatcher.
     */
    static void testDL_DCCH_Message(String path, String filename) throws IOException, Exception
    {
	DL_DCCH_Message 	request;
	UL_DCCH_Message 	response;

	File file = new File(path, filename);
	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	System.out.println("Read encoding from file: " + filename + "\n");
	System.out.println("Decoding the input downlink DCCH message");
	System.out.println(border);
	/* Deserialize input message */
        request = (DL_DCCH_Message)coder.decode(
    			    source, new DL_DCCH_Message());
	source.close();
	System.out.println("\nPDU decoded");
	
	DL_DCCH_MessageType msg_typ = request.getMessage();
	System.out.println(border);
	switch (msg_typ.getChosenFlag()) {
	    /* You can take unimplemented CHOICE alternatives one by
	     * one and add support for them */
            case DL_DCCH_MessageType.activeSetUpdate_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.assistanceDataDelivery_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.cellChangeOrderFromUTRAN_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.cellUpdateConfirm_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.counterCheck_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.downlinkDirectTransfer_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.handoverFromUTRANCommand_GSM_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.handoverFromUTRANCommand_CDMA2000_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.measurementControl_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.pagingType2_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.physicalChannelReconfiguration_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.physicalSharedChannelAllocation_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.radioBearerReconfiguration_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.radioBearerRelease_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.radioBearerSetup_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.rrcConnectionRelease_chosen:
		/* Print deserialized message */
		System.out.println(request);
		break;
            case DL_DCCH_MessageType.securityModeCommand_chosen:
		/* Print deserialized message */
		System.out.println(request);
		System.out.println("Creating response");
		System.out.println(border);
		/* Create response */
		response = createSecurityModeCommandResponse(request);

		System.out.println();
		System.out.println("Response created successfully");
		System.out.println(border);
		/* Print outcome message */
		System.out.println(response);
		System.out.println("Encoding response");
		System.out.println(border);
		/* Serialize outcome message */
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
		    coder.encode(response, out);
		    out.close();
		} catch (Exception e) {
		    System.out.println("Encoding failed: " + e);
		    System.exit(1);
		}

		/* Print serialized outcome message */
		System.out.println("\nEncoded response "
				+ "(" + out.size() + " bytes):");
		System.out.println(HexTool.getHex(out.toByteArray()));

		break;
            case DL_DCCH_MessageType.signallingConnectionRelease_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.transportChannelReconfiguration_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.transportFormatCombinationControl_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.ueCapabilityEnquiry_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.ueCapabilityInformationConfirm_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.uplinkPhysicalChannelControl_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.uraUpdateConfirm_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.utranMobilityInformation_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.handoverFromUTRANCommand_GERANIu_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.mbmsModifiedServicesInformation_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.etwsPrimaryNotificationWithSecurity_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.handoverFromUTRANCommand_EUTRA_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.spare3_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.spare2_chosen:
		System.out.println("Unimplemented");
		break;
            case DL_DCCH_MessageType.spare1_chosen:
		System.out.println("Unimplemented");
		break;
	    default:
		System.out.println("Unknown CHOICE alternative selected");
		break;
	}	
    }

    /*
     * Creates an UL_DCCH_Message PDU (security mode complete) 
     * for given DL_DCCH_Message PDU (security mode command).
     */
    static UL_DCCH_Message createSecurityModeCommandResponse(
				DL_DCCH_Message request)
    throws IOException, Exception
    {
	IntegrityProtectionAlgorithm_r7 ipalg = null;
	CipheringAlgorithm_r7 calg = null;
        
        SecurityModeCommand.Later_than_r3 cmd = securityModeCommand(request);
        if (cmd == null) {
 	    throw new Exception("cannot handle ASN.1 data");            
        }
        RRC_TransactionIdentifier transaction_id = cmd.getRrc_TransactionIdentifier();
        SecurityModeCommand_r7_IEs ies = extractIEs(cmd);
        if (ies == null) {
 	    throw new Exception("cannot handle ASN.1 data");            
        }

        if (ies.hasCipheringModeInfo()) {
            calg = 
                ies.getCipheringModeInfo().getCipheringModeCommand().getStartRestart();
        }

        if (ies.hasIntegrityProtectionModeInfo() && 
                ies.getIntegrityProtectionModeInfo().hasIntegrityProtectionAlgorithm()) {
            ipalg = 
                ies.getIntegrityProtectionModeInfo().getIntegrityProtectionAlgorithm();
        }
        
        if (calg != null && 
            calg != CipheringAlgorithm_r7.uea0 &&
            calg != CipheringAlgorithm_r7.uea1 &&    
            calg != CipheringAlgorithm_r7.uea2) {
	    throw new Exception("unknown ciphering");
        }

        if (ipalg != null && 
            ipalg != IntegrityProtectionAlgorithm_r7.uia1 &&
            ipalg != IntegrityProtectionAlgorithm_r7.uia2) {
	    throw new Exception("unknown integrity protection");
        }

        UL_DCCH_MessageType message = 
            UL_DCCH_MessageType.createUL_DCCH_MessageTypeWithSecurityModeComplete(
                new SecurityModeComplete(transaction_id));
        UL_DCCH_Message response = new UL_DCCH_Message(message);

	return response;
    }

    /*
     * Attempts to extract the SecurityModeCommand with version later then r3 
     * from the request. Returns null if the request does not contain the 
     * SecurityModeCommand or the contained SecurityModeCommand is r3
     */
    private static SecurityModeCommand.Later_than_r3 securityModeCommand(DL_DCCH_Message request) {
        DL_DCCH_MessageType message = request.getMessage();
        if (!message.hasSecurityModeCommand() 
            || !((SecurityModeCommand)
               message.getChosenValue()).hasLater_than_r3()) {
	    return null;            
        }
        
        return (SecurityModeCommand.Later_than_r3)
            ((SecurityModeCommand)message.getChosenValue()).getChosenValue();
    }

    /*
     * Attempts to extract r7 IEs from the SecurityModeCommand. Returns null
     * if the command does not contain any r7 IEs
     */
    private static SecurityModeCommand_r7_IEs extractIEs(Later_than_r3 cmd) {
        SecurityModeCommand.Later_than_r3.CEs criticalExtemsions = 
            cmd.getCriticalExtensions();

        if (!criticalExtemsions.hasR7()) {
 	    return null;            
        }

        SecurityModeCommand.Later_than_r3.CEs.R7 r7 = 
            (SecurityModeCommand.Later_than_r3.CEs.R7)criticalExtemsions.getChosenValue();
        return r7.getSecurityModeCommand_r7();
    }
}
