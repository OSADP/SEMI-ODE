#!/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	16.2 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -rf index1
	rm -f *.class
	rm -f *.log
	break;;
	
    "javac")

	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the index1 abstract syntax and run the IndexDemo# tests

	echo "----- Compiling the index1 specification -----"
	$ASN1 $COMMON_ASN1_OPTIONS index1 -indexinfoobjectsets -err compile.log
	if [ $? -eq 0 ]; then
	    cd index1
	    echo "----- Compiling generated classes -----"
	    sh index1.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g IndexDemo1.java 2>&1 >> compile.log
	    if [ -f IndexDemo1.class ]; then
		echo "----- Running the IndexDemo1 sample -----";
		$JAVA $COMMON_JAVA_OPTIONS IndexDemo1;
	    fi
	    $JAVAC $JFLAGS -g IndexDemo2.java 2>&1 >> compile.log
	    if [ -f IndexDemo2.class ]; then
		echo "----- Running the IndexDemo1 sample -----";
		$JAVA $COMMON_JAVA_OPTIONS IndexDemo2;
	    fi
	    $JAVAC $JFLAGS -g IndexDemo3.java 2>&1 >> compile.log
	    if [ -f IndexDemo3.class ]; then
		echo "----- Running the IndexDemo1 sample -----";
		$JAVA $COMMON_JAVA_OPTIONS IndexDemo3;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac


