#!/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE: @(#)run.sh	16.3 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -fr csta
	rm -f *.log
	rm -f *.class
	break;;
	
    "javac")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the abstract syntax and run the tests

	echo "----- ASN.1-compiling the syntax -----"
	$ASN1 $COMMON_ASN1_OPTIONS -commandfile csta.cmd -err compile.log
	if [ $? -eq 0 ]; then 
	    cd csta
	    echo "----- Compiling generated classes -----"
	    sh csta.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g Service.java 2>&1 >> compile.log
	    if [ -f Service.class ]; then
		echo "----- Running the Service test -----";
                echo ""
		$JAVA $COMMON_JAVA_OPTIONS Service;
	    fi
	    $JAVAC $JFLAGS -g Client.java 2>&1 >> compile.log
	    if [ -f Client.class ]; then
		echo "----- Running the Client test -----";
                echo ""
		$JAVA $COMMON_JAVA_OPTIONS Client;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	echo ""
	;;
    
esac
