/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Twimax.java	17.1 15/11/13
 */

/*
 * The sample simulates some small aspect of ABS functioning - namely,
 * keeping track of connected AMS, their statuses, and their parameters.
 * The input MAC control messages are simply read from files, no real network
 * messages exchange occurs. Since messages themselves do not contain any
 * identification data which allow the ABS to determine the concrete AMS the
 * message has come from, the ABS needs to distinguish between different
 * control connections. In this example, different connections are identified
 * simply by an integer identifier. The example processes only AAI_REG_REQ
 * and AAI_DREG_REQ input messages.
 */

import java.io.*;
import java.util.Enumeration;
import java.lang.System;

import com.oss.asn1.*;
import com.oss.asn1printer.DataPrinter;
import com.oss.util.*;
import com.oss.metadata.*;

import wimax.*;
import wimax.wirelessman_advanced_air_interface.*;

public class Twimax {

    public static final int MAX_CONNECTED_STATIONS = 10;
    /* Global array of AMSes - indexed by the connection identifier */
    public static ConnectedAMS ConnectedStations[] = new ConnectedAMS[MAX_CONNECTED_STATIONS];

    /* The list of simulated input messages */
    static InputDatum inputMessageFiles[] = {
	new InputDatum("reg1.uper", 1, "Registering first station"),
	new InputDatum("reg2.uper", 2, "Registering second station"),
	new InputDatum("idle1.uper", 1, "First station goes to idle mode"),
	new InputDatum("reg3.uper", 3, "Registering third station"),
	new InputDatum("dcr1.uper", 3, "Third station goes to DCR mode"),
	new InputDatum("dereg1.uper", 2, "Deregistering second station"),
	new InputDatum("reg1.uper", 1, "First station reentry"),
	new InputDatum("reg3.uper", 3, "Third station reentry"),
	new InputDatum("dereg1.uper", 1, "Deregistering first station"),
	new InputDatum("dereg1.uper", 3, "Deregistering third station")
    };

    /*
     * Static binary data to be used in responses. They are just some example
     * values with no particular meaning. A real ABS will use real meaningful
     * values instead.
     */

    /* 15 bits */
    static byte[] responseMask = new byte[] {(byte)0x80, (byte)0x64};
    /* 72 bits */
    static byte[] responseCRID =
	new byte[] {(byte)0x12, (byte)0x34, (byte)0x56, (byte)0x78, (byte)0x9A,
		    (byte)0xBC, (byte)0xDE, (byte)0xF0, (byte)0xEE};
    /* 4 octets */
    static byte[] responseIP =
	new byte[] {(byte)0x0A, (byte)0x0B, (byte)0x0C, (byte)0x0D};
    /* Up to 1024 octets (just a sample meaningless value) */
    static byte[] responseAdditionalHostParameters =
	new byte[] {(byte)0x01, (byte)0x02, (byte)0x03, (byte)0x04};

    /* Global carrier config change count */
    static byte responseGlobalCarrierConfigChangeCount = 1;
    /* CSG ID Length (can be up to 24 */
    static byte responseCSGIdLength = 10;

    /* Paging controller ID - 48 bits */
    static byte[] responsePagingController =
	new byte[] {(byte)0x01, (byte)0x02, (byte)0x03,
		    (byte)0x04, (byte)0x05, (byte)0x06};
    /* Paging group ID - 16 bits */
    static byte[] responsePagingGroup =  new byte[] {0x12, 0x34};

    /*
     * Control mask for IP addresses (it is assumed the last byte of IP address
     * can be only from 1 to 8).
     */
    static short ip_addr_mask = 0;

    /* Control mask for STIDs (from 1 to 8) */
    static short stid_mask = 0;

    /* Control mask for paging offsets (from 1 to 8) */
    static short pgoffset_mask = 0;

    /* Redirection info array (2 entries just for example) */
    static RedirectionInfo[] responseRedirectionArray =
	new RedirectionInfo[] {
	    new RedirectionInfo(
		new BSID(new byte[]{
		    (byte)0x01, (byte)0x02, (byte)0x03, (byte)0x04,
		    (byte)0x05, (byte)0x06}, 48),
		new PreambleIndex(111),
		new CenterFreq(11000000)
	    ),
	    new RedirectionInfo(
		new BSID(new byte[]{(byte)0x11, (byte)0x22, (byte)0x33, 
				    (byte)0x44, (byte)0x55, (byte)0x66}, 48),
		new PreambleIndex(555),
		new CenterFreq(13000000)
	    )
	};

    static Coder coder;
    static int messageCount;
    static byte source[];
    static String border = "-------------------------------------------------------";

    public static void main(String[] args) throws java.io.FileNotFoundException, Exception
    {
	// Initialize the project
	try {
	    Wimax.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = Wimax.getPERUnalignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	for(int i = 0; i < ConnectedStations.length; i++){
	    ConnectedStations[i] = new ConnectedAMS();
	}

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;

	int connection = 0;
	try {
	    connection = receiveMessage(path);
	} catch (IOException e) {
	    System.out.println(e);
	}

	while(connection > 0) {
	    MAC_Control_Message request = null;
	    MAC_Control_Message response;

	    System.out.println(border);
	    System.out.println("Serialized  incoming message from connection "
			+ connection + " (" + source.length + " bytes):");
	    System.out.println(border);
	    System.out.println(toHstring(source));
	    System.out.println("\nThe decoder trace messages:\n");

	    /*
	     * Decode the PDU (MAC_Control_Message)
	     */
	    try {
		request = (MAC_Control_Message)coder.decode(
		    new ByteArrayInputStream(source), new MAC_Control_Message());
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoding failed: " + e);
		System.exit(2);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoding failed: " + e);
		System.exit(2);
	    }

	    /* Print the message contents */
	    System.out.println("\nDeserialized incoming message:");
	    System.out.println(border);
    	    System.out.println(request);

	    /* Access components of the message */
	    printMACControlMessage(request);

	    /* Process the request and create the response message */
	    response = processMACControlMessage(request, connection);
	    System.out.println("\nConstructed response PDU:");
	    System.out.println(border);
    	    System.out.println(response);
	    System.out.println("The encoder trace messages:\n");

	    /*
	     * Set the output stream.
	     */
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    try {
		coder.encode(response, out);
		out.close();
	    } catch (Exception e) {
		System.out.println("Encoding failed: " + e);
		System.exit(1);
	    }

	    /*
	     * "Send" the encoded message (the example application simply prints
	     * it to the standard output in the binary form)
	     */
	    sendMessage(out, connection);

	    /* Print the ABS status */
	    printStatus();
	    System.out.println();
	    messageCount++;

	    try {
		connection = receiveMessage(path);
	    } catch (IOException e) {
		System.out.println(e);
	    }
	}

	Wimax.deinitialize();
    }

    /*
     * Reads a current input message. The example application simply reads
     * messages from external files (taking the file names from the
     * InputMessageFiles array). However this function can easily be
     *  changed to use any other source.
     */
    static int receiveMessage(String path) throws IOException
    {
	InputDatum currentData;

	if (messageCount < inputMessageFiles.length)
	    currentData = inputMessageFiles[messageCount];
	else
	    return -1;

	File file = new File(path, currentData.getFileName());
	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}
	System.out.println(border);
	System.out.println(currentData.getComment());

	source = new byte[(int)file.length()];
	int  bufpos = 0;
	int c;

	FileInputStream in = new FileInputStream(file);

	while ((c = in.read()) != -1)
	    source[bufpos++] = (byte)c;

	in.close();
	return currentData.getConnection();
    }

    /*
     * Outputs a message. The example application simply prints a binary
     * dump of the message to the standard output. However this function
     * can easily be changed as needed.
     */
    static void sendMessage(ByteArrayOutputStream out, int connection)
    {
	byte[] encoding = out.toByteArray();
	System.out.println("\nSerialized response to connection " 
	    + connection + " (" + encoding.length + " bytes):");
	System.out.println(border);
	System.out.println(toHstring(encoding) + "\n");
    }

    /*
     * Reads a MAC control message, performs the needed changes in the ABS data
     * and returns the response message. Only AAI_REG_REQ and AAI_DREG_REQ
     * messages are implemented in this example, but the method can be easily
     * extended to process other messages.
     */
    static MAC_Control_Message processMACControlMessage(
		MAC_Control_Message msg, int connection)
    throws Exception
    {
	switch (msg.getMessage().getChosenFlag()) {
	case MAC_Control_Msg_Type.aaiRegReq_chosen:
	    return processAAIRegReq(
		(AAI_REG_REQ)msg.getMessage().getChosenValue(), connection);
	case MAC_Control_Msg_Type.aaiDregReq_chosen:
	    return processAAIDregReq(
		(AAI_DREG_REQ)msg.getMessage().getChosenValue(), connection);
	default:
	    /* other message types are not implemented */
	    System.out.println("Unsupported message type " 
		    + msg.getMessage().getChosenFlag()
		    + "; not implemented in this example");
	    return null;
	}
    }

    /*
     * Reads an AAI_REG_REQ message, performs the needed changes
     * in the ABS data, and returns the response message
     */
    static MAC_Control_Message processAAIRegReq(
		    AAI_REG_REQ value, int connection)
    {
	MAC_Control_Message response = null;

	/* store MAC address */
	ConnectedStations[connection].setMACAddress(
	    (byte[])value.getAmsMacAddress().byteArrayValue().clone());

	if (!ConnectedStations[connection].getAddressValid()) {
	    /* If no IP address is assigned to the AMS, assign a new one */
	    try {
		ConnectedStations[connection].setIPAddress(allocateNewIP());
	    } catch (Exception e) {
		System.out.println(e);
		return createAbortMessage();
	    }
	}

	if (!ConnectedStations[connection].getStidValid()) {
	    /* If no STID is assigned to the AMS, assign a new one */
	    try {
		ConnectedStations[connection].setStid(allocateNewSTID());
	    } catch (Exception e) {
		System.out.println(e);
		return createAbortMessage();
	    }
	}

	/* Mark the AMS as active */
	ConnectedStations[connection].setAddressValid(true);
	ConnectedStations[connection].setStidValid(true);
	ConnectedStations[connection].setStatus(ConnectedAMS.AMS_connected);

	/* Create the response message */
	try {
	    return createAAIRegRsp(
			ConnectedStations[connection].getIPAddress(),
			ConnectedStations[connection].getStid());
	} catch (Exception e) {
	    System.out.println(e);
	    return createAbortMessage();
	}
    }

    /*
     * Creates a sample registration response (AAI_REG_RSP) using the 
     * static sample data. Also, the response data reports the minimally
     * possible EBS capabilities.
     */
    static MAC_Control_Message createAAIRegRsp(byte[] ipAddress, short con_stid)
    throws Exception
    {
	/* Set STID */
	byte[] stidValue = new byte[] {(byte)(con_stid >> 4),
				       (byte)((con_stid & 0x0F) << 4)};
	STID stid = new STID(stidValue, 12);

	/* Set MAPMask seed */
	MapMaskSeed mapMaskSeed =
	    new MapMaskSeed((byte[])responseMask.clone(), 15);

	/* Set AAI_REG_RSP.StidAndMAPMaskSeed */
	AAI_REG_RSP.StidAndMAPMaskSeed stidAndMAPMaskSeed =
	    new AAI_REG_RSP.StidAndMAPMaskSeed(stid, mapMaskSeed);

	/* Set CRID */
	CRID crid = new CRID((byte[])responseCRID.clone(), 72);

	/* Set imCapabilities to string of zeros */
	ImCapabilities imCapabilities = new ImCapabilities(new byte[1], 5);

	/* Set embsCapabilities to string of zeros */
	EmbsCapabilities embsCapabilities = new EmbsCapabilities(new byte[1], 3);

	/* Set hoTriggerMetric to zero string */
	ReportMetric hoTriggerMetric = new ReportMetric(new byte[1], 4);

	/* Set csSpecificationTypes to IPv4 only */
	CsSpecificationTypes csSpecificationTypes =
	    new CsSpecificationTypes(new byte[2], 16);
	csSpecificationTypes.setBit(CsSpecificationTypes.packetIpv4);

	CsCapabilities csCapabilities = new CsCapabilities();
	csCapabilities.setCsSpecificationTypes(csSpecificationTypes);

	/* Set maxNoOfClassificationRules, rohc, and resourceRetainTime */
	csCapabilities.setMaxNoOfClassificationRules(0);
	csCapabilities.setRohc(FeatureSupport.notSupported);
	csCapabilities.setResourceRetainTime(0);

	/* Set ipv4HostAddress */
	byte[] ipv4HostAddressValue = new byte[4];
	System.arraycopy(ipAddress, 0, ipv4HostAddressValue , 0, 
			ipAddress.length);
	IPv4Address ipv4HostAddress = new IPv4Address((byte[])ipAddress.clone());

	/* Set additionalHostConfigIe */
	OctetString additionalHostConfigIe =
	    new OctetString((byte[])responseAdditionalHostParameters.clone());

	/* Redirection info - it's easier to copy it in the backward order */
	AAI_REG_RSP.RedirectionInfoArray redirectionInfoArray =
	    new AAI_REG_RSP.RedirectionInfoArray(
		(RedirectionInfo[])responseRedirectionArray.clone());

	/* Set the AAI-REG-RSP message */
	AAI_REG_RSP aaiRegRsp = new AAI_REG_RSP();
	aaiRegRsp.setStidAndMAPMaskSeed(stidAndMAPMaskSeed);
	aaiRegRsp.setCrid(crid);

	/* femtoAbsLdm missing */
	aaiRegRsp.setAgpsMethod(FeatureSupport.notSupported);
	aaiRegRsp.setImCapabilities(imCapabilities);

	/* antennaConfig missing */
	aaiRegRsp.setEmbsCapabilities(embsCapabilities);
	aaiRegRsp.setPersistentAllocation(FeatureSupport.notSupported);
	aaiRegRsp.setGroupResourceAllocation(FeatureSupport.notSupported);
	aaiRegRsp.setHoTriggerMetric(hoTriggerMetric);
	aaiRegRsp.setCsCapabilities(csCapabilities);
	aaiRegRsp.setIpv4HostAddress(ipv4HostAddress);

	/* ipv6HomeNetworkPrefix missing */
	aaiRegRsp.setAdditionalHostConfigIe(additionalHostConfigIe);
	aaiRegRsp.setRedirectionInfoArray(redirectionInfoArray);
	aaiRegRsp.setCsgIdlength(responseCSGIdLength);
	aaiRegRsp.setGlobalCarrierCfgChangeCount(
		responseGlobalCarrierConfigChangeCount);
	aaiRegRsp.setMulticarrierCapabilities(McCapabilities.noMcModes);

	/* csTypeOfDefaultServiceFlow and clcLimits missing */
	aaiRegRsp.setAmsInitAgpServiceAdaptation(FeatureSupport.notSupported);
	MAC_Control_Msg_Type message =
	    MAC_Control_Msg_Type.createMAC_Control_Msg_TypeWithAaiRegRsp(aaiRegRsp);

	return new MAC_Control_Message(message);
    }

    /*
     * Reads an AAI_DREG_REQ message, performs the needed changes
     * in the ABS data, and returns the response message
     */
    static MAC_Control_Message processAAIDregReq(
		AAI_DREG_REQ value, int connection)
    {
	switch (value.getDeRegReqCode().getChosenFlag()) {
	case AAI_DREG_REQ.DeRegReqCode.deregFromABSAndNetwork_chosen:
	{    /* Complete deregistration */
	    if (ConnectedStations[connection].getAddressValid()) {
		/* If the IP address is valid, free it */
		ip_addr_mask = freeIPAddress(
			ConnectedStations[connection].getIPAddress());
		ConnectedStations[connection].setAddressValid(false);
	    }

	    if (ConnectedStations[connection].getStidValid()) {
		/* If the STID is valid, free it */
		stid_mask = freeSTID(ConnectedStations[connection].getStid());
		ConnectedStations[connection].setStidValid(false);
	    }

	    /* The array slot is now unused */
	    ConnectedStations[connection].setStatus(ConnectedAMS.AMS_unused);

	    /* Create response */
	    AAI_DREG_RSP.ActionCode actionCode =
		AAI_DREG_RSP.ActionCode.createActionCodeWithAttempyNewNtwkEntry(
								    new Null());
	    AAI_DREG_RSP aaiDregRsp = new AAI_DREG_RSP(actionCode);
	    MAC_Control_Msg_Type message =
		MAC_Control_Msg_Type.createMAC_Control_Msg_TypeWithAaiDregRsp(
								    aaiDregRsp);
	    return new MAC_Control_Message(message);
	}
	case AAI_DREG_REQ.DeRegReqCode.deregAndInitIdleMode_chosen:
	{
	    /* Switch to idle mode */
	    DeregAndInitIdleMode deregAndInitIdleMode =
		(DeregAndInitIdleMode)value.getDeRegReqCode().getChosenValue();
	    PgCycle pagingCycle = deregAndInitIdleMode.getPgCycleReq();
	    try {
		ConnectedStations[connection].setPagingOffset(
					allocatePagingOffset());
	    } catch (Exception e) {
		System.out.println(e);
		return createAbortMessage();
	    }

	    PgOffset pagingOffset =
		ConnectedStations[connection].getPagingOffset();
	    PCID pagingControllerId =
		new PCID((byte[])responsePagingController.clone(), 48);
	    PGID pagingGroupId =
		new PGID((byte[])responsePagingGroup.clone(), 16);
	    IdleModeRetain idleModeRetainInfo =
		new IdleModeRetain(
		    (byte[])deregAndInitIdleMode.getIdleModeRetainInfo().byteArrayValue().clone(), 5);

	    AllowIdleModeInitiationRequest idlerec =
		new AllowIdleModeInitiationRequest();
	    idlerec.setPagingCycle(pagingCycle);
	    idlerec.setPagingOffset(pagingOffset);
	    idlerec.setPagingControllerId(pagingControllerId);
	    idlerec.setPagingGroupId(pagingGroupId);
	    idlerec.setIdleModeRetainInfo(idleModeRetainInfo);

	    if (ConnectedStations[connection].getStidValid()
		&& !idlerec.getIdleModeRetainInfo().getBit(
				IdleModeRetain.regMessages)) {
		/*
		 * if STID is assigned and registration info retention is not
		 * requested, free the STID
		 */
		stid_mask = freeSTID(ConnectedStations[connection].getStid());
		ConnectedStations[connection].setStidValid(false);
	    }

	    if (ConnectedStations[connection].getAddressValid()
		&& !idlerec.getIdleModeRetainInfo().getBit(
				    IdleModeRetain.networkAddr)) {
		/*
		 * if IP adress is assigned and network address retention
		 * is not requested, free the IP address
		 */
		ip_addr_mask = freeIPAddress(
			ConnectedStations[connection].getIPAddress());
		ConnectedStations[connection].setAddressValid(false);
	    }

	    /* mark the AMS as idle */
	    ConnectedStations[connection].setStatus(ConnectedAMS.AMS_idle);

	    AAI_DREG_RSP.ActionCode actionCode =
		AAI_DREG_RSP.ActionCode.createActionCodeWithAllowIdleModeInitiationRequest(idlerec);
	    AAI_DREG_RSP aaiDregRsp = new AAI_DREG_RSP(actionCode);
	    MAC_Control_Msg_Type message =
		MAC_Control_Msg_Type.createMAC_Control_Msg_TypeWithAaiDregRsp(aaiDregRsp);
	    return new MAC_Control_Message(message);
	}
	case AAI_DREG_REQ.DeRegReqCode.deregToEnterDcrMode_chosen:
	{    /* Enter DCR mode */
	    ConnectedStations[connection].setStatus(ConnectedAMS.AMS_dcr);

	    AAI_DREG_RSP.ActionCode actionCode =
		AAI_DREG_RSP.ActionCode.createActionCodeWithAllowConnectionInfoRetention(new Null());
	    AAI_DREG_RSP aaiDregRsp = new AAI_DREG_RSP(actionCode);
	    MAC_Control_Msg_Type message =
		MAC_Control_Msg_Type.createMAC_Control_Msg_TypeWithAaiDregRsp(aaiDregRsp);

	    IdleModeRetain idleModeRetainInfo = ((DeregToEnterDcrMode)
		value.getDeRegReqCode().getChosenValue()).getIdleModeRetainInfo();
	    if (ConnectedStations[connection].getStidValid()
		&& !idleModeRetainInfo.getBit(IdleModeRetain.regMessages)) {
		/*
		 * if STID is assigned and registration info retention is not
		 * requested, free the STID
		 */
		stid_mask = freeSTID(ConnectedStations[connection].getStid());
		ConnectedStations[connection].setStidValid(false);
	    }

	    if (ConnectedStations[connection].getAddressValid()
		&& !idleModeRetainInfo.getBit(IdleModeRetain.networkAddr)) {
		/*
		 * if IP adress is assigned and network address retention is not
		 * requested, free the IP address
		 */
		ip_addr_mask = freeIPAddress(
			ConnectedStations[connection].getIPAddress());
		ConnectedStations[connection].setAddressValid(false);
	    }

	    return new MAC_Control_Message(message);
	}
	default:
	    return createAbortMessage();
	}
    }

    /*
     * Creates a registration abort message (AAI_RNG_RSP with RangingAbort == 1).
     * Called in case of an error.
     */
    static MAC_Control_Message createAbortMessage()
    {
	/* Set ranging abort timer not to try ranging again */
	AAI_RNG_RSP.TimerOrSTID timerOrSTID =
	    AAI_RNG_RSP.TimerOrSTID.createTimerOrSTIDWithRangingAbortTimer(0);
	/* Set the AAI-RNG-RSP message */
	AAI_RNG_RSP aaiRngRsp = new AAI_RNG_RSP(true, timerOrSTID);

	MAC_Control_Msg_Type message =
	    MAC_Control_Msg_Type.createMAC_Control_Msg_TypeWithAaiRngRsp(aaiRngRsp);

	return new MAC_Control_Message(message);
    }

    /*
     * Prints a MAC control message by components. Only AAI_REG_REQ and
     * AAI_DREG_REQ messages are implemented in this example but the
     * method can be easily extended to other types
     */
    static void printMACControlMessage(MAC_Control_Message msg)
    {
	MAC_Control_Msg_Type msgType = msg.getMessage();
	switch (msgType.getChosenFlag()) {
	    case MAC_Control_Msg_Type.aaiRegReq_chosen:
		printAAIRegReq((AAI_REG_REQ)msgType.getChosenValue());
		break;
	    case MAC_Control_Msg_Type.aaiDregReq_chosen:
		printAAIDregReq((AAI_DREG_REQ)msgType.getChosenValue());
		break;
	    default:
		/* other message types are not implemented */
		System.out.println("Unsupported message type "
			    + msgType.getChosenFlag()
			    + " cannot print the contents");
	}
    }

    /*
     * Prints an AAI_REG_REQ value by components
     */
    static void printAAIRegReq(AAI_REG_REQ value)
    {
	System.out.println("Getting message information");
	System.out.println(border);

	/* amsMacAddress */
	System.out.print("AMS MAC Address = " +
	    toHstring(value.getAmsMacAddress().byteArrayValue()) + "\n");

	/* amsCapNegotiation */
	System.out.println("AMS Capability Negotiation:");

	if (isNullEnumElements(
		value.getAmsCapNegotiation().enumeratedComponents()))
	    System.out.print("\t<Empty>\n");
	else {
	    /* maxARQBufferSize */
	    if (value.getAmsCapNegotiation().hasMaxARQBufferSize())
		System.out.println("\tMax ARQ buffer size = " +
		    value.getAmsCapNegotiation().getMaxARQBufferSize());

	    /* maxNonARQBufferSize */
	    if (value.getAmsCapNegotiation().hasMaxNonARQBufferSize())
		System.out.println("\tMax non-ARQ buffer size = " +
		    value.getAmsCapNegotiation().getMaxNonARQBufferSize());

	    /* multicarrierCapabilities */
	    if (value.getAmsCapNegotiation().hasMulticarrierCapabilities()) {
		McCapabilities mcCapabilities =
		    value.getAmsCapNegotiation().getMulticarrierCapabilities();
		System.out.print("\tMulti-carrier capabilities: ");
		if (mcCapabilities.equalTo(McCapabilities.noMcModes))
		    System.out.println("no MC modes");
		else if (mcCapabilities.equalTo(McCapabilities.basicMcMode))
		    System.out.println("basic MC mode");
		else if (mcCapabilities.equalTo(McCapabilities.mcAggregation))
		    System.out.println("MC aggregation");
		else if (mcCapabilities.equalTo(McCapabilities.mcSwitching))
		    System.out.println("MC switching");
		else if (mcCapabilities.equalTo(
			    McCapabilities.mcAggregationAndSwitching))
		    System.out.println("MC aggregation and switching");
		else
		    System.out.println("invalid value ( " +
			    mcCapabilities + ")");
	    }

	    /* zoneSwitchingMode */
	    if (value.getAmsCapNegotiation().hasZoneSwitchingMode()) {
		System.out.print("\tZone switching mode: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getZoneSwitchingMode());
	    }

	    /* agpsMethod */
	    if (value.getAmsCapNegotiation().hasAgpsMethod()) {
		System.out.print("\tA-GPS Method: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getAgpsMethod());
	    }

	    /* imCapabilities */
	    if (value.getAmsCapNegotiation().hasImCapabilities()) {
		ImCapabilities imCapabilities =
		    value.getAmsCapNegotiation().getImCapabilities();
		System.out.println("\tIM Capabilities:");
		if (imCapabilities.byteArrayValue().length == 0)
		    System.out.println("\t\t<None>");
		else {
		    if (imCapabilities.getBit(ImCapabilities.dlPMICoordination))
			System.out.println("\t\tDL PMI Coordination");

		    if (imCapabilities.getBit(
			    ImCapabilities.dlCollaborativeMBSMIMO))
			System.out.println("\t\tDL Collaborative MBS MIMO");

		    if (imCapabilities.getBit(
			    ImCapabilities.dlClosedLoopMbsMacroDiversity))
			System.out.println(
			    "\t\tDL Closed Loop MBS Macro Diversity");

		    if (imCapabilities.getBit(ImCapabilities.ulPmiCombination))
			System.out.println("\t\tUL PMI Combination");

		    if (imCapabilities.getBit(ImCapabilities.multiBsSoundingCalibration))
			System.out.println("\t\tMulti-BS Sounding Calibration");
		}
	    }

	    /* embsCapabilities */
	    if (value.getAmsCapNegotiation().hasEmbsCapabilities()) {
		EmbsCapabilities embsCapabilities =
		    value.getAmsCapNegotiation().getEmbsCapabilities();
		System.out.println("\tE-MBS Capabilities:");
		if (embsCapabilities.byteArrayValue().length == 0)
		    System.out.println("\t\t<None>");
		else {
		    if (embsCapabilities.getBit(
			    EmbsCapabilities.servingAbsOnly))
			System.out.println("\t\tS-ABS only");

		    if (embsCapabilities.getBit(
			    EmbsCapabilities.macroDiversityMultiAbs))
			System.out.println("\t\tMacro diversity multi ABS");

		    if (embsCapabilities.getBit(
			    EmbsCapabilities.nonMacroDiversityMultiAbs))
			System.out.println(
			    "\t\tNon-macro-diversity multi ABS");
		}
	    }

	    /* channelBwAndCyclicPrefix */
	    if (value.getAmsCapNegotiation().hasChannelBwAndCyclicPrefix()) {
		AmsCapabilities.ChannelBwAndCyclicPrefix channelBwAndCyclicPrefix =
		    value.getAmsCapNegotiation().getChannelBwAndCyclicPrefix();
		System.out.println("\tChannel BW and cyclic prefix:");

		if (channelBwAndCyclicPrefix.byteArrayValue().length == 0)
		    System.out.println("\t\t<None>");
		else {
		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.fiveMHz1Over16))
			System.out.println("\t\t5 MHz (1/16 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.fiveMHz1Over8))
			System.out.println("\t\t5 MHz (1/8 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.fiveMHz1Over4))
			System.out.println("\t\t5 MHz (1/4 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.tenMHz1Over16))
			System.out.println("\t\t10 MHz (1/16 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.tenMHz1Over8))
			System.out.println("\t\t10 MHz (1/8 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.tenMHz1Over4))
			System.out.println("\t\t10 MHz (1/4 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.twentyMHz1Over16))
			System.out.println("\t\t20 MHz (1/16 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.twentyMHz1Over8))
			System.out.println("\t\t20 MHz (1/8 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.twentyMHz1Over4))
			System.out.println("\t\t20 MHz (1/4 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.eightDotSevenFiveMHz1Over16))
			System.out.println("\t\t8.75 MHz (1/16 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.eightDotSevenFiveMHz1Over8))
			System.out.println("\t\t8.75 MHz (1/8 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.eightDotSevenFive5MHz1Over4))
			System.out.println("\t\t8.75 MHz (1/4 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.sevenMHz1Over16))
			System.out.println("\t\t7 MHz (1/16 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.sevenMHz1Over8))
			System.out.println("\t\t7 MHz (1/8 CP)");

		    if (channelBwAndCyclicPrefix.getBit(
			    AmsCapabilities.ChannelBwAndCyclicPrefix.sevenMHz1Over4))
			System.out.println("\t\t7 MHz (1/4 CP)");
		}
	    }

	    /* frameConfigOfLegacyR1 */
	    if (value.getAmsCapNegotiation().hasFrameConfigOfLegacyR1()) {
		LegacyR1Support legacyR1Support =
		    value.getAmsCapNegotiation().getFrameConfigOfLegacyR1();
		System.out.print("\tFrame config of legacy R1.0: ");

		if (legacyR1Support.getBit(LegacyR1Support.fiveMHz))
		    System.out.print("5 MHz  ");

		if (legacyR1Support.getBit(LegacyR1Support.tenMHz))
		    System.out.print("10 MHz  ");

		if (legacyR1Support.getBit(LegacyR1Support.eightDotSevenFiveMHz))
		    System.out.print("8.75 MHz  ");

		if (legacyR1Support.getBit(LegacyR1Support.sevenMHz))
		    System.out.print("7 MHz  ");

		System.out.println();
	    }

	    /* persistentAllocation */
	    if (value.getAmsCapNegotiation().hasPersistentAllocation()) {
		System.out.print("\tPersistent allocation: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getPersistentAllocation());
	    }

	    /* groupResourceAllocation */
	    if (value.getAmsCapNegotiation().hasGroupResourceAllocation()) {
		System.out.print("\tGroup resource allocation: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getGroupResourceAllocation());
	    }

	    /* coLocatedCoexistence */
	    if (value.getAmsCapNegotiation().hasCoLocatedCoexistence()) {
		AmsCapabilities.CoLocatedCoexistence coLocatedCoexistence =
		    value.getAmsCapNegotiation().getCoLocatedCoexistence();
		System.out.println("\tCo-located coexistence capability:");

		if (coLocatedCoexistence.byteArrayValue().length == 0)
		    System.out.println("\t\t<None>");
		else {
		    if (coLocatedCoexistence.getBit(
			    AmsCapabilities.CoLocatedCoexistence.typeI))
			System.out.println("\t\tType I");

		    if (coLocatedCoexistence.getBit(
			    AmsCapabilities.CoLocatedCoexistence.typeII_1))
			System.out.println("\t\tType II subtype 1");

		    if (coLocatedCoexistence.getBit(
			    AmsCapabilities.CoLocatedCoexistence.typeII_2))
			System.out.println("\t\tType II subtype 2");

		    if (coLocatedCoexistence.getBit(
			    AmsCapabilities.CoLocatedCoexistence.typeII_3))
			System.out.println("\t\tType II subtype 3");

		    if (coLocatedCoexistence.getBit(
			    AmsCapabilities.CoLocatedCoexistence.typeIII))
			System.out.println("\t\tType III");
		}
	    }

	    /* hoTriggerMetric */
	    if (value.getAmsCapNegotiation().hasHoTriggerMetric()) {
		ReportMetric hoTriggerMetric =
		    value.getAmsCapNegotiation().getHoTriggerMetric();
		System.out.println("\tHO trigger metric:");
		if (hoTriggerMetric.byteArrayValue().length == 0)
		    System.out.println("\t\t<None>");
		else {
		    if (hoTriggerMetric.getBit(ReportMetric.absCINRMean))
			System.out.println("\t\tABS CINR mean");

		    if (hoTriggerMetric.getBit(ReportMetric.absRSSIMean))
			System.out.println("\t\tABS RSSI mean");

		    if (hoTriggerMetric.getBit(ReportMetric.relativeDelay))
			System.out.println("\t\tRelative delay");

		    if (hoTriggerMetric.getBit(ReportMetric.absRTD))
			System.out.println("\t\tABS RTD");
		}
	    }

	    /* ebbHandover */
	    if (value.getAmsCapNegotiation().hasEbbHandover()) {
		System.out.print("\tEBB operation during handover: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getEbbHandover());
	    }

	    /* minHoRentryIntlvInterval */
	    if (value.getAmsCapNegotiation().hasMinHoRentryIntlvInterval()) {
		System.out.println("\tMinimal handover reentry interleaving interval = "
		    + value.getAmsCapNegotiation().getMinHoRentryIntlvInterval());
	    }

	    /* soundingAntSwitching */
	    if (value.getAmsCapNegotiation().hasSoundingAntSwitching()) {
		System.out.print("\tSounding antenna switching: ");
		printFeatureSupport(
		    value.getAmsCapNegotiation().getSoundingAntSwitching());
	    }

	    /* antennaConfig */
	    if (value.getAmsCapNegotiation().hasAntennaConfig()) {
		SoundingAntennaSw antennaConfig =
		    value.getAmsCapNegotiation().getAntennaConfig();
		System.out.print("\tAntenna configuration: ");

		if (antennaConfig.equalTo(SoundingAntennaSw.amongDLRx))
		    System.out.println("among DL Rx antennas");
		else if (antennaConfig.equalTo(SoundingAntennaSw.amongULTx))
		    System.out.println("among UL Tx antennas");
		else
		    System.out.println("invalid value (" + antennaConfig + ")");
	    }
	}

	/* csCapabilities */
	System.out.println("CS Capabilities:");
	if (isNullEnumElements(value.getCsCapabilities().enumeratedComponents()))
	    System.out.print("\t<Empty>\n");
	else {
	    /* csSpecificationTypes */
	    if (value.getCsCapabilities().hasCsSpecificationTypes()) {
		boolean known = false;  /* to see if any known bits are present */

		System.out.println("\tCS specification types = " +
		    toHstring(value.getCsCapabilities().getCsSpecificationTypes().byteArrayValue()));

		System.out.println("\t\tKnown bits:");
		if (value.getCsCapabilities().getCsSpecificationTypes().getBit(
			    CsSpecificationTypes.packetIpv4)) {
		    System.out.println("\t\t\tIPv4 packets");
		    known = true;
		}

		if (value.getCsCapabilities().getCsSpecificationTypes().getBit(
			    CsSpecificationTypes.packetIpv6)) {
		    System.out.println("\t\t\tIPv6 packets");
		    known = true;
		}

		if (value.getCsCapabilities().getCsSpecificationTypes().getBit(
			CsSpecificationTypes.packetEthernet)) {
		    System.out.println("\t\t\tEthernet packets");
		    known = true;
		}

		if (value.getCsCapabilities().getCsSpecificationTypes().getBit(
			CsSpecificationTypes.packetIpv4OrIpv6)) {
		    System.out.println("\t\t\tIPv4 or IPv6 packets");
		    known = true;
		}

		if (value.getCsCapabilities().getCsSpecificationTypes().getBit(
			CsSpecificationTypes.multiProtocol)) {
		    System.out.println("\t\t\tMultiprotocol flow");
		    known = true;
		}
		if (!known)
		    System.out.println("\t\t\t<None>");
	    }

	    /* maxNoOfClassificationRules */
	    if (value.getCsCapabilities().hasMaxNoOfClassificationRules()) {
		System.out.println(
		    "\tMaximum number of classification rules = " +
		    value.getCsCapabilities().getMaxNoOfClassificationRules());
	    }

	    /* rohc */
	    if (value.getCsCapabilities().hasRohc()) {
		System.out.print("\tROHC: ");
		printFeatureSupport(value.getCsCapabilities().getRohc());
	    }

	    /* phs */
	    if (value.getCsCapabilities().hasPhs()) {
		System.out.println("\tPHS support level = " +
		    value.getCsCapabilities().getPhs().longValue() + " ("
		    + (value.getCsCapabilities().getPhs().equalTo(
			    CsCapabilities.Phs.packetPhs) ?
			    "packet PHS" : "reserved") + ")");
	    }

	    /* resourceRetainTime */
	    if (value.getCsCapabilities().hasResourceRetainTime()) {
		System.out.println("\tResource retain time = "
		    + value.getCsCapabilities().getResourceRetainTime());
	    }
	}

	/* hostCfgCapIndicator */
	System.out.print("Host configuration capability indicator: ");
	printFeatureSupport(value.getHostCfgCapIndicator());

	/* requestedHostConfig */
	if (value.hasRequestedHostConfig()) {
	    System.out.print("Requested host config\n\t");
	    System.out.println(toHstring(
		value.getRequestedHostConfig().byteArrayValue()));
	}

	/* globalCarrierConfigChangeCount */
	System.out.println("Global carrier config change count = "
			   + value.getGlobalCarrierConfigChangeCount());

	/* amsInitAgpServiceAdaptation */
	if (value.hasAmsInitAgpServiceAdaptation()) {
	    System.out.print("AMS initiated aGP Service Adaptation: ");
	    printFeatureSupport(value.getAmsInitAgpServiceAdaptation());
	}
    }

    /*
     * Prints an AAI_DREG_REQ value by components
     */
    static void printAAIDregReq(AAI_DREG_REQ value)
    {
	System.out.println("Getting message information");
	System.out.println(border);

	switch (value.getDeRegReqCode().getChosenFlag()) {
	case AAI_DREG_REQ.DeRegReqCode.deregFromABSAndNetwork_chosen:
	    System.out.println("Deregister from ABS and network");
	    break;
	case AAI_DREG_REQ.DeRegReqCode.deregAndInitIdleMode_chosen:
	    {
		/* A temporary pointer just to make the code smaller */
		DeregAndInitIdleMode info =
		    (DeregAndInitIdleMode)value.getDeRegReqCode().getChosenValue();

		System.out.println("Deregister from ABS and enter idle mode");
		System.out.println("\tRecommended paging cycle = " +
				info.getPgCycleReq().intValue() +
				" (" + textualPagingCycle(info.getPgCycleReq()) + ")");
		printIdleModeRetain(info.getIdleModeRetainInfo());
		if (info.hasMobilityInfo()) {
		    System.out.println("\tMobility: ");
		    if (info.getMobilityInfo().equalTo(AMSMobilityLevel.slow))
		        System.out.println("slow");
		    else if (info.getMobilityInfo().equalTo(AMSMobilityLevel.medium))
			System.out.println("medium");
		    else if (info.getMobilityInfo().equalTo(AMSMobilityLevel.fast))
			System.out.println("fast");
		    else
			System.out.println("invalid value (" +
					    info.getMobilityInfo().longValue() + ")");
		}
	    }
	    break;
	case AAI_DREG_REQ.DeRegReqCode.unsolicitedDeregRspWithAct05_chosen:
	    System.out.println("Unsolicited AAI-DREG-REQ response (code = 0x05)");
	    break;
	case AAI_DREG_REQ.DeRegReqCode.rejectUnsolicitedDeregRsp_chosen:
	    System.out.println("Reject unsloicited AAI-DREG-REQ response");
	    break;
	case AAI_DREG_REQ.DeRegReqCode.deregToEnterDcrMode_chosen:
	    System.out.println("Deregister from ABS and enter DCR mode");
	    printIdleModeRetain(((DeregToEnterDcrMode)
		value.getDeRegReqCode().getChosenValue()).getIdleModeRetainInfo());
	    break;
	case AAI_DREG_REQ.DeRegReqCode.unsolicitedDeregRspWithAct00_01_02_03_chosen:
	    System.out.println("Unsolicited AAI-DREG-REQ response (code != 0x05)\n");
	    break;
	default:
	    System.out.println("Invalid value (selector = " +
			    value.getDeRegReqCode().getChosenFlag() + ")");
	    break;
	}
    }

    /*
     *  Prints the ABS data (connected AMSes, their states,
     *	IP addresses, STIDs, etc.)
     */
    static void printStatus()
    {
	ConnectedAMS ams;
	System.out.println("Connected stations:");
	System.out.println(border);
	/* scan the array of AMSes */
	for (int i = 0; i < MAX_CONNECTED_STATIONS; i++) {
	    if (ConnectedStations != null 
		&& ConnectedStations[i].getStatus() != ConnectedAMS.AMS_unused) {
		/* if the array slot is not unused */
		ams = ConnectedStations[i];
		System.out.print(i + " " + getTextualStatus(ams.getStatus()) +
			" MAC = " + HexTool.getHex(ams.getMACAddress()));

		if (ams.getAddressValid())
		    System.out.print(" IP = " + ams.getIPAddress()[0] + "."
			+ ams.getIPAddress()[1] + "." + ams.getIPAddress()[2]
			+ "." + ams.getIPAddress()[3]);

		if (ams.getStidValid())
		    System.out.print(" STID = " + ams.getStid());

		if (ams.getStatus() == ConnectedAMS.AMS_idle)
		    /* paging offset is valid for idle AMSes only */
		    System.out.print(" Paging offset = " +
				ams.getPagingOffset().longValue());

		System.out.println();
	    }
	}
    }

    /*
     * Returns a printable representation of an ConnectedAMS status
     */
    static String getTextualStatus(int status)
    {
	switch (status) {
	case ConnectedAMS.AMS_unused:
	    return "unused";
	case ConnectedAMS.AMS_idle:
	    return "idle";
	case ConnectedAMS.AMS_connected:
	    return "connected";
	case ConnectedAMS.AMS_dcr:
	    return "DCR";
	default:
	    return "????";
	}
    }

    /*
     * Prints a FeatureSupport value in text form
     */
    static void printFeatureSupport(FeatureSupport value)
    {
	if (value.equalTo(FeatureSupport.notSupported))
	    System.out.println("not supported");
	else if (value.equalTo(FeatureSupport.supported))
	    System.out.println("supported");
	else
	    System.out.println("invalid value (" + value + ")");
    }

    /*
     * Prints an IdleModeRetain value in text form
     */
    static void printIdleModeRetain(IdleModeRetain value)
    {
	System.out.println("\tIdle mode retain:");
	if (value.byteArrayValue().length == 0)
	    System.out.println("\t\t<None>");
	else {
	    if (value.getBit(IdleModeRetain.sbcMessages))
		System.out.println("\t\tSBC messages");
	    if (value.getBit(IdleModeRetain.pkmMessages))
		System.out.println("\t\tPKM messages");
	    if (value.getBit(IdleModeRetain.regMessages))
		System.out.println("\t\tREG messages");
	    if (value.getBit(IdleModeRetain.networkAddr))
		System.out.println("\t\tNetwork address");
	    if (value.getBit(IdleModeRetain.msState))
		System.out.println("\t\tMS state");
	}
    }

    /*
     * Returns a printable representation of a PgCycle value
     */
    static String textualPagingCycle(PgCycle pgc)
    {
	String TextualPagingCycles[] = {
	    "4 superframes",
	    "8 superframes",
	    "16 superframes",
	    "32 superframes",
	    "64 superframes",
	    "128 superframes",
	    "256 superframes",
	    "512 superframes"
	};

	if (pgc.intValue() < TextualPagingCycles.length)
	    return TextualPagingCycles[pgc.intValue()];
	else
	    return "reserved";
    }

    /*
     * Helper method. Converts byte[] array to the Hstring format, like '12345'H.
     */
    static String toHstring(byte[] value)
    {
	return "'" + HexTool.getHex(value) + "'H";
    }

    /*
     * Helper method. Determine if all elements of Enumeration are null.
     */
    static boolean isNullEnumElements(Enumeration enms)
    {
	while(enms.hasMoreElements()) {
	    if (enms.nextElement() != null)
		return false;
	}

	return true;
    }

    /*
     * Allocates an unused IP address from the pool of available IP addresses.
     */
    static byte[] allocateNewIP() throws Exception
    {
	byte[] place = new byte[4];
	byte last_digit = 1;
	boolean isAllocate = false;

	for (short bit = 0x80; bit != 0; bit >>= 1) {
	    if ((ip_addr_mask & bit) == 0 ) {
		ip_addr_mask |= bit;
		isAllocate = true;
		break;
	    }
	    last_digit++;
	}

	if (!isAllocate)
	    throw new Exception("Cannot allocate IP address");
	for (int i = 0; i < 3; i++)
	    place[i] = responseIP[i];
	place[3] = last_digit;
        return place;
    }

    /*
     * Allocates an unused STID.
     */
    static short allocateNewSTID() throws Exception
    {
	short result = 1;
	for (short bit = 0x80; bit != 0; bit >>= 1) {
	    if ((stid_mask & bit) == 0 ) {
		stid_mask |= bit;
		return result;
	    }
	    result++;
	}

	throw new Exception("Cannot allocate STID");
    }

    /*
     * Allocates an unused paging offset.
     */
    static PgOffset allocatePagingOffset() throws Exception
    {
	short result = 1;
	for (short bit = 0x80; bit != 0; bit >>= 1) {
	    if ((pgoffset_mask & bit) == 0 ) {
		pgoffset_mask |= bit;
		return new PgOffset(result);
	    }
	    result++;
	}

	throw new Exception("Cannot allocate paging offset");
    }

    /*
     * Frees a previously allocated IP address.
     */
    static short freeIPAddress(byte[] ipAddress)
    {
	return freeBit(ip_addr_mask, ipAddress[3]);
    }

    /*
     * Frees a previously allocated STID.
     */
    static short freeSTID(short stid)
    {
	return freeBit(stid_mask, stid);
    }

    /*
     * Frees a previously allocated resource.
     */
    static short freeBit(short mask, short bit)
    {
	mask &= ~(0x80 >> (bit - 1));
	return mask;
    }

    /* 
     * Auxiliary class describing an input MAC control message with 
     * supplementary info
     */
    static class InputDatum
    {
	String fileName;	/* file name */
	int    connection;	/* connection id */
	String comment;		/* comment (printed to make output more comprehensive) */

	public InputDatum (String fileName, int connection, String comment) {
	    this.fileName = fileName;
	    this.connection = connection;
	    this.comment = comment;
	}

	public String getFileName() {
	    return fileName;
	}

	public int getConnection() {
	    return connection;
	}

	public String getComment() {
	    return comment;
	}
    }

    /*
     * Auxiliary class describing AMS array elements
     */
    static class ConnectedAMS
    {
        public static final int AMS_unused = 0;	   /* Unused - data are ignored */
	public static final int AMS_idle = 1;	   /* Idle */
	public static final int AMS_connected = 2; /* Connected (active) */
	public static final int AMS_dcr = 3;	   /* DCR */

	int status = 0;		/* Slot status */
	boolean addressValid = false;	/* true if IP address is valid */
	boolean stidValid = false;	/* true if STID is valid */
	byte[] MACAddress = new byte[6];/* MAC address - reported by AMS */
	byte[] IPAddress = new byte[4];	/* IP address - allocated by ABS */
	short stid = 0;		/* STID - allocated by ABS */
	PgOffset pagingOffset;	/* Paging offset - valid only in idle mode */

	public int getStatus() {
	    return status;
	}

	public boolean getAddressValid() {
	    return addressValid;
	}

	public boolean getStidValid() {
	    return stidValid;
	}

	public byte[] getMACAddress() {
	    return MACAddress;
	}

	public byte[] getIPAddress() {
	    return IPAddress;
	}

	public short getStid() {
	    return stid;
	}

	public PgOffset getPagingOffset() {
	    return pagingOffset;
	}

	public void setStatus(int status) {
	    this.status = status;
	}

	public void setAddressValid(boolean addressValid) {
	    this.addressValid = addressValid;
	}

	public void setStidValid(boolean stidValid) {
	    this.stidValid = stidValid;
	}

	public void setMACAddress(byte[] MACAddress) {
	    this.MACAddress = MACAddress;
	}

	public void setIPAddress(byte[] IPAddress) {
	    this.IPAddress = IPAddress;
	}

	public void setStid(short stid) {
	    this.stid = stid;
	}

	public void setPagingOffset(PgOffset pagingOffset) {
	    this.pagingOffset = pagingOffset;
	}
    }
}
