#!/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	16.2 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -rf product
	rm -f converted.xml
	rm -f converted.per
	rm -f *.class
	rm -f *.log
	break;;
	
    "javac")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the product.asn abstract syntax and run the Bin2XML

	echo "----- Compiling the product specification -----"
	$ASN1 $COMMON_ASN1_OPTIONS -per -exer product -err compile.log
	if [ $? -eq 0 ]; then
	    cd product
	    echo "----- Compiling generated classes -----"
	    sh product.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g Bin2XML.java 2>&1 >> compile.log
	    if [ -f Bin2XML.class ]; then
		echo "----- Running the Bin2XML sample -----";
		$JAVA $COMMON_JAVA_OPTIONS Bin2XML product.per converted.xml;
	    fi
	    $JAVAC $JFLAGS -g XML2Bin.java 2>&1 >> compile.log
	    if [ -f XML2Bin.class ]; then
		echo "----- Running the XML2Bin sample -----";
		$JAVA $COMMON_JAVA_OPTIONS XML2Bin product.xml converted.per;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac



