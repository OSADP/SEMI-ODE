/*
 * Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)OERDemo.java	16.2 14/02/08  */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program OERDemo.java
    Demonstrates OSS ASN.1/Java Tools TOED API and OER encoding rules
    using BCAS (Baseball Card Abstract Syntax).
*/

/* To run the program:

asn1pjav baseball.asn
cd baseball
baseball.bat javac
cd ..
javac -g OERDemo.java
java OERDemo

 OR:

asn1pjav -test baseball.asn
cd baseball
baseball.bat javac
cd ..
java baseball.Test

If you experience difficulties running or compiling this program, carefully read
through the Installing section of the quickstart.html guide in the doc/guide
directory of your shipment. If that doesn't help contact support@oss.com. Be
sure to submit your license number, as well as a description of the problem.
*/

/* main() shows how to create values to be encoded,   */
/*    how to compare 2 values to be encoded,          */
/*    how to check constraints of a value,            */
/*    how to print the message that is ready to be    */
/*    encoded, how to encode the message, how to print*/
/*    the encoded data, how to decode the encoded data*/
/*    how to print the decoded data.                  */

/* Compiler-generated classes */
import baseball.*;
import baseball.bcas.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class OERDemo {

    /**
     * Constructor.
     */
    public OERDemo () {
    }

    public static void main(String args[]) {

	// Initialize the project
	try {
	    Baseball.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Create the value of BBCard using the constructor with arguments
	System.out.println("Creating 'myCard' value, using the constructor with arguments...");
	BBCard myCard = new BBCard (
	    new IA5String (
		"Casey"
	    ),
	    new IA5String (
		"Mudville Nine"
	    ),
	    32,
	    new IA5String (
		"left field"
	    ),
	    BBCard.Handedness.ambidextrous,
	    250.E-3);

	// Create another value of BBCard using the default constructor
	// and mutator methods
	System.out.println("Creating 'anotherCard' value, using the default constructor and mutator methods ...");
	BBCard anotherCard = new BBCard();
	// Set the value of the 'name' field
	anotherCard.setName(new IA5String("Casey"));
	// Set the value of the 'team' field
	anotherCard.setTeam(new IA5String("Mudville Nine"));
	// or set values of fields directly
	// Set the value of the 'age' field
	anotherCard.age = new INTEGER(32);
	// Set the value of the 'position' field
	anotherCard.position = new IA5String("left field");
	// Set the value of the 'handedness' field
	anotherCard.handedness = BBCard.Handedness.ambidextrous;
	// Set the value of the 'batting-average' field
	anotherCard.batting_average = new Real(250.E-3);

	// Compare myCard and anotherCard for identity
	System.out.println("Comparing 'myCard' and 'anotherCard' values ...");
	if (myCard.equalTo(anotherCard))
	    System.out.println("The values are identical.");
	else
	    System.out.println("The values are not identical.");

	// Check constraints for the 'myCard'
	// TOED runtime currently includes dummy constraint checker
	// that isValid() method always returns 'true'
	try {
	    System.out.println("Checking constraints for the 'myCard' ...");
	    if (myCard.isValid())
		System.out.println("Constraint checking suceeded.");
	} catch (ValidateFailedException e) {
	    System.out.println("Constraint checking failed: " + e);
	} catch (ValidateNotSupportedException e) {
	    System.out.println("Constraint checking failed: " + e);
	}

	// Encode the myCard value using OER.
	// Note, that support for OER is currently available only
	// in the TOED runtime
	try {
	    Coder coder = Baseball.getOERCoder();
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();

	    // Enable trace output from the encoder and decoder
	    // To have trace output printed you need to compile
	    // baseball.asn with -debug 2
	    coder.enableEncoderDebugging();
	    coder.enableDecoderDebugging();

	    // Print the input to the encoder
	    System.out.println("\nThe input to the encoder\n");
	    System.out.println(myCard);

	    // Encode a card
	    System.out.println("\nThe encoder's trace messages ...");
	    coder.encode(myCard, sink);

	    // Extract the encoding from the sink stream
	    byte[] encoding = sink.toByteArray();

	    // Print the encoding using the HexTool utility
	    System.out.println("Card encoded into " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);

	    try {
		ByteArrayInputStream source = new ByteArrayInputStream(encoding);

		// Decode the card whose encoding is in the 'encoding' byte array.
		System.out.println("\nThe decoder's trace messages ...\n");
		BBCard decodedCard = (BBCard)coder.decode(source, new BBCard());
		System.out.println("Card decoded.");
		// Print out the player's batting average
		double batting_average = decodedCard.getBatting_average();
		String name = decodedCard.name.stringValue();
		String team = decodedCard.team.stringValue();
		System.out.println(
		    name + " of the " + team + " has a batting average of " +
		    batting_average);
		System.out.println("Output from decoder ...");
		System.out.println(decodedCard);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoder exception: " + e);
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoder exception: " + e);
	    }
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}
	Baseball.deinitialize();
    }
}

