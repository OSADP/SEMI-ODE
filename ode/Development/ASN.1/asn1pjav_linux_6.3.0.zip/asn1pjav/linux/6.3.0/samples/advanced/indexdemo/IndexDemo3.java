/*
 * Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)IndexDemo3.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program IndexDemo3.java
    Demonstrates OSS ASN.1/Java Tools API for indexing information
    object sets. This demo implements lazy variant of automatic
    indexing.
*/

/* To run the program:

asn1pjav index1.asn -indexinfoobjectsets
cd index1
index1.bat javac
cd ..
javac -g IndexDemo3.java
java IndexDemo3

If you experience difficulties running or compiling this program, carefully
read through the Installing section of the quickstart.html guide in the
doc/guide directory of your shipment. If that doesn't help contact
support@oss.com. Be sure to submit your license number, as well as a
description of the problem.
*/

/* main() shows how to automatically index all        */
/*    information object sets on the first lookup(),  */
/*    rather than before initiation.                  */
/*    The automatic indexing is enabled via           */
/*    setIndexProcedure(), but the Index object used  */
/*    is an instance of special DummyIndex class      */
/*    which defers real indexing until first lookup() */
/*    or the index is invoked. On lookup() invocation */
/*    the dummy index replaces itself with real       */
/*    index which is derived from DefaultIndex.       */

/* Compiler-generated classes */
import index1.*;
import index1.ind1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;
import java.util.*;


public class IndexDemo3 {


    public static void main(String args[]) {

	// Initialize the project
	try {
	    Index1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Set IndexProcedure for all info object sets that 
      // use the PARAMETER_OSET class.
	// Two anonymous inner classes are used to extend
	// IndexProcedure class and DefaultIndex class.

	PARAMETER_OSET.setIndexProcedure(
	    new IndexProcedure() {
		public Index create(IndexedInfoObjectSet oset) {
		    // Do not index information object sets that are
		    // empty or contain just a few elements.
		    if (oset.getSize() > 2) {
			Index index = new DummyIndex((PARAMETER_OSET)oset);
			 if (((PARAMETER_OSET)oset).indexById(index))
			     return oset.getIndex();
		     }
		     return null;
		}
	    }
	);

	// Examine index of object sets found in index1.asn
	System.out.println("Examine info object sets before the first lookup()\n");
	examineIndex(Ind1.kNOWN_PARAMETERS, "KNOWN-PARAMETERS");
	examineIndex(Ind1.eXTRA_PARAMETERS, "EXTRA-PARAMETERS");
	examineIndex(Ind1.mORE_PARAMETERS, "MORE-PARAMETERS");

	// Initialize the project
	try {
	    Index1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

        // Use default coder to encode/decode 'proc' value from 'Ind1' module
	Coder coder = Index1.getDefaultCoder();
      AbstractData data = Ind1.proc;

        // Enable automatic encode/decode. Information object set lookups
        // are done if automatic decoding of open types is enabled 
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

        // Disable utility code to get clean performance figures
	coder.enableEncoderDebugging();
	coder.disableDecoderDebugging();
	coder.disableDecoderConstraints();
	coder.disableEncoderConstraints();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	try {
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();

	    // Print the input to the encoder
	    System.out.println("\nThe input to the encoder\n");
	    System.out.println(data);

	    // Encode sample value
	    System.out.println("\nThe encoder's trace messages ...");
	    coder.encode(data, sink);

	    // Extract the encoding from the sink stream
	    byte[] encoding = sink.toByteArray();

	    // Print the encoding using the HexTool utility
	    System.out.println("Value encoded into " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);

	    // Prepare to decode
	    Procedure newProc = new Procedure();
	    ByteArrayInputStream source = new ByteArrayInputStream(encoding);
	    AbstractData decoded = null;

	    System.out.println("\nDecoding...");
	    System.out.println("Decoder should perform lookup() in the KNOWN-PARAMETERS object set");
	    try {
		decoded = coder.decode(source, newProc);
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decode not supported.");
		return;
	    } catch (DecodeFailedException e) {
		System.out.println("Decode failed.");
		System.out.println("Error code: " + e.getReason());
		System.out.println(e);
		return;
	    }

            // Report elapsed time and print decoded value
	    System.out.println("\n\tDecoded PDU...\n");
	    System.out.println(decoded);

	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}

	System.out.println("Examine info object sets after decoding");
	System.out.println("Should report real indexing on KNOWN-PARAMETERS\n");

	examineIndex(Ind1.kNOWN_PARAMETERS, "KNOWN-PARAMETERS");
	examineIndex(Ind1.eXTRA_PARAMETERS, "EXTRA-PARAMETERS");
	examineIndex(Ind1.mORE_PARAMETERS, "MORE-PARAMETERS");


    }

    /**
	The method prints index statistics of an info object set
    */
    static void examineIndex(IndexedInfoObjectSet oset, String name)
    {
	Index i = oset.getIndex();

	if (i != null) {
	    if (i instanceof DummyIndex) {
		System.out.println("The information object set " + name + " is indexed via DummyIndex");
          } else {
		DefaultIndex index = (DefaultIndex)i;
		System.out.println("The information object set " + name + " is indexed via DefaultIndex");
		System.out.println("index.size() == " + index.size());
		System.out.println("index.numberOfBuckets() == " + index.numberOfBuckets());
		System.out.println("index.minBucket() == " + index.minBucket());
		System.out.println("index.maxBucket() == " + index.maxBucket());
	    }
	} else {
	    System.out.println("The information object set " + name + " is not indexed");
	}
    }

    /**
	DummyIndex class. On first lookup it replaces itself with
	real index which is derived from DefaultIndex implementation
    */
    static public class DummyIndex implements Index {
	protected PARAMETER_OSET oset = null;

	public DummyIndex(PARAMETER_OSET ios)
	{
	    oset = ios;
	}

	// This is the first lookup in the associated info object set.
	// Compute index and replace this dummy index with a real one.
	public Enumeration lookup(AbstractData key) {
	    Index index = new DefaultIndex() {
		public int mapKey(AbstractData key)
		{
		    return ((INTEGER)key).intValue();
		}
	    };
	    if (oset.indexById(index)) {
		// Indexing succeeded. Lookup the key using the new index.
		index = oset.getIndex();
		return index.lookup(key);
	    } else
		// Indexing failed. indexById() has cleared the index from the
		// information object set. Inform the caller (the lookup() of
		// the PARAMETER_OSET) that it should fall back to linear
		// search.
		return null;
	}

	public Index add(AbstractData key, InfoObject row)
	{
	    return this;
	}
	public Index remove(AbstractData key, InfoObject row)
	{
	    return this;
	}
	public Index reset()
	{
	    return this;
	}


    }

}
