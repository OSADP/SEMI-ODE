/*************************************************************/
/* Copyright (C) 2016 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)Tperf.java	17.2 16/01/24 */
/* Prepared by OSS Nokalva, Inc.  */

/* Application Program: Tperf.java

    The performance test sample illustrates a way to measure the runtime 
    performance of the coder.encode() and coder.decode() methods
    The program takes a binary or XML message, decodes it in a loop while 
    collecting execution time statistics, and then reencodes it back, again 
    measuring the execution time. 
*/
 
/* Compiler-generated classes */
import asn1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;

/* Java I/O classes */
import java.io.*;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.channels.Channels;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;


public class Tperf {
    
    public static void main(String[] args)
    {
        Tperf benchmark = new Tperf();
        int status = benchmark.setupBenchmark(args);
        if (status != 0)
            System.exit(status);

	// Initialize the project
	try {
	    Asn1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization error: " + e);
	    System.exit(1);
	}
	
	Coder coder = Asn1.getDefaultCoder();
        // Enable automatic encode/decode. Information object set lookups
        // are done if automatic decoding of open types is enabled 
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
        // Disable constraint checking for better performance.
        coder.disableEncoderConstraints();
        coder.disableDecoderConstraints();
	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}
        
        Result enc_result = null, dec_result = null;
        try {
            enc_result = benchmark.testEncoder(coder);
        } catch (Exception e) {
    	    System.out.println("Encoder exception: " + e);
            System.exit(2);
        }
        try {
            dec_result = benchmark.testDecoder(coder);
        } catch (Exception e) {
    	    System.out.println("Decoder exception: " + e);
        }
        // Print results
	System.out.printf("Average encode time is %s\n", enc_result);
        if (dec_result != null)
            System.out.printf("Average decode time is %s\n", dec_result);

	Asn1.deinitialize();
    }
    
    /**
     * Calculates the performance of the encoder.
     * 
     * @param coder the coder object to run the benchmark.
     * @return the result of the Benchmark.
     * @throws FileNotFoundException if the file with the sample message
     * cannot be opened.
     * @throws IOException if an error occurs while reading the sample message.
     * @throws DecodeFailedException if the decoding of the sample message
     * has failed.
     * @throws EncodeFailedException if the encoder has failed while running
     * the benchmark.
     */
    public Result testEncoder(Coder coder) 
        throws FileNotFoundException, DecodeNotSupportedException, 
               IOException, DecodeFailedException, 
               EncodeNotSupportedException, EncodeFailedException
    {
        // Decode the value from the "message.bin" file.
	System.out.println("Running the benchmark for the encoder...");

        AbstractData data;
        try (FileInputStream source = new FileInputStream(messageData)) {
            System.out.println("Loading test message...");
            data = coder.decode(source, emptyMessage);
            System.out.println("Message loaded.");
            System.out.println("Data " + data);
        }
        
        // For fastest performance preallocate output buffer for the
        // encoder.
        long size = (int)messageData.length();
        ByteArrayOutputStream baos = 
            new ByteArrayOutputStream(size > Short.MAX_VALUE ? 
                Short.MAX_VALUE : (int)size);
        Timer t = new Timer();
        try {
            // Do warmup
            if (warmupDuration > 0) {
                System.out.printf("Warming up the encoder for %d milliseconds...\n", 
                    warmupDuration);
                interrupted = false;
                scheduleInterrupt(t, warmupDuration);
                stopWatch.start();
                while (!interrupted) {
                    baos.reset();
                    coder.encode(data, baos);
                }
                StopWatch.ElapsedTime elapsed = stopWatch.stop();
                System.out.printf("Done in %d ms\n", elapsed.total / 1000000);
            }
            // Run profiling loop
            System.out.printf("Running the encoder for %d milliseconds...\n",
                benchmarkDuration);
            interrupted = false;
            scheduleInterrupt(t, benchmarkDuration);
            int count = 0;
            stopWatch.start();
            while (!interrupted) {
                baos.reset();
                coder.encode(data, baos);
                ++count;
            }
            StopWatch.ElapsedTime elapsed = stopWatch.stop();
            System.out.printf("Done in %d ms\n", elapsed.total / 1000000);
            return new Result(count, elapsed);
        } finally {
            t.cancel();
        }
    }

    /**
     * Calculates the performance of the encoder.
     * 
     * @param coder the coder object to run the benchmark.
     * @return the result of the Benchmark.
     * @throws FileNotFoundException if the file with the sample message
     * cannot be opened.
     * @throws IOException if an error occurs while reading the sample message.
     * @throws DecodeFailedException if the decoder has failed while running
     * the benchmark.
     */
    public Result testDecoder(Coder coder) throws FileNotFoundException, 
            IOException,
            DecodeNotSupportedException,
            DecodeFailedException
    {
        // Attempt to cache the encoding into the in-memory buffer
        byte[] encoding = getEncodedMessage(coder);
	System.out.println("Running the benchmark for the decoder...");

        Timer t = new Timer();
        try {
            // Do warmup
            if (warmupDuration > 0) {
                System.out.printf("Warming up the decoder for %d milliseconds...\n", 
                    warmupDuration);
                interrupted = false;
                scheduleInterrupt(t, warmupDuration);
                stopWatch.start();
                while (!interrupted) {
                    coder.decode(new ByteArrayInputStream(encoding), emptyMessage);
                }
                StopWatch.ElapsedTime elapsed = stopWatch.stop();
                System.out.printf("Done in %d ms\n", elapsed.total / 1000000);
            }
            // Run profiling loop
            System.out.printf("Running the decoder for %d milliseconds...\n",
                benchmarkDuration);
            interrupted = false;
            scheduleInterrupt(t, benchmarkDuration);
            int count = 0;
            stopWatch.start();
            while (!interrupted) {
                coder.decode(new ByteArrayInputStream(encoding), emptyMessage);
                ++count;
            }
            StopWatch.ElapsedTime elapsed = stopWatch.stop();
            System.out.printf("Done in %d ms\n", elapsed.total / 1000000);
            return new Result(count, elapsed);
        } finally {
            t.cancel();
        }
    }

    /**
     * The helper method to get a value of numeric property from the
     * property list.
     * 
     * @param settings - the property list.
     * @param name - the name that identifies the numeric property.
     * @return the value of the requested property or null if the property
     * with the specified name does not exist.
     * @throws NumberFormatException if the setting of the property is not a
     *	valid number.
     */
    protected static Integer getIntProperty(Properties settings, String name) 
	throws NumberFormatException
    {
	String decimal = settings.getProperty(name);
	int value = 0;
	if (decimal != null)
		value = Integer.parseInt(decimal);

        return value;
    }
    
    /**
     * Initializes various benchmark settings by parsing command-line arguments
     * and reading the 'benchmark.properties' file.
     * 
     * @param args the command-line arguments.
     * @return the non-zero status code if an error occurs.
     */
    private int setupBenchmark(String[] args)
    {
	int index = 0;
	String path = null;
        
	// Read configuration settings from the 'benchmark.properties' file
	Properties settings = new Properties();

	// An optional parameter includes the path to all the files that are used by
	// the program.
	if (args.length > 0) {
	    // Make sure first command-line argument isn't a benchmark setting
	    if (args[0].indexOf('=') < 0) {
		path = args[0];
		++index;
	    }
	}

	File file = new File(path, "benchmark.properties");
        if (!file.exists()) {
            System.out.printf("Failed to open the %s file. " +
                "Restart the sample program using as input parameter the name of the directory " +
                "where the '%s' file is located.\n", file.toString(), file.getName());
            return -1;
        }

	try (FileInputStream bpf = new FileInputStream(file)) {
	    settings.load(bpf);
	    bpf.close();
	} catch (IOException e) {
	    System.out.printf("Unable to read 'benchmark.properties' file: %s\n", e);
	    return -1;
	}

	// The remaining command-line arguments override settings in the benchmark.properties
	for (int i = index; i < args.length; i++) {
	    int eqpos = args[i].indexOf('=');
	    if (eqpos > 0 && eqpos < args[i].length() - 1) {
		settings.setProperty(args[i].substring(0, eqpos), args[i].substring(eqpos + 1));
	    } else {
		System.out.printf("Unexpected argument '%s'\n", args[i]);
		return -2;
	    }
	}	

	// Read the name of the file containing test messages
	String testData = settings.getProperty("benchmark.data");
	if (testData == null) {
	    System.out.println("The 'benchmark.data' property is missing.");
	    System.out.println(
		"This setting specifies the location of the file containing test messages.");
	    System.out.println("Loading test message from 'message.bin' file");
	    testData = "message.bin";
	}
        messageData = new File(testData);
        if (!messageData.isAbsolute())
            messageData = new File(file.getParent(), testData);
    
	// Determine the type of the test messages
	String messageType = settings.getProperty("benchmark.oss.message.type");
	if (messageType == null) {
	    System.out.println("The 'benchmark.oss.message.type' property is missing.");
	    return -3;
	}

	// Split qualified name to package name and class name
	int separator = messageType.lastIndexOf('.');
	if (separator == -1) {
	    System.out.println("The 'benchmark.oss.message.type' should specify qualified name.");
	    return -4;
	}
        try {
            this.emptyMessage = createEmptyMessage(messageType);
        } catch (InstantiationException e) {
            Throwable cause = e.getCause();
            if (cause != null)
                System.out.printf(
                    "Failed to instantiate the Java class, specified by the 'benchmark.oss.message.type' property: %s (caused by %s)\n",
                    e, cause);
            else
                System.out.printf(
                    "Failed to instantiate the Java class, specified by the 'benchmark.oss.message.type' property: %s\n",
                    e);
            return -5;
        }
        if (!emptyMessage.isPDU()) {
            System.out.printf("The specified Java class %s does not represent a PDU type. " +
                "The benchmark can be run for PDU messages only.\n", messageType);
            return -6;
        }

    	String name = null;
	// Read the time to warmup the JVM
	try {
	    name = "benchmark.warmup";
	    Integer warmup = getIntProperty(settings, name);
	    if (warmup != null)
		warmupDuration = warmup;
	} catch (NumberFormatException e) {
	    System.out.printf(
                "Invalid setting for '%s'. A number is expected. Default setting is used.\n", 
                name);
	}

	// Read the  current setting for the sampling interval
	try {
	    name = "benchmark.sampling";
	    Integer sampling = getIntProperty(settings, name);
            if (sampling != null) {
                if (sampling > 0)
                    benchmarkDuration = sampling;
                else
                    System.out.printf(
                        "Invalid setting for '%s'. A positive number is expected. Default setting is used.\n", 
                        name);
            }
	} catch (NumberFormatException e) {
	    System.out.printf(
                "Invalid setting for '%s'. A number is expected. Default setting is used.\n", 
                name);
	}
        
	// Read the  current setting for the precision.
        name = "benchmark.precision";
        String precision = settings.getProperty(name);
        StopWatch.Kind defaultStopWatchKind = StopWatch.Kind.standard;
        if (precision != null)
        {
            try {
                StopWatch.Kind stopWatchKind = 
                    StopWatch.Kind.valueOf(precision);
                stopWatch = StopWatch.Create(stopWatchKind);
            } catch (IllegalArgumentException e) {
                System.out.printf(
                    "Invalid setting for '%s'. Default setting '%s' is used.\n", 
                    name, defaultStopWatchKind);
            } catch (UnsupportedOperationException e) {
                System.out.printf(
                    "The '%s' setting for '%s' is not supported on your platform. Default setting '%s' is used.\n", 
                    precision, name, defaultStopWatchKind);
            }
        }
        if (stopWatch == null)
            stopWatch = StopWatch.Create(defaultStopWatchKind);

        return 0;
    }
    
    /**
     * Creates the empty instance of the message to be used for the
     * benchmark.
     * 
     * @param messageType the fully qualified name of the Java class that
     * represents the ASN.1 type of the message.
     * @throws InstantiationException if the creation of the empty
     * instance has failed.
     * @return the empty instance of the Java class identified by the
     * 'benchmark.oss.message.type' setting.
     */
    private AbstractData createEmptyMessage(String messageType) 
        throws InstantiationException
    {
        AbstractData emptyInstance = null;
        try {
            Class<?> clazz = Class.forName(messageType);
            if (Enumerated.class.isAssignableFrom(clazz)) {
                // Subclasses of Enumerated cannot be instantiated via the
                // newInstance().
                String valueClassName = messageType + "$" +
                    (clazz.getSimpleName().equals("Value") ? "Value_" : "Value");
                Class<?> valueClass = Class.forName(valueClassName);
                for (Field f:valueClass.getDeclaredFields()) {
                    int modifier = f.getModifiers();
                    if (Modifier.isStatic(modifier) &&
                        Modifier.isFinal(modifier)  && 
                        Modifier.isPublic(modifier) && 
                        "long".equals(f.getType().getName())) {
                        long value = f.getLong(null);
                        Method valueOf = 
                            clazz.getMethod("valueOf", long.class);
                        emptyInstance = 
                            (AbstractData)valueOf.invoke(null, value);
                    }
                }
            } else {
                emptyInstance = (AbstractData)clazz.newInstance();
            }
        } catch (ClassNotFoundException | SecurityException | 
                 IllegalArgumentException | IllegalAccessException | 
                 NoSuchMethodException | InvocationTargetException e) {
            InstantiationException e1 = new InstantiationException(
                "Failed to create the empty instance of the " + messageType);
            e1.initCause(e);
            throw e1;
        }
        if (emptyInstance == null)
            throw new InstantiationException(
                "Failed to create the empty instance of the " + messageType);
        else
            return emptyInstance;
    }

    /**
     * Attempts to load the encoding from the input file to the in-memory
     * buffer. When the length of the data file is bigger than the 
     * Short.MAX_VALUE bytes, the provided Coder object is used to determine
     * whether the file contains multiple concatenated messages and to extract 
     * the very first one.
     * @param coder the coder object. 
     * @return the encoding of the sample message.
     * @throws FileNotFoundException if the file with the sample message
     * cannot be opened.
     * @throws IOException if an error occurs while reading the sample
     * encoding into the in-memory buffer.
     * @throws DecodeFailedException if an error occurs while extracting the
     * encoded message.
     */
    private byte[] getEncodedMessage(Coder coder) throws FileNotFoundException,
        IOException,
        DecodeNotSupportedException,
        DecodeFailedException
    {
        final long limit = Short.MAX_VALUE;
        long size = messageData.length();
        if (size > limit) {
            // Check whether the input file contains multiple concatenated
            // messages and attempt to extract the first one
            try (RandomAccessFile raf = new RandomAccessFile(messageData, "r");
                 InputStream is = Channels.newInputStream(raf.getChannel())) {
                coder.decode(is, emptyMessage);
                size = raf.getFilePointer();
            }
            if (size > limit)
                throw new UnsupportedOperationException(
                    "This simple benchmark does not support sample messages that are bigger than " +
                    limit + " bytes. ");
        }
        byte[] encoding = new byte[(int)size];
        try (FileInputStream fis = new FileInputStream(messageData)) {
            fis.read(encoding);
        }
        
        return encoding;
    }

    /**
     * Setup the timer to interrupt the warmup/profiling loop.
     * 
     * @param t The timer object.
     * @param duration Time in milliseconds.
     */
    private void scheduleInterrupt(Timer t, long duration)
    {
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                interrupted = true;
            }}, duration);
    }
    
    /**
     * Specifies the name of the file where the encoded message is stored.
     */
    private File messageData;
    /**
     * Empty instance of the Java class that represents the
     * ASN.1 type of the message.
     */
    private AbstractData emptyMessage;
    /**
     * Selects the precision of measurements (System.nanoTime() or
     * ThreadMXBean).
     */
    private StopWatch stopWatch;
    /**
     * Specifies the duration of the warmup phase in milliseconds.
     */
    private int warmupDuration = 5000;
    /**
     * Specifies the duration of the benchmark phase in milliseconds.
     */
    private int benchmarkDuration = 5000;
    /**
     * Internal flag that is used to terminate the profiling loop.
     */
    private volatile boolean interrupted;
    /**
     * Represents the result of the benchmark.
     */
    public static class Result {
        /**
         * Constructs the Tperf.Result object.
         * 
         * @param iterations specifies the number of iterations performed.
         * @param elapsed specifies elapsed times.
         */
        public Result(long iterations, StopWatch.ElapsedTime elapsed)
        {
            this.iterations = iterations;
            this.elapsed = elapsed;
        }
        /**
         * The total number of iterations performed.
         */
        public long iterations;
        /**
         * Total elapsed, CPU and user times.
         */
        public StopWatch.ElapsedTime elapsed;
        /**
         * 
         * @return the average number of milliseconds per iteration.
         */
        public double millisecondsPerOperation()
        {
            return (double)elapsed.total * SCALE / (double)iterations;
        }
        /**
         * 
         * @return The average CPU time per iteration in milliseconds 
         * or Double.NaN if CPU time is not available.
         */
        public double cpuMillisecondsPerOperation()
        {
            return elapsed.cpu_time == -1 ? Double.NaN :
                (double)elapsed.cpu_time * SCALE / (double)iterations;
        }
        /**
         * 
         * @return The average user time per iteration in 
         * milliseconds or Double.NaN if user time is not available.
         */
        public double userMilliecondsPerOperation()
        {
            return elapsed.user_time == -1 ? Double.NaN :
                (double)elapsed.user_time * SCALE / (double)iterations;
        }
        @Override
        public String toString()
        {
            if (elapsed.cpu_time == -1) {
                return String.format("%f ms, %.02f operations per second",
                    millisecondsPerOperation(), 
                    1.0/millisecondsPerOperation()*1000.0);
            } else {
                return String.format("%f ms, %f ms (user), %.02f operations per second",
                    cpuMillisecondsPerOperation(), 
                    userMilliecondsPerOperation(),
                    1.0/cpuMillisecondsPerOperation()*1000.0);
            }
        }
        /**
         * The scale factor to convert nanoseconds to milliseconds.
         */
        private final double SCALE = 1E-09 / 1E-03;
    }
    /**
     * Simple class to measure time intervals.
     */
    public static abstract class StopWatch
    {
        /**
         * Supported stopwatch kinds.
         */
        public static enum Kind {
            /**
             * The stopwatch measures time intervals using the 
             * System.nanoTime().
             */
            standard, 
            /**
             * The stopwatch measures time intervals using the 
             * ThreadMXBean.
             */
            enhanced
        };
        /**
         * Represents the time span measured by the stopwatch.
         */
        public static class ElapsedTime
        {
            /**
             * Total elapsed time in nanoseconds.
             */
            public long total;
            /**
             * Elapsed CPU time in nanoseconds.
             */
            public long cpu_time;
            /**
             * Elapsed user time in nanoseconds.
             */
            public long user_time;
            /**
             * Constructs the ElapsedTime object when CPU and user times are not 
             * available.
             * 
             * @param total the total elapsed time.
             */
            public ElapsedTime(long total)
            {
                this.total = total;
                this.cpu_time = -1 ;
                this.user_time = -1;
            }
            /**
             * Constructs the ElapsedTime object.
             * 
             * @param total the total elapsed time.
             * @param cpu the CPU time.
             * @param user the user time.
             */
            public ElapsedTime(long total, long cpu, long user)
            {
                this.total = total;
                this.cpu_time = cpu;
                this.user_time = user;
            }
        }
        /**
         * Creates the Stopwatch of the requested kind.
         * 
         * @param kind the requested kind,
         * @return the Stopwatch object of the requested kind.
         */
        public static StopWatch Create(Kind kind)
        {
            switch (kind) {
                case enhanced:
                    return new MxbeanStopWatch();
                case standard:
                default:
                    return new SystemStopWatch();
            }
        }
        /**
         * Starts the stopwatch.
         */
        public abstract void start();
        /**
         * Stops the stopwatch and return times elapsed from the last 
         * invocation of the start() method.
         * 
         * @return the Result object containing elapsed times.
         */
        public abstract ElapsedTime stop();
        /**
         * The implementation of the StopWatch that is based on the 
         * System.nanoTime().
         * CPU and user times are not supported.
         */
        private static class SystemStopWatch extends StopWatch
        {
            private long clock;
            @Override
            public void start() 
            {
                clock = System.nanoTime();
            }

            @Override
            public ElapsedTime stop() 
            {
                return new ElapsedTime(System.nanoTime() - clock);
             }
            
        }
        /**
         * The implementation of the StopWatch that is based on the 
         * ThreadMXBean.
         * CPU and user times are available.
         */
        private static class MxbeanStopWatch extends StopWatch
        {
            private long clock;
            private long cpu;
            private long user;
            private ThreadMXBean mxBean = ManagementFactory.getThreadMXBean();

            /**
             * Constructs the MxbeanStopWatch object.
             * @throws UnsupportedOperationException if thread CPU time
             * management is not supported by the JVM or cannot be enabled.
             */
            public MxbeanStopWatch()
            {
                mxBean = ManagementFactory.getThreadMXBean();
                if (!mxBean.isThreadCpuTimeSupported())
                    throw new UnsupportedOperationException();
                else if (!mxBean.isThreadCpuTimeEnabled())
                    try {
                        mxBean.setThreadCpuTimeEnabled(true);
                    } catch (SecurityException e) {
                        throw new UnsupportedOperationException(e);
                    }
            }

            @Override
            public void start() 
            {
                clock = System.nanoTime();
                cpu = mxBean.getCurrentThreadCpuTime();
                user = mxBean.getCurrentThreadUserTime();
            }

            @Override
            public ElapsedTime stop() 
            {
                user = mxBean.getCurrentThreadUserTime() - user;
                cpu = mxBean.getCurrentThreadCpuTime() - cpu;
                clock = System.nanoTime() - clock;
 
                return new ElapsedTime(clock, cpu, user);
             }
            
        }
    }
}
