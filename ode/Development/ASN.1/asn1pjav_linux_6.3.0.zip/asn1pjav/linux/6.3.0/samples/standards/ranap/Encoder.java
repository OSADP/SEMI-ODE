/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Encoder.java	16.3 14/02/08
 */

/*
 * Demonstrates RANAP PDU encoding and further processing.
 */


import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import ranap.*;
import ranap.ranap_containers.*;
import ranap.ranap_ies.*;
import ranap.ranap_constants.*;
import ranap.ranap_commondatatypes.*;
import ranap.ranap_pdu_descriptions.*;
import ranap.ranap_pdu_contents.*;

public class Encoder {

    public static void main(String[] args) {

	// Initialize the project
	try {
	    Ranap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Ranap.getPERAlignedCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	/*
	 * Construct PDU for encoding.
	 */
	AbstractData msg = fill_RANAP_PDU();

	System.out.println("PDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);

    }

/*
 * Helper functions to set up the PDU for encoding.
 */
    static RANAP_PDU fill_RANAP_PDU()
    {
	RANAP_PDU pdu = new RANAP_PDU();

	InitiatingMessage imsg = new InitiatingMessage();
	pdu.setInitiatingMessage(imsg);

	/* Indicate RAB ASSIGNMENT REQUEST */
	imsg.setProcedureCode(
	    new ProcedureCode(RANAP_Constants.id_RAB_Assignment.intValue()));

	/* Indicate procedure criticality */
	imsg.setCriticality(Criticality.reject);

	/* Create an unencoded value for OpenType field initiatingMessage.value */
	imsg.setValue(
	    new OpenType(
		fill_RAB_AssignmentRequest_PDU()
	    )
	);
	return pdu;
    }

    static RAB_AssignmentRequest fill_RAB_AssignmentRequest_PDU()
    {
	RAB_AssignmentRequest   pdu = new RAB_AssignmentRequest();
	ProtocolIE_Container    ies = new ProtocolIE_Container();
	pdu.setProtocolIEs(ies);

	/* Create unencoded value for the PDU, it consists
	 * of 2 Information Elements (IEs) */

	/* First IE is a RAB SetupOrModifyList */
	ProtocolIE_Field ie = new ProtocolIE_Field();
	ies.add(ie);
	ie.setId(
	    new ProtocolIE_ID(RANAP_Constants.id_RAB_SetupOrModifyList.intValue())
	);
	ie.setCriticality(Criticality.ignore);
       /* value is an OpenType field,
	* set unencoded value of the enclosed PDU */
	ie.setValue(
	    new OpenType(
		fill_RAB_SetupOrModifyList_PDU()
	    )
	);

	/* Create the second IE - RAB ReleaseList */
	ie = new ProtocolIE_Field();
	ies.add(ie);
	ie.setId(
	    new ProtocolIE_ID(RANAP_Constants.id_RAB_ReleaseList.intValue())
	);
	ie.setCriticality(Criticality.ignore);
       /* value is an OpenType field,
	* set unencoded value of the enclosed PDU */
	ie.setValue(
	    new OpenType(
		fill_RAB_ReleaseList_PDU()
	    )
	);
	return pdu;
    }

    static RAB_SetupOrModifyList fill_RAB_SetupOrModifyList_PDU()
    {
	RAB_SetupOrModifyList list = new RAB_SetupOrModifyList();
	ProtocolIE_ContainerPair element = new ProtocolIE_ContainerPair();
	list.add(element);
	ProtocolIE_FieldPair elt = new ProtocolIE_FieldPair();
	element.add(elt);
	elt.setId(
	    new ProtocolIE_ID(RANAP_Constants.id_RAB_SetupOrModifyItem.intValue())
	);
	elt.setFirstCriticality(Criticality.reject);
	elt.setFirstValue(
	    new OpenType(
		fill_RAB_SetupOrModifyItemFirst_PDU()
	    )
	);
	elt.setSecondCriticality(Criticality.ignore);
	elt.setSecondValue(
	    new OpenType(
		fill_RAB_SetupOrModifyItemSecond_PDU()
	    )
	);
	return list;
    }

    static RAB_ReleaseList fill_RAB_ReleaseList_PDU()
    {
	RAB_ReleaseList list = new RAB_ReleaseList();
	ProtocolIE_Container element = new ProtocolIE_Container();
	list.add(element);
	ProtocolIE_Field elt = new ProtocolIE_Field();
	element.add(elt);
	elt.setId(
	    new ProtocolIE_ID(RANAP_Constants.id_RAB_ReleaseItem.intValue())
	);
	elt.setCriticality(Criticality.ignore);
	elt.setValue(
	    new OpenType(
		fill_RAB_ReleaseItem_PDU()
	    )
	);
       return list;
   }

   static RAB_SetupOrModifyItemFirst fill_RAB_SetupOrModifyItemFirst_PDU()
   {
       RAB_SetupOrModifyItemFirst pdu = new RAB_SetupOrModifyItemFirst();

       pdu.setRAB_ID(new RAB_ID(new byte[] {(byte)222}));
       RAB_Parameters parms = new RAB_Parameters();
       pdu.setRAB_Parameters(parms);

	parms.setTrafficClass(TrafficClass.conversational);
	parms.setRAB_AsymmetryIndicator(RAB_AsymmetryIndicator.symmetric_bidirectional);
	parms.setMaxBitrate(
	     new RAB_Parameter_MaxBitrateList(
		 new MaxBitrate[] { new MaxBitrate(2) }
	     )
	);
	parms.setGuaranteedBitRate(
	     new RAB_Parameter_GuaranteedBitrateList(
		 new GuaranteedBitrate[] { new GuaranteedBitrate(3) }
	     )
	);
	parms.setDeliveryOrder(DeliveryOrder.delivery_order_requested);
	parms.setMaxSDU_Size(new MaxSDU_Size(4));
	SDU_Parameters sparms = new SDU_Parameters();
	parms.setSDU_Parameters(sparms);
	SDU_Parameters.Sequence_ sparm = new SDU_Parameters.Sequence_();
	sparms.add(sparm);
	sparm.setSDU_ErrorRatio(
	    new SDU_ErrorRatio(5, 6)
	);
	sparm.setResidualBitErrorRatio(
	    new ResidualBitErrorRatio(7, 8)
	);
	sparm.setDeliveryOfErroneousSDU(DeliveryOfErroneousSDU.yes);
	SDU_FormatInformationParameters sfparms =
	    new SDU_FormatInformationParameters();
	SDU_FormatInformationParameters.Sequence_ sfparm =
	    new  SDU_FormatInformationParameters.Sequence_();
	sfparms.add(sfparm);
	sfparm.setSubflowSDU_Size(new SubflowSDU_Size(9));
	sfparm.setRAB_SubflowCombinationBitRate(new RAB_SubflowCombinationBitRate(11));
	parms.setTransferDelay(new TransferDelay(11));
	parms.setTrafficHandlingPriority(TrafficHandlingPriority.lowest);

	AllocationOrRetentionPriority pty = new AllocationOrRetentionPriority();
	parms.setAllocationOrRetentionPriority(pty);
	pty.setPriorityLevel(PriorityLevel.no_priority);
	pty.setPre_emptionCapability(Pre_emptionCapability.shall_not_trigger_pre_emption);
	pty.setPre_emptionVulnerability(Pre_emptionVulnerability.not_pre_emptable);
	pty.setQueuingAllowed(QueuingAllowed.queueing_not_allowed);

	parms.setSourceStatisticsDescriptor(SourceStatisticsDescriptor.speech);

	UserPlaneInformation info = new UserPlaneInformation();
	info.setUserPlaneMode(UserPlaneMode.support_mode_for_predefined_SDU_sizes);
	info.setUP_ModeVersions(
	    new UP_ModeVersions(
		new byte[] { (byte)0x22, (byte)0x22 }
	    )
	);
	TransportLayerInformation tinfo = new TransportLayerInformation();
	pdu.setTransportLayerInformation(tinfo);
	tinfo.setTransportLayerAddress(
	    new TransportLayerAddress(
		new byte[] { (byte)0x33 }
	    )
	);

	tinfo.setIuTransportAssociation(
	    IuTransportAssociation.createIuTransportAssociationWithBindingID(
		new BindingID(
		   new byte[] { (byte)0x44, (byte)0x44, (byte)0x44,
				(byte)0x44
			      }
		)
	    )
	);
	return pdu;
    }

    static RAB_SetupOrModifyItemSecond fill_RAB_SetupOrModifyItemSecond_PDU()
    {
	RAB_SetupOrModifyItemSecond pdu = new RAB_SetupOrModifyItemSecond();

	pdu.setDataVolumeReportingIndication(DataVolumeReportingIndication.do_report);
	pdu.setDl_GTP_PDU_SequenceNumber(new DL_GTP_PDU_SequenceNumber(5));
	pdu.setUl_GTP_PDU_SequenceNumber(new UL_GTP_PDU_SequenceNumber(6));
	pdu.setDl_N_PDU_SequenceNumber(new DL_N_PDU_SequenceNumber(7));
	pdu.setUl_N_PDU_SequenceNumber(new UL_N_PDU_SequenceNumber(8));

	return pdu;
    }


    static RAB_ReleaseItem fill_RAB_ReleaseItem_PDU()
    {
	RAB_ReleaseItem pdu =
	    new RAB_ReleaseItem (
		 new RAB_ID (
		     new byte[]
		     {
			 (byte)0x5B
		     },
		     8
		 ),
		 Cause.createCauseWithRadioNetwork (
		     (CauseRadioNetwork)CauseRadioNetwork.trelocoverall_expiry.clone()
		 )
	    );
	return pdu;
    }

}
