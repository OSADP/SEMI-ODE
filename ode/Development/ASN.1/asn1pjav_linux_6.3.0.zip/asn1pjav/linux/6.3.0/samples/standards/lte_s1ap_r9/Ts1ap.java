/*****************************************************************************/
/*  Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.               */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE:  @(#)Ts1ap.java	17.1  15/11/13
 */

/*
 * Demonstrates work with data for S1 protocol of LTE
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.*;

import s1ap.*;
import s1ap.oss_s1ap_s1ap_commondatatypes.*;
import s1ap.oss_s1ap_s1ap_constants.*;
import s1ap.oss_s1ap_s1ap_containers.*;
import s1ap.oss_s1ap_s1ap_ies.*;
import s1ap.oss_s1ap_s1ap_pdu_contents.*;
import s1ap.oss_s1ap_s1ap_pdu_descriptions.*;

public class Ts1ap {
    static Coder coder;
    static String border = "-------------------------------------------------------";
    /* Names of Criticality values */
    static String[] Criticalities = { "reject", "ignore", "notify" };

    /* Names of HandoverType values */
    static String HandoverType[] = {
	"intralte", "ltetoutran", "ltetogeran", "utrantolte", "gerantolte"
    };

    /*
     * Deserializes and prints input messages, creates and prints successful
     * outcome messages
     */
    public static void main(String[] args) throws java.io.FileNotFoundException, Exception
    {
	// Initialize the project
	try {
	    S1ap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = S1ap.getPERAlignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;

	try {
	    testS1AP(path, "S1AP-PDU_HandoverRequest_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	    System.exit(1);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * testS1AP() is used to test S1AP message, the input serialized pdu is
     * deserialized and printed, then an outcome message is created, printed
     * and encoded.
     */
    static void testS1AP(String path, String filename) throws IOException, Exception
    {
	OSS_S1AP_PDU request;
	File file = new File(path, filename);
	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	/* Read serialized message from file */
	System.out.println("Read encoding from file: " + filename + "\n");

	System.out.println("Deserialize request");
	System.out.println(border);
	/* Deserialize input message */
        request = (OSS_S1AP_PDU)coder.decode(source, new OSS_S1AP_PDU());
	source.close();
	System.out.println("\nDeserialized request");
	System.out.println(border);
	System.out.println(request);
	/* Parse and print input message */
	printHandoverRequiredMsg(request);
	/* Create successful outcome message */
	OSS_S1AP_PDU response = createSuccessResponse(request);

	/* Print outcome message */
	System.out.println(response);
	System.out.println("Serialize response");
	System.out.println(border);
	/* Serialize outcome message */
	ByteArrayOutputStream out = new ByteArrayOutputStream();
	try {
	    coder.encode(response, out);
	} catch (Exception e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(1);
	}

	/* Print serialized outcome message */
	System.out.println("\nSerialized response "
				+ "(" + out.size() + " bytes):");
	System.out.println(HexTool.getHex(out.toByteArray()));
    }

    /*
     * Prints S1AP pdu which contains HandoverRequired message. The
     * function is not intended to handle other types of messages.
     */
    static void printHandoverRequiredMsg(OSS_S1AP_PDU pdu) throws Exception
    {
	OSS_S1AP_HandoverRequired hr_value;
	System.out.println("\nGet message information");
	System.out.println(border);
	/* Get identifier of message stored in PDU */
	if (!pdu.hasInitiatingMessage())
	    throw new Exception("Unexpected type of message");

	OpenType msg_value = ((OSS_S1AP_InitiatingMessage)
	    pdu.getChosenValue()).getValue();

	if (msg_value.getDecodedValue() != null) {
	    if (msg_value.getDecodedValue() instanceof OSS_S1AP_HandoverRequired)
		hr_value = (OSS_S1AP_HandoverRequired)msg_value.getDecodedValue();
	    else
		throw new Exception("Incorrect message");
	} else 
	    throw new Exception("Incorrect message");

	System.out.println("Message type is HandoverRequired\n");

	if (hr_value.getProtocolIEs() == null)
	    throw new Exception("Incorrect message");

	printProtocolIEs(hr_value.getProtocolIEs(), 0);
    }

    /*
     * Creates S1AP successful outcome message for given
     * HandoverRequired request.
     */
    static OSS_S1AP_PDU createSuccessResponse(OSS_S1AP_PDU request) throws Exception
    {
	if (!request.hasInitiatingMessage())
	    throw new Exception("Unexpected type of message");

	OpenType msg_value = ((OSS_S1AP_InitiatingMessage)
	    request.getChosenValue()).getValue();
	OSS_S1AP_HandoverRequired hr_value =
	    (OSS_S1AP_HandoverRequired)msg_value.getDecodedValue();

	if (hr_value == null || msg_value.getEncodedValue() != null)
	    throw new Exception("Unexpected HandoverRequired request data");

	if (hr_value.getProtocolIEs() == null || hr_value.getProtocolIEs().getSize() == 0)
	    throw new Exception("No IEs in HandoverRequired request");

	OSS_S1AP_ProtocolIE_Container reqies = hr_value.getProtocolIEs();

	System.out.println("Create response");
	System.out.println(border);
	/*
         * Create successful outcome message from initiating message. Copy
         * some IEs from input to output.
         */
        OSS_S1AP_ProtocolIE_Container respies =
    	     new OSS_S1AP_ProtocolIE_Container();
    	OSS_S1AP_ProtocolIE_Field element;

        for (int i = 0; i < reqies.getSize(); i++) {
    	    if (reqies.get(i).getId().equalTo(
    		    OSS_S1AP_S1AP_Constants.OSS_S1AP_id_eNB_UE_S1AP_ID)
    		    || reqies.get(i).getId().equalTo(
    		    OSS_S1AP_S1AP_Constants.OSS_S1AP_id_MME_UE_S1AP_ID)
    		    || reqies.get(i).getId().equalTo(
    		    OSS_S1AP_S1AP_Constants.OSS_S1AP_id_HandoverType)) {
		element = (OSS_S1AP_ProtocolIE_Field)reqies.get(i).clone();
		respies.add(element);
	    }
	}

	/* Add E-RABList IE to outcome message */
	OSS_S1AP_ProtocolIE_ID id = OSS_S1AP_S1AP_Constants.OSS_S1AP_id_E_RABtoReleaseListHOCmd;
	OSS_S1AP_Criticality criticality = OSS_S1AP_Criticality.ignore;

	OSS_S1AP_E_RAB_ID e_RAB_ID = new OSS_S1AP_E_RAB_ID(13);
	OSS_S1AP_Cause cause =
	    OSS_S1AP_Cause.createOSS_S1AP_CauseWithRadioNetwork(
		OSS_S1AP_CauseRadioNetwork.x2_handover_triggered);
	OSS_S1AP_E_RABItem eRabItem = new OSS_S1AP_E_RABItem(e_RAB_ID, cause);
	OSS_S1AP_ProtocolIE_Field field =
	    new OSS_S1AP_ProtocolIE_Field(
		    OSS_S1AP_S1AP_Constants.OSS_S1AP_id_E_RABItem,
		    OSS_S1AP_Criticality.ignore,
		    new OpenType(eRabItem));
	OSS_S1AP_E_RABList eRabList = new OSS_S1AP_E_RABList();
	eRabList.add(field);

	element = new OSS_S1AP_ProtocolIE_Field(
		    id, criticality, new OpenType(eRabList));
	respies.add(element);

	/* Add Target-ToSource-TransparentContainer IE to outcome message */
	id = OSS_S1AP_S1AP_Constants.OSS_S1AP_id_Target_ToSource_TransparentContainer;
	criticality = OSS_S1AP_Criticality.reject;
	OSS_S1AP_Target_ToSource_TransparentContainer trValue =
	    new OSS_S1AP_Target_ToSource_TransparentContainer(
		    new byte[] {(byte)0x55});

	element = new OSS_S1AP_ProtocolIE_Field(
		    id, criticality, new OpenType(trValue));
	respies.add(element);

	OSS_S1AP_ProcedureCode procedureCode = ((OSS_S1AP_InitiatingMessage)
				request.getChosenValue()).getProcedureCode();
	criticality = OSS_S1AP_Criticality.reject;
        OSS_S1AP_HandoverCommand handoverCommand =
	    new OSS_S1AP_HandoverCommand(respies);
	OSS_S1AP_SuccessfulOutcome successfulOutcome =
	    new OSS_S1AP_SuccessfulOutcome(
		procedureCode, criticality, new OpenType(handoverCommand));
	OSS_S1AP_PDU response =
	    OSS_S1AP_PDU.createOSS_S1AP_PDUWithSuccessfulOutcome(successfulOutcome);
	return response;
    }

    /*
     * Prints ProtocolIE_Container data.
     */
    static void printProtocolIEs(OSS_S1AP_ProtocolIE_Container ies, int indent)
    {
	System.out.println("protocolIEs includes the following IEs:\n");
	indent++;
	/* Print each IE */
        for (int i = 0; i < ies.getSize(); i++) {
	    OSS_S1AP_ProtocolIE_Field field =
		(OSS_S1AP_ProtocolIE_Field )ies.get(i).clone();
	    OpenType value = field.getValue();
	    long fieldId = field.getId().longValue();
	    printIndent(indent++);
	    System.out.println("#" + (i + 1) + ": id = " + fieldId +
				", criticality = " + Criticalities[(int)field.getCriticality().longValue()]);

	    /* Print MME-UE-S1AP-ID IE */
	    printIndent(indent);
    	    if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_MME_UE_S1AP_ID)) {
		System.out.println("value MME-UE-S1AP-ID: " +
		    ((OSS_S1AP_MME_UE_S1AP_ID)value.getDecodedValue()).longValue());
	    /* ENB-UE-S1AP-ID IE */
    	    } else if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_eNB_UE_S1AP_ID)) {
		System.out.println("value ENB-UE-S1AP-ID: " +
		    ((OSS_S1AP_ENB_UE_S1AP_ID)value.getDecodedValue()).longValue());
	    /* HandoverType IE */
    	    } else if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_HandoverType)) {
		System.out.println("value HandoverType: " +
		    HandoverType[(int)((OSS_S1AP_HandoverType)value.getDecodedValue()).longValue()]);
	    /* Cause IE */
    	    } else if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_Cause)) {
		OSS_S1AP_Cause pcause = (OSS_S1AP_Cause)value.getDecodedValue();

		/*
		 * Named values can be printed below instead of numbers for all
		 * Cause components
		 */
		System.out.print("value Cause: ");
		/* radioNetwork */
		if (pcause.hasRadioNetwork())
		    System.out.println("radioNetwork: " +
			((OSS_S1AP_CauseRadioNetwork)pcause.getChosenValue()).longValue());
		/* transport */
		else if (pcause.hasTransport())
		    System.out.println("transport: " +
			((OSS_S1AP_CauseTransport)pcause.getChosenValue()).longValue());
		/* nas */
		else if (pcause.hasNas())
		    System.out.println("nas: " +
			((OSS_S1AP_CauseNas)pcause.getChosenValue()).longValue());
		/* protocol */
		else if (pcause.hasProtocol())
		    System.out.println("Protocol: " +
			((OSS_S1AP_CauseProtocol)pcause.getChosenValue()).longValue());
		/* misc */
		else if (pcause.hasMisc())
		    System.out.println("misc: " +
			((OSS_S1AP_CauseMisc)pcause.getChosenValue()).longValue());
	    /* TargetID IE */
    	    } else if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_TargetID)) {
		OSS_S1AP_TargetID ptarget = (OSS_S1AP_TargetID)value.getDecodedValue();
		System.out.print("value TargetID : ");
		indent++;
		/* targeteNB-ID */
		if (ptarget.hasTargeteNB_ID()) {
		    OSS_S1AP_TargeteNB_ID targeteNB_ID =
			(OSS_S1AP_TargeteNB_ID)ptarget.getChosenValue();
		    System.out.println("targeteNB-ID :");
		    /* global-ENB-ID */
		    printDataWithIndent(indent, "targete-END-ID: ");
		    indent++;
		    /* pLMNidentity */
		    printDataWithIndent(indent, "pLMNidentity: " +
			toHstring(targeteNB_ID.getGlobal_ENB_ID().getPLMNidentity().byteArrayValue()));
		    /* eNB-ID */
		    printIndent(indent);
		    System.out.print("eNB-ID: ");

		    if (targeteNB_ID.getGlobal_ENB_ID().getENB_ID().hasMacroENB_ID()) {
			System.out.println("macroENB-ID: " + toHstring(((BitString)
			    targeteNB_ID.getGlobal_ENB_ID().getENB_ID().getChosenValue()).byteArrayValue()));
		    /* homeENB-ID */
		    } else if (targeteNB_ID.getGlobal_ENB_ID().getENB_ID().hasHomeENB_ID()) {
			System.out.println("homeENB-ID: " + toHstring(((BitString)
			    targeteNB_ID.getGlobal_ENB_ID().getENB_ID().getChosenValue()).byteArrayValue()));
		    }

		    if (targeteNB_ID.getGlobal_ENB_ID().hasIE_Extensions())
			printProtocolExtensions(
			    targeteNB_ID.getGlobal_ENB_ID().getIE_Extensions(), indent);

		    indent--;
		    /* selected-TAI */
		    printDataWithIndent(indent, "selected-TAI: ");
		    indent++;
		    /* pLMNidentity */
		    printDataWithIndent(indent, "pLMNidentity: " +
			toHstring(targeteNB_ID.getSelected_TAI().getPLMNidentity().byteArrayValue()));

		    /* tAC */
		    printDataWithIndent(indent, "tAC: " +
			toHstring(targeteNB_ID.getSelected_TAI().getTAC().byteArrayValue()));

		    if (targeteNB_ID.getSelected_TAI().hasIE_Extensions())
			printProtocolExtensions(
			    targeteNB_ID.getSelected_TAI().getIE_Extensions(), indent);

		    indent--;

		    /* iE_Extensions is optional */
		    if (targeteNB_ID.hasIE_Extensions())
			printProtocolExtensions(
			    targeteNB_ID.getIE_Extensions(), indent);

		/* targetRNC-ID */
		} else if (ptarget.hasTargetRNC_ID()) {
		    OSS_S1AP_TargetRNC_ID targetRNC_ID =
		        (OSS_S1AP_TargetRNC_ID)ptarget.getChosenValue();
		    System.out.println("targetRNC_ID :");
		    /* lAI */
		    printDataWithIndent(indent, "lAI: ");
		    indent++;
		    /* pLMNidentity */
		    printDataWithIndent(indent, "pLMNidentity: " +
			toHstring(targetRNC_ID.getLAI().getPLMNidentity().byteArrayValue()));
		    /* lAC */
		    printDataWithIndent(indent, "lAC: " +
			toHstring(targetRNC_ID.getLAI().getLAC().byteArrayValue()));
		    /* iE_Extensions is optional */
		    if (targetRNC_ID.getLAI().hasIE_Extensions())
			printProtocolExtensions(
			    targetRNC_ID.getLAI().getIE_Extensions(), indent);

		    indent--;
		    /* rAC is optional */
		    if (targetRNC_ID.hasRAC()) {
			printDataWithIndent(indent, "rAC: " +
			    toHstring(targetRNC_ID.getRAC().byteArrayValue()));
		    }

		    /* rNC-ID */
		    printDataWithIndent(indent, "rNC-ID: " +
			    targetRNC_ID.getRNC_ID().longValue());

		    /* extendedRNC-ID is optional */
		    if (targetRNC_ID.hasExtendedRNC_ID()) {
			printDataWithIndent(indent, "extendedRNC-ID: " +
				targetRNC_ID.getExtendedRNC_ID().longValue());
		    }
		/* cGI */
		} else if (ptarget.hasCGI()) {
		    OSS_S1AP_CGI cGI =
		        (OSS_S1AP_CGI)ptarget.getChosenValue();
		    System.out.println("cGI :");
		    /* pLMNidentity */
		    printDataWithIndent(indent, "pLMNidentity: " +
			toHstring(cGI.getPLMNidentity().byteArrayValue()));
		    /* lAC */
		    printDataWithIndent(indent, "lAC: " +
			toHstring(cGI.getLAC().byteArrayValue()));
		    /* cI */
		    printDataWithIndent(indent, "cI : " +
			toHstring(cGI.getCI().byteArrayValue()));

		    /* rAC is optional */
		    if (cGI.hasRAC()) {
			printDataWithIndent(indent, "rAC: " +
			    toHstring(cGI.getRAC().byteArrayValue()));
		    }
		}
	    indent--;

	    /* Direct-Forwarding-Path-Availability IE */
    	    } else if (field.getId().equalTo(OSS_S1AP_S1AP_Constants.OSS_S1AP_id_Direct_Forwarding_Path_Availability)) {
		System.out.println("value Direct-Forwarding-Path-Availability: " +
		    ((OSS_S1AP_Direct_Forwarding_Path_Availability)value.getDecodedValue()).longValue());
	    /* other IEs are printed as ASN.1 value notation */
	    } else if (value.getDecodedValue() != null) {
		System.out.print(value.getDecodedValue());
	    } else
		System.out.println("PDU is not decoded");
	    System.out.println();
	    indent--;
	}
    }

    /*
     * Prints ProtocolExtensionContainer data.
     */
    static void printProtocolExtensions(
	    OSS_S1AP_ProtocolExtensionContainer ie_ext, int indent)
    {
	printDataWithIndent(indent++, "iE-Extensions includes the following IEs:");
        for (int i = 0; i < ie_ext.getSize(); i++) {
    	    OSS_S1AP_ProtocolExtensionField field = ie_ext.get(i);
	    OpenType value = field.getExtensionValue();
	    long fieldId = field.getId().longValue();
	    printIndent(indent++);
	    System.out.println("#" + (i + 1) + ": id = " + fieldId +
				", criticality = " +
				Criticalities[(int)field.getCriticality().longValue()]);
	    if (value.getDecodedValue() != null)
		System.out.println(value.getDecodedValue());
	    else
		System.out.println("PDU is not decoded");
	}
    }

    /*
     * Helper method. Converts byte[] array to the Hstring format, like '12345'H.
     */
    static String toHstring(byte[] value)
    {
	return "'" + HexTool.getHex(value) + "'H";
    }

    /*
     * Performs indentation.
     * @param indentlevel indentation level.
     */
    public static void printIndent(int indentlevel)
    {
	for (int i = 0; i < indentlevel; i++)
	    System.out.print(' ');
    }

    /*
     * Print indentation with following data.
     */
    public static void printDataWithIndent(int indentlevel, Object data)
    {
	printIndent(indentlevel);
	System.out.println(data);
    }
}

