/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.	          */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Tm3ap.java	17.2  15/11/13
 */

/*
 * Demonstrates work with data for M3AP protocol of LTE.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.*;
import m3ap.*;
import m3ap.oss_m3ap_m3ap_commondatatypes.*;
import m3ap.oss_m3ap_m3ap_constants.*;
import m3ap.oss_m3ap_m3ap_containers.*;
import m3ap.oss_m3ap_m3ap_ies.*;
import m3ap.oss_m3ap_m3ap_pdu_contents.*;
import m3ap.oss_m3ap_m3ap_pdu_descriptions.*;

public class Tm3ap {

    static Coder coder;
    static String border = "-------------------------------------------------------";

    /*
     * Decodes and prints the input messages; creates, encodes and prints 
     * the output (response) messages.
     */
    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    M3ap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = M3ap.getPERAlignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;

	try {
	    test_M3AP_Message(path, "M3AP-PDU_MBMSSessionStartRequest_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	}

	try {
	    test_M3AP_Message(path, "M3AP-PDU_Reset_bin.per");
	} catch (Exception e) {
	    System.out.println(e);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * Prints ProtocolIE_Container data.
     * This method handles only some IEs that can be present in a MBMS Session
     * Start Request message.
     */
    static void printSessionStartRequestProtocolIEs(OSS_M3AP_ProtocolIE_Container protocolIEs) 
    {
        System.out.printf("%s includes the following protocol IEs:\n", 
            "Session Start Request message");
        for (int i=0; i<protocolIEs.getSize(); i++) {
            OSS_M3AP_ProtocolIE_Field field = protocolIEs.get(i);
            OSS_M3AP_ProtocolIE_ID field_id = field.getId();
            System.out.printf("IE#%d: id = %2d, criticality = %s\n", i+1, 
                field_id.intValue(), field.getCriticality().name());
            AbstractData value = field.getValue().getDecodedValue();
            if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MME_MBMS_M3AP_ID)) {
                // Print MME-MBMS-M3AP-ID IE
                int ie_value = ((OSS_M3AP_MME_MBMS_M3AP_ID)value).intValue();
                System.out.printf("value %s: %d\n",  "MCE-MBMS-M3AP-ID", ie_value);
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_TMGI)) {
                // Print TMGI IE
                OSS_M3AP_TMGI ie_value = (OSS_M3AP_TMGI)value;
                System.out.printf("value %s: \n",  "TMGI fields");
                System.out.printf("%s: %s\n",  "PLMN-Identity", 
                    toHstring(ie_value.getPLMNidentity().byteArrayValue()));
                System.out.printf("%s: %s\n",  "Service-ID", 
                    toHstring(ie_value.getServiceID().byteArrayValue()));
                if (ie_value.hasIE_Extensions()) {
                    printProtocolExtensions(ie_value.getIE_Extensions(), "IE-Extensions");
                }
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_Session_ID)) {
                // Print MBMS-Session-ID IE
                OSS_M3AP_MBMS_Session_ID ie_value = (OSS_M3AP_MBMS_Session_ID)value;
                System.out.printf("value %s: %s\n",  "MBMS-Session-ID", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_E_RAB_QoS_Parameters)) {
                // Print MBMS-E-RAB-QoS-Params IE
                System.out.printf("value: %s:\n", "MBMS-E-RAB-QoS-Param fields");
                OSS_M3AP_MBMS_E_RAB_QoS_Parameters ie_value =
                    (OSS_M3AP_MBMS_E_RAB_QoS_Parameters)value;
                // Print QCI field
                System.out.printf("%s: %d\n", "QCI", ie_value.getQCI().intValue());
                // Print GBR-QoS-Info field, if present
                if (ie_value.hasGbrQosInformation()) {
                    OSS_M3AP_GBR_QosInformation qos_info = ie_value.getGbrQosInformation();
                    System.out.printf("%s:\n", "GBR-QoS-Info fields");
                    // Print MBMS-E-RAB-Guaranteed-Bitrate-Downlink field
                    System.out.printf("%s: %d\n", "MBMS-E-RAB-Max-Bitrate-Downlink",
                        qos_info.getMBMS_E_RAB_MaximumBitrateDL().longValue());
                    // Print MBMS-E-RAB-Max-Bitrate-Downlink field
                    System.out.printf("%s: %d\n", "MBMS-E-RAB-Guaranteed-Bitrate-Downlink",
                        qos_info.getMBMS_E_RAB_GuaranteedBitrateDL().longValue());
                    // Print IE-Extensions if present
                    if (qos_info.hasIE_Extensions()) {
                        printProtocolExtensions(qos_info.getIE_Extensions(), 
                            "IE-Extensions");
                    }
                }
                // Print IE-Extensions if present
                if (ie_value.hasIE_Extensions()) {
                    printProtocolExtensions(ie_value.getIE_Extensions(), "E-RAB-QoS-Params");
                }
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_E_RAB_QoS_Parameters)) {
                // Print Session-Duration IE
                OSS_M3AP_MBMS_Session_Duration ie_value =
                    (OSS_M3AP_MBMS_Session_Duration)value;
                System.out.printf("value %s: %s\n", "Session-Duration",
                        toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_Service_Area)) {
                // Print MBMS-Service-Area IE
                OSS_M3AP_MBMS_Service_Area ie_value = (OSS_M3AP_MBMS_Service_Area)value;
                System.out.printf("value %s: %s\n",  "MBMS-Service-Area", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MinimumTimeToMBMSDataTransfer)) {
                // Print Minimum-Time-To-MBMS-Data-Transfer IE
                OSS_M3AP_MinimumTimeToMBMSDataTransfer ie_value =
                    (OSS_M3AP_MinimumTimeToMBMSDataTransfer)value;
                System.out.printf("value %s: %s\n",  "Minimum-Time-To-MBMS-Data-Transfer", 
                    toHstring(ie_value.byteArrayValue()));
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_TNL_Information)) {
                // Print TNL-Information IE
                OSS_M3AP_TNL_Information ie_value = (OSS_M3AP_TNL_Information)value;
                System.out.printf("value %s: \n",  "TNL-Information fields");
                System.out.printf("%s: %s\n",  "IPMC-Address", 
                    toHstring(ie_value.getIPMCAddress().byteArrayValue()));
                System.out.printf("%s: %s\n",  "IP-Source-Address", 
                    ByteTool.toIPAddress(ie_value.getIPSourceAddress().byteArrayValue()));
                System.out.printf("%s: %s\n",  "GTP-DLTEID", 
                    toHstring(ie_value.getGTP_DLTEID().byteArrayValue()));
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_Time_ofMBMS_DataTransfer)) {
                // Time-Of-MBMS-DataTransfer
                OSS_M3AP_Absolute_Time_ofMBMS_Data ie_value =
                    (OSS_M3AP_Absolute_Time_ofMBMS_Data)value;
                System.out.printf("value %s: %s\n",  "Time-Of-MBMS-DataTransfer", 
                    toBstring(ie_value));
            } else {
                // Print other IEs via toString()
                if (value != null) {
                    System.out.print(value);
                } else {
                    System.out.println("The IE was left undecoded");
                }
            }
        }
    }

    /*
     * Creates an OSS_M3AP_SessionStartResponse PDU for a given
     * OSS_M3AP_SessionStartRequest PDU.
     */
    static OSS_M3AP_M3AP_PDU createSessionStartResponse(OSS_M3AP_MBMSSessionStartRequest req) 
    {
        System.out.printf("\nCreating Session Start Response...\n");
        OSS_M3AP_ProtocolIE_Container request_IEs = req.getProtocolIEs();
        
        if (request_IEs == null || request_IEs.getSize() == 0) {
            System.out.println("No IEs in Session Start Request");
            return null;
        }
        /* 
         * Find the MCE-MBMS-M3AP-ID IE which uniquely identifies the MBMS 
         * service association 
         */
        OSS_M3AP_MME_MBMS_M3AP_ID srcv_assoc_ID = null;
        for (int i=0; i<request_IEs.getSize(); i++) {
            OSS_M3AP_ProtocolIE_Field field = request_IEs.get(i);
            if (field.getId().equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MME_MBMS_M3AP_ID)) {
                srcv_assoc_ID = (OSS_M3AP_MME_MBMS_M3AP_ID)field.getValue().getDecodedValue();
                break;
            }
        }
        if (srcv_assoc_ID == null) {
            System.out.println("Unexpected Session Start Request data");
            return null;
        }
        
        // Create the protocol container
        OSS_M3AP_ProtocolIE_Container response_IEs = new OSS_M3AP_ProtocolIE_Container();
        // Add the MME-MBMS-M3AP-ID IE
        OSS_M3AP_ProtocolIE_Field field = new OSS_M3AP_ProtocolIE_Field(
            OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MME_MBMS_M3AP_ID, 
            OSS_M3AP_Criticality.ignore, 
            new OpenType(srcv_assoc_ID));
        response_IEs.add(field);
        // Add the MCE-MBMS-M3AP-ID IE
        field = new OSS_M3AP_ProtocolIE_Field(
            OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MCE_MBMS_M3AP_ID, 
            OSS_M3AP_Criticality.ignore, 
            new OpenType(new OSS_M3AP_MCE_MBMS_M3AP_ID(6600)));
        response_IEs.add(field);
        // Construct the SessionStartResponse message
        OSS_M3AP_MBMSSessionStartResponse resp =
            new OSS_M3AP_MBMSSessionStartResponse(response_IEs);
        // Construct the SuccessfulOutcome message
        OSS_M3AP_SuccessfulOutcome successfulOutcome = 
            new OSS_M3AP_SuccessfulOutcome(
                OSS_M3AP_M3AP_Constants.OSS_M3AP_id_mBMSsessionStart, 
                OSS_M3AP_Criticality.reject, 
                new OpenType(resp));
        // Construct and return the top-level PDU
        return OSS_M3AP_M3AP_PDU.createOSS_M3AP_M3AP_PDUWithSuccessfulOutcome(successfulOutcome);
    }

    /*
     * Prints ProtocolExtensionContainer data.
     */
    static void printProtocolExtensions(OSS_M3AP_ProtocolExtensionContainer ie_Extensions, String id) 
    {
        System.out.printf("%s includes the following extensions:\n", id);
        for (int i=0; i<ie_Extensions.getSize(); i++) {
            OSS_M3AP_ProtocolExtensionField ext = ie_Extensions.get(i);
            System.out.printf("EXTENSION#%d: id = %d, criticality = %s\n", i+1,
                ext.getId().intValue(), ext.getCriticality().name());
            AbstractData value = ext.getExtensionValue().getDecodedValue();
            if (value != null) {
                System.out.print(value);
            } else {
                System.out.println("The EXTENSION was left undecoded: ");
                System.out.println(HexTool.getHex(ext.getExtensionValue().getEncodedValue()));
            }
        }
    }

    static OSS_M3AP_M3AP_PDU createResetAcknowledge(OSS_M3AP_Reset req)
    {
        System.out.println("Creating Reset Acknowledge...");
        OSS_M3AP_ProtocolIE_Container req_ies = req.getProtocolIEs();
         
        if (req_ies == null || req_ies.getSize() == 0) {
            System.out.println("No IEs in Reset message");
            return null;
        }
        /*
         * The MCE shall in the RESET ACKNOWLEDGE message include, for each MBMS service
         * association to be reset, the MBMS-Service-associated logical M3-connection Item.
         * A particular RESET ACKNOWLEDGE message is created for the M3AP-PDU_Reset_bin.per PDU.
         */
        // Find Reset-Type IE in the RESET request message
        OSS_M3AP_ResetType reset_type = null;
        OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListRes rst_req_conn_items = null;
        for (int i = 0; i < req_ies.getSize(); i++) {
            OSS_M3AP_ProtocolIE_Field field = req_ies.get(i);
            OSS_M3AP_ProtocolIE_ID field_id = field.getId();
            if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_ResetType)) {
                OSS_M3AP_ResetType ie_value = 
                    (OSS_M3AP_ResetType)field.getValue().getDecodedValue();
                if (ie_value.hasPartOfM3_Interface()) {
                    reset_type = ie_value;
                    rst_req_conn_items = 
                        (OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListRes)ie_value.getChosenValue();
                }
            }
        }
        if (rst_req_conn_items == null) {
            System.out.println("Unexpected RESET data");
            return null;
        }
        OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListResAck ack_conn_items =
            new OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListResAck();
        for (int i=0; i<rst_req_conn_items.getSize(); i++) {
            OSS_M3AP_ProtocolIE_Field src = rst_req_conn_items.get(i);
            ack_conn_items.add(
                new OSS_M3AP_ProtocolIE_Field(
                    src.getId(), 
                    OSS_M3AP_Criticality.ignore, 
                    (OpenType)src.getValue().clone()));
        }
        // Create the protocol container
        OSS_M3AP_ProtocolIE_Container ack_ie = new OSS_M3AP_ProtocolIE_Container();
        // Add the MME-MBMS-M3AP-ID IE
        OSS_M3AP_ProtocolIE_Field field = new OSS_M3AP_ProtocolIE_Field(
            OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_Service_associatedLogicalM3_ConnectionListResAck, 
            OSS_M3AP_Criticality.ignore, 
            new OpenType(ack_conn_items));
        ack_ie.add(field);
        // Create the ResetAcknowledge
        OSS_M3AP_ResetAcknowledge ack = new OSS_M3AP_ResetAcknowledge(ack_ie);
        // Construct the SuccessfulOutcome message
        OSS_M3AP_SuccessfulOutcome successfulOutcome = 
            new OSS_M3AP_SuccessfulOutcome(
                OSS_M3AP_M3AP_Constants.OSS_M3AP_id_Reset, 
                OSS_M3AP_Criticality.reject, 
                new OpenType(ack));
        // Construct and return the top-level PDU
        return OSS_M3AP_M3AP_PDU.createOSS_M3AP_M3AP_PDUWithSuccessfulOutcome(successfulOutcome);
    }
    
    /*
     * Prints ProtocolIE_Container data.
     * This function handles only some IEs that can be present in a Reset message.
     */
    static void printResetProtocolIEs(OSS_M3AP_ProtocolIE_Container protocolIEs) 
    {
        System.out.printf("%s includes the following protocol IEs:\n", 
            "Reset message");
        // Print each IE
        for (int i = 0; i < protocolIEs.getSize(); i++) {
            OSS_M3AP_ProtocolIE_Field field = protocolIEs.get(i);
            OSS_M3AP_ProtocolIE_ID field_id = field.getId();
            System.out.printf("IE#%d: id = %2d, criticality = %s\n", i+1, 
                field_id.intValue(), field.getCriticality().name());
            AbstractData value = field.getValue().getDecodedValue();
            if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_Cause)) {
                // Print Cause IE
                OSS_M3AP_Cause ie_value = (OSS_M3AP_Cause)value;
                AbstractData selection = ie_value.getChosenValue();
                String cause = null, category = null;
                switch (ie_value.getChosenFlag()) {
                    case OSS_M3AP_Cause.radioNetwork_chosen:
                        category = "Radio Network Layer";
                        cause = ((OSS_M3AP_CauseRadioNetwork)selection).name();
                        break;
                    case OSS_M3AP_Cause.transport_chosen:
                        category = "Transport Layer";
                        cause = ((OSS_M3AP_CauseTransport)selection).name();
                        break;
                    case OSS_M3AP_Cause.nAS_chosen:
                        category = "NAS";
                        cause = ((OSS_M3AP_CauseNAS)selection).name();
                        break;
                    case OSS_M3AP_Cause.protocol_chosen:
                        category = "Pprotocol";
                        cause = ((OSS_M3AP_CauseProtocol)selection).name();
                        break;
                    case OSS_M3AP_Cause.misc_chosen:
                        category = "Misc";
                        cause = ((OSS_M3AP_CauseMisc)selection).name();
                        break;
                }
                if (cause == null) {
                    System.out.println("Unexpected Reset message content");
                    cause = "undefined";
                    category = "undefined";
                }
                System.out.printf("value %s: %s -> %s\n", "Cause", 
                    category, cause);
            } else if (field_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_ResetType)) {
                // Print Reset-Type IE
                OSS_M3AP_ResetType ie_value = (OSS_M3AP_ResetType)value;
                if (ie_value.hasM3_Interface()) {
                    OSS_M3AP_ResetAll reset_all = 
                        (OSS_M3AP_ResetAll)ie_value.getChosenValue();
                    if (reset_all == OSS_M3AP_ResetAll.reset_all) {
                        System.out.println("value Reset-Type: M3 Interface -> Reset All");
                    } else {
                        System.out.println("Unexpected reset message content");
                    }
                } else if (ie_value.hasPartOfM3_Interface()) {
                    OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListRes list =
                        (OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionListRes)ie_value.getChosenValue();
                    System.out.println("value Reset-Type: Part of M3 interface");
                    System.out.println("MBMS-Service-associated logical M3-connection list");
                    for (int k = 0; k < list.getSize(); k++) {
                        OSS_M3AP_ProtocolIE_Field entry = list.get(k);
                        OSS_M3AP_ProtocolIE_ID entry_id = entry.getId();
                        if (entry_id.equalTo(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_MBMS_Service_associatedLogicalM3_ConnectionItem)) {
                            OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionItem item =
                                (OSS_M3AP_MBMS_Service_associatedLogicalM3_ConnectionItem)entry.getValue().getDecodedValue();
                            System.out.printf("ITEM#%d\n", k+1);
                            // Print MME-MBMS-M3AP-ID field if present
                            if (item.hasMME_MBMS_M3AP_ID()) {
                                System.out.printf("%s: %d\n", "MME-MBMS-M3AP-ID",
                                    item.getMME_MBMS_M3AP_ID().intValue());
                            }
                            // Print MCE-MBMS-M3AP-ID field if present
                            if (item.hasMCE_MBMS_M3AP_ID()) {
                                System.out.printf("%s: %d\n", "MCE-MBMS-M3AP-ID",
                                    item.getMCE_MBMS_M3AP_ID().intValue());
                            }
                            // Print IE-Extensions if present
                            if (item.hasIE_Extensions()) {
                                printProtocolExtensions(item.getIE_Extensions(), 
                                "IE-Extensions");
                            }
                        }
                    }
                }
            } else {
                // Print other IEs via toString()
                if (value != null) {
                    System.out.print(value);
                } else {
                    System.out.println("The IE was left undecoded");
                }
            }
        }
    }
    
    /*
     * M3AP elementary procedure codes
     */
    public static enum ProcedureID {
        MBMSsessionStart(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_mBMSsessionStart),
        MBMSsessionStop (OSS_M3AP_M3AP_Constants.OSS_M3AP_id_mBMSsessionStop),
        MBMSsessionUpdate(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_mBMSsessionUpdate),
        Reset(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_Reset),
        M3Setup(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_m3Setup),
        MCEConfigurationUpdate(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_mCEConfigurationUpdate),
        ErrorIndication(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_errorIndication),
        PrivateMessage(OSS_M3AP_M3AP_Constants.OSS_M3AP_id_privateMessage),
        Unknown(null);
        
        private int id;
        private ProcedureID(OSS_M3AP_ProcedureCode id)
        {
            if (id != null)
                this.id = id.intValue();
        }
        
        public static ProcedureID valueOf(OSS_M3AP_ProcedureCode id)
        {
            int code = id.intValue();
            ProcedureID[] enums = values();
            int unknown = enums.length-1;
            for (int i=0; i<unknown; i++) {
                if (code == enums[i].id)
                    return enums[i];
            }
            
            return enums[unknown];
        }
    }

    /*
     * Represents am incomplete implementation
     * of MCE-side function processing an M3AP message. It decodes the
     * message, prints it, and creates a response for some particular
     * alternatives. The function can be used to implement a complete
     * LTE M3AP MCE-side dispatcher.
     */

    static void test_M3AP_Message(String path, String filename) throws IOException, Exception
    {
        OSS_M3AP_M3AP_PDU incoming;

	File file = new File(path, filename);
	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	System.out.println("Read encoding from file: " + filename + "\n");
	System.out.println("Decoding the input M3AP message...");
	System.out.println(border);
	/* Deserialize input message */
        incoming = (OSS_M3AP_M3AP_PDU)coder.decode(
    			    source, new OSS_M3AP_M3AP_PDU());
	source.close();
	System.out.println("\nPDU decoded");

	if (!incoming.hasInitiatingMessage()) {
	    throw new Exception("Incorrect message: expecting InitiatingMessage");
	}
        
        OSS_M3AP_InitiatingMessage msg = 
            (OSS_M3AP_InitiatingMessage)incoming.getChosenValue();
        
        ProcedureID code = ProcedureID.valueOf(msg.getProcedureCode());
        switch (code) {
            /* You can take unimplemented alternatives one by
             * one and add support for them */
            case MBMSsessionStart:
            {
                OSS_M3AP_MBMSSessionStartRequest req = 
                    (OSS_M3AP_MBMSSessionStartRequest)msg.getValue().getDecodedValue();
                printSessionStartRequestProtocolIEs(req.getProtocolIEs());
                OSS_M3AP_M3AP_PDU resp = 
                    createSessionStartResponse(req);
                if (resp != null) {
                    System.out.println("Response created successfully");
                    System.out.println("The Session Start Response message");
                    System.out.println(border);
                    System.out.println(resp);
                    System.out.println("Serializing response...");
                    System.out.println(border);
                    ByteArrayOutputStream sink = new ByteArrayOutputStream();
                    coder.encode(resp, sink);
                    sink.close();
                    byte[] encoded = sink.toByteArray();
                    System.out.printf("Serialized response (%d bytes):\n",
                        encoded.length);
                    System.out.println(border);
                    System.out.println(HexTool.getHex(encoded));
                }
                break;
            }
            case Reset:
            {
                OSS_M3AP_Reset req = 
                    (OSS_M3AP_Reset)msg.getValue().getDecodedValue();
                printResetProtocolIEs(req.getProtocolIEs());
                OSS_M3AP_M3AP_PDU resp = 
                    createResetAcknowledge(req);
                if (resp != null) {
                    System.out.println("Acknowledge created successfully");
                    System.out.println("The Reset Acknowledge message");
                    System.out.println(border);
                    System.out.println(resp);
                    System.out.println("Serializing response...");
                    System.out.println(border);
                    ByteArrayOutputStream sink = new ByteArrayOutputStream();
                    coder.encode(resp, sink);
                    sink.close();
                    byte[] encoded = sink.toByteArray();
                    System.out.printf("Serialized response (%d bytes):\n",
                        encoded.length);
                    System.out.println(border);
                    System.out.println(HexTool.getHex(encoded));
                }
                break;
            }
            case M3Setup:
            case MBMSsessionStop:
            case MBMSsessionUpdate:
            case ErrorIndication:
            case MCEConfigurationUpdate:
            case PrivateMessage:
                System.out.printf("%s - Unimplemented \n", code.name());
                break;
            case Unknown:
                System.out.printf("Unexpected PDU type \n");
                break;
        }
    }
    
    /*
     * Formats the value of BIT STRING as binary string
     */
    static String toBstring(BitString bitString)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        for (int i=0; i<bitString.getSize(); i++)
            buffer.append(bitString.getBit(i) ? '1' : '0');
        buffer.append("'B");
        
        return buffer.toString();
    }

    /*
     * Formats the value of byte[] as hex string
     */
    static String toHstring(byte[] bytes)
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("'");
        buffer.append(HexTool.getHex(bytes, 0));
        buffer.append("'H");
        
        return buffer.toString();
    }
}
