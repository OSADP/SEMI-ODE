/*
 * Copyright (C) 2016 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Tdefer.java	16.2 14/02/08 */
/*
 * This example demonstrates use of the DeferDecoding ASN.1 compiler directive.
 * The example does the following:
 * 
 * 1. Encodes a PDU object.
 * 2. Decodes with the DeferDecoding directive disabled.
 * 3. Decodes with the DefeDecoding directive enabled.
 * 4. Decodes the deferred component separately.
 * 5. Changes the component to a new value.
 * 6. Encodes the changed component separately.
 * 6. Encodes the parent enclosing PDU object with the encoded component.
 *
 * To run the program say:
 *
 * asn1pjav defer.asn
 * cd defer
 * defer.bat javac
 * cd ..
 * javac -g *.java
 * java Tdefer
 */


/* Compiler-generated classes */
import defer.Defer;
import defer.defersample.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;


public class Tdefer {

    public static void main(String args[]) {

		//
		// Initialize the project.
		//
	try {
	    Defer.initialize();
	}
	catch (Exception e) {
	    System.out.println("Initialization failed with exception: " + e);
	    System.exit(1);
	}

	Coder coder = Defer.getBERCoder();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	ByteArrayOutputStream sink = new ByteArrayOutputStream();

		//
		// Encode the PDU.
		//
	try {
	    Type data = new Type(32, true);
	    System.out.println("\nEncoding PDU object...\n");
	    coder.encode(data, sink);

		//
		// Decode the PDU.
		//
	    byte[] typeEncoding = sink.toByteArray();
	    try {
		ByteArrayInputStream source =
		    new ByteArrayInputStream(typeEncoding);
		System.out.println(
		    "\nDecoding PDU with DeferDecoding disabled...\n");
		coder.disableDeferredDecoding();
		Type decoded = (Type) coder.decode(source, new Type());
			//
			// The component "setComponent" is decoded by the
			// decoder since the DeferDecoding directive is
			// disabled.
			//
	    }
	    catch (Exception e) {
		System.out.println("Decoding failed with exception: " + e);
	    }

	    ByteArrayInputStream source =
		new ByteArrayInputStream(typeEncoding);
	    System.out.println(
		"Decoding PDU with DeferDecoding enabled...\n");
	    coder.enableDeferredDecoding();
	    Type decoded = (Type) coder.decode(source, new Type());
		//
		// The compinent "setComponent" is left undecoded
		// as a result DeferDecoding being enabled.
		//
	    byte[] encoded = decoded.getEncodedSetComponent();

		//
		// Now we can perform processing of the encoded component
		// separately.
		//
	    System.out.println("\n\tEncoded deferred component...\n");
	    HexTool.printHex(encoded);

		//
		// Decode the component.
		//
	    System.out.println("\nDecoding the deferred component...\n");
	    decoded.decodeSetComponent(coder);

		//
		// Now the component is fully decoded and we can print it.
		//
	    System.out.println("\n\tDecoded PDU with fully decoded deferred component...\n");
	    System.out.println(decoded);

		 //
		 // Change the component to a new value.
		 //
	    System.out.println("Changing the value of the component...");
	    decoded.setSetComponent(324);

		//
		// Encode the changed component.
		//
	    System.out.println("\nRe-encoding the changed component...\n");
	    decoded.encodeSetComponent(coder);
	    byte [] encodedAgain = decoded.getEncodedSetComponent();

		//
		// Check the new length.
		//
	    if (encoded.length == encodedAgain.length) {
		System.out.println("\nError occurred while re-encoding the component.\n");
		HexTool.printHex(encodedAgain);
	    }
	    else {
		System.out.println("Re-encoded successfully.");
		System.out.println("\n\tRe-encoded deferred component.\n");
		HexTool.printHex(encodedAgain);
	    }
	}
	catch (DecodeFailedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	}
	catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed with exception: " + e);
	}
	catch (EncodeFailedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}
	catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed with exception: " + e);
	}
	finally {
		//
		// Do a final cleanup.
		//
	    Defer.deinitialize();
	}
    }
}

