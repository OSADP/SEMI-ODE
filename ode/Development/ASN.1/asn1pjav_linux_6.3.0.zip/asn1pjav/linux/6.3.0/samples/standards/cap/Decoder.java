/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Decoder.java	16.2 14/02/08
 */

/*
 * Demonstrates CAP PDU decoding and further processing.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import cap.*;
import cap.cap_gsmssf_gsmscf_pkgs_contracts_acs.*;
import cap.tcapmessages.*;
import cap.dialoguepdus.*;
import cap.unidialoguepdus.*;
import cap.remote_operations_generic_ros_pdus.*;
import cap.remote_operations_information_objects.*;
import cap.cs1_datatypes.*;
import cap.map_commondatatypes.*;
import cap.map_ms_datatypes.*;
import cap.cap_sample_values.*;

public class Decoder {

	/*
	 * BER-encoded sample PDU.
	 */
     static byte encodedData[] = new byte[] {
    (byte)0x62, (byte)0x81, (byte)0xA8, (byte)0x48, (byte)0x04, (byte)0x70,
    (byte)0x00, (byte)0x01, (byte)0xFD, (byte)0x6B, (byte)0x1E, (byte)0x28,
    (byte)0x1C, (byte)0x06, (byte)0x07, (byte)0x00, (byte)0x11, (byte)0x86,
    (byte)0x05, (byte)0x01, (byte)0x01, (byte)0x01, (byte)0xA0, (byte)0x11,
    (byte)0x60, (byte)0x0F, (byte)0x80, (byte)0x02, (byte)0x07, (byte)0x80,
    (byte)0xA1, (byte)0x09, (byte)0x06, (byte)0x07, (byte)0x04, (byte)0x00,
    (byte)0x00, (byte)0x01, (byte)0x00, (byte)0x32, (byte)0x01, (byte)0x6C,
    (byte)0x80, (byte)0xA1, (byte)0x7C, (byte)0x02, (byte)0x01, (byte)0x00,
    (byte)0x02, (byte)0x01, (byte)0x00, (byte)0x30, (byte)0x74, (byte)0x80,
    (byte)0x01, (byte)0x64, (byte)0x83, (byte)0x07, (byte)0x83, (byte)0x13,
    (byte)0x37, (byte)0x97, (byte)0x01, (byte)0x04, (byte)0x02, (byte)0x85,
    (byte)0x01, (byte)0x0A, (byte)0x8A, (byte)0x08, (byte)0x84, (byte)0x93,
    (byte)0x64, (byte)0x37, (byte)0x97, (byte)0x00, (byte)0x03, (byte)0x01,
    (byte)0xBB, (byte)0x05, (byte)0x80, (byte)0x03, (byte)0x80, (byte)0x90,
    (byte)0xA3, (byte)0x9C, (byte)0x01, (byte)0x02, (byte)0x9F, (byte)0x32,
    (byte)0x08, (byte)0x42, (byte)0x00, (byte)0x47, (byte)0x26, (byte)0x00,
    (byte)0x00, (byte)0x04, (byte)0xF2, (byte)0xBF, (byte)0x34, (byte)0x17,
    (byte)0x02, (byte)0x01, (byte)0x00, (byte)0x81, (byte)0x07, (byte)0x91,
    (byte)0x64, (byte)0x37, (byte)0x97, (byte)0x00, (byte)0x03, (byte)0xF1,
    (byte)0xA3, (byte)0x09, (byte)0x80, (byte)0x07, (byte)0x42, (byte)0xF0,
    (byte)0x50, (byte)0x00, (byte)0x2A, (byte)0x03, (byte)0x60, (byte)0xBF,
    (byte)0x35, (byte)0x03, (byte)0x83, (byte)0x01, (byte)0x11, (byte)0x9F,
    (byte)0x36, (byte)0x05, (byte)0x00, (byte)0x12, (byte)0x7B, (byte)0x00,
    (byte)0x00, (byte)0x9F, (byte)0x37, (byte)0x07, (byte)0x91, (byte)0x64,
    (byte)0x37, (byte)0x97, (byte)0x00, (byte)0x03, (byte)0xF1, (byte)0x9F,
    (byte)0x38, (byte)0x06, (byte)0x81, (byte)0x70, (byte)0x40, (byte)0x62,
    (byte)0x34, (byte)0x07, (byte)0x9F, (byte)0x39, (byte)0x08, (byte)0x02,
    (byte)0x30, (byte)0x11, (byte)0x72, (byte)0x31, (byte)0x95, (byte)0x84,
    (byte)0x00, (byte)0x00, (byte)0x00
    };

    public static void main(String[] args)
    {
	// Initialize the project
	try {
	    Cap.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Cap.getBERCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	System.out.println("Original BER-encoded PDU...\n");
	HexTool.printHex(encodedData);
	System.out.println("\nDecoding...");

	ByteArrayInputStream source = new ByteArrayInputStream(encodedData);

	/*
	 * Decode the PDU.
	 */
	GenericSSF_gsmSCF_PDUs msg = null;
	try {
	    msg = (GenericSSF_gsmSCF_PDUs)
		coder.decode(source, new GenericSSF_gsmSCF_PDUs());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}
	/*
	 * Decode the nested OpenType value (dialoguePortion is an External
	 * type).
	 */
	switch (msg.getChosenFlag()) {
	case GenericSSF_gsmSCF_PDUs.begin_chosen:
		    /*
		     * Check if the optional dialogPortion field present and it
		     * contains a direct reference to the enclosed type.
		     */
	    GenericSSF_gsmSCF_PDUs.Begin begin =
		(GenericSSF_gsmSCF_PDUs.Begin)msg.getChosenValue();

	    if (begin.hasDialoguePortion() &&
		begin.getDialoguePortion().hasDirect_reference()) {

		AbstractData pdu = null;
		if (DialoguePDUs.dialogue_as_id.equals(begin.getDialoguePortion().getDirect_reference())) {
		    pdu = new DialoguePDU();
		} else if (UnidialoguePDUs.uniDialogue_as_id.equals(begin.getDialoguePortion().getDirect_reference())) {
		    pdu = new UniDialoguePDU();
		}
		OpenType encoding =
		    (OpenType)begin.getDialoguePortion().getEncoding().getChosenValue();

		AbstractData decoded = null;
		try {
		    decoded = coder.decode(
			encoding.getEncodedValueAsStream(), pdu);
		} catch (DecodeNotSupportedException e) {
		    System.out.println("Decoding failed: " + e);
		    System.exit(3);
		} catch (DecodeFailedException e) {
		    System.out.println("Decoding failed: " + e);
		    System.exit(3);
		}
		encoding.setDecodedValue(decoded);
		System.out.println("Decoded successfully.");
	    }
	    break;
	default:
	    ; /* do nothing for other alternatives */
	}

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(msg);
	/*
	 * Check to see that the PDU was decoded properly by comparing it
	 * with the value generated by the ASN.1 compiler from the value
	 * notation present in the ASN.1 syntax.
	 */
	System.out.println("\nComparing with the original PDU...");
	if (!msg.equals(CAP_Sample_Values.value)) {
	    System.out.println("Comparison failed.");
	    System.exit(4);
	}
	System.out.println("Comparison succeeded.");
    }

}
