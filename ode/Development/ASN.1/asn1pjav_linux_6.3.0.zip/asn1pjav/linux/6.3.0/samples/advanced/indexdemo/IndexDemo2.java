/*
 * Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
 */
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)IndexDemo2.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/**
    Application program IndexDemo2.java
    Demonstrates OSS ASN.1/Java Tools API for indexing multiple 
    information object sets. This demo uses IndexProcedure to 
    perform automatic indexing on all information object sets of
    selected class.
*/

/* To run the program:

asn1pjav index1.asn -indexinfoobjectsets
cd index1
index1.bat javac
cd ..
javac -g IndexDemo2.java
java IndexDemo2

If you experience difficulties running or compiling this program, carefully
read through the Installing section of the quickstart.html guide in the
doc/guide directory of your shipment. If that doesn't help contact
support@oss.com. Be sure to submit your license number, as well as a
description of the problem.
*/

/* main() shows how to automatically index all        */
/*    information object sets which are instances     */
/*    of PARAMETER_OSET class. First the automatic    */
/*    indexing is enabled via setIndexProcedure()     */
/*    API call on the class PARAMETER_OSET. Next      */
/*    three information object sets which are         */
/*    defined  in the index1.asn spec are examined    */
/*    to see if they were automatically indexed.      */

/* Compiler-generated classes */
import index1.*;
import index1.ind1.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;
import java.util.*;


public class IndexDemo2 {


    public static void main(String args[]) {

	// Initialize the project
	try {
	    Index1.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Set IndexProcedure for the PARAMETER_OSET class.
      // Automatic indexing via the hash function supplied by mapKey
      // is enabled for all information object sets 
      // defined using the PARAMETER_OSET class.
	// Two anonymous inner classes are used to extend
	// IndexProcedure class and DefaultIndex class.

	PARAMETER_OSET.setIndexProcedure(
	    new IndexProcedure() {
		public Index create(IndexedInfoObjectSet oset) {
		    // Only index information object sets that are
		    // not empty and contain more than a few elements.
                // The mapping is to use the key as the index.
		    if (oset.getSize() > 2) {
			Index index = new DefaultIndex() {
			    public int mapKey(AbstractData key) {
				return ((INTEGER)key).intValue();
			    }
			 };
			 if (((PARAMETER_OSET)oset).indexById(index))
			     return oset.getIndex();
		     }
		     return null;
		}
	    }
	);

	// Examine index of object sets found in index1.asn
	examineIndex(Ind1.kNOWN_PARAMETERS, "KNOWN-PARAMETERS");
	examineIndex(Ind1.eXTRA_PARAMETERS, "EXTRA-PARAMETERS");
	examineIndex(Ind1.mORE_PARAMETERS, "MORE-PARAMETERS");

    }

    /**
	The method prints index statistics of an info object set
    */
    static void examineIndex(IndexedInfoObjectSet oset, String name)
    {
	DefaultIndex index = (DefaultIndex)oset.getIndex();

	if (index != null) {
	    System.out.println("The information object set " + name + " is indexed");
	    System.out.println("index.size() == " + index.size());
	    System.out.println("index.numberOfBuckets() == " + index.numberOfBuckets());
	    System.out.println("index.minBucket() == " + index.minBucket());
	    System.out.println("index.maxBucket() == " + index.maxBucket());
	} else {
	    System.out.println("The information object set " + name + " is not indexed");
	}
    }
}
