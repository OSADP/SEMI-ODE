/*************************************************************/
/* Copyright (C) 2016 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)External3.java	16.2 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/* Application Program: External3.java

   Illustrates the third possible way to process the encoding that is nested
   in the value of the EXTERNAL ASN.1 type. The type of the value of the
   encoding in the 'encoding' component of the EXTERNAL is identified by the
   OBJECT IDENTIFIER in the 'direct-reference' field.
   
   When the sender always encodes the value of EXTERNAL using the
   'single-ASN1-type' alternative of the 'encoding', the decoder can
   decode the value in a single step. This is possible due to the
   automatic decoding feature that is available in the OSS runtime.
   
   Although the EXTERNAL type provides no means to automatically decode the
   'encoding' component, when the 'encoding' is constrained to the
   'single-ASN1-type' alternative, the overall encoding of EXTERNAL is
   identical to the encoding of another useful ASN.1 type - the INSTANCE OF
   type.
   
   Unlike EXTERNAL, INSTANCE OF allows for automatic decoding. So this
   sample program decodes the input octets as if they represent the encoding 
   of the value of INSTANCE OF:

	INSTANCE OF TYPE-IDENTIFIER({Links})

   where the 'Links' information object set links the 'direct-reference' field
   of EXTERNAL to the type of the value in the 'encoding' field. This
   sample uses the same information object set as the External2.java sample:
   
    Links TYPE-IDENTIFIER ::= {
	{DialoguePDU IDENTIFIED BY dialogue-as-id},
	...
    }
   
    To run the sample perform the following steps:

    asn1pjav dialogue.asn -ber -nounique
    cd dialogue
    dialogue.bat javac
    javac -g ../External3.java
    java External3
*/

/* Compiler generated classes */
import dialogue.*;
import dialogue.dialoguepdus.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;

/* Java I/O classes */
import java.io.*;

public class External3 {
    public static void main(String[] args)
    {
	try {
	    Dialogue.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization failed: " + e);
	    System.exit(1);
	}

	// Open the file that contains the input encoding
	String dataFile = "myDialogue.ber";
	FileInputStream encodedData = null;

	try {
	    encodedData = new FileInputStream(dataFile);
	} catch (IOException e) {
	    System.out.println("Cannot open " + dataFile + " for reading: " + e);
	    System.exit(2);
	}

	// Create the BER coder, set it to emit the diagnostic output
	// and enable automatic decoding
	Coder coder = Dialogue.getBERCoder();
	coder.enableDecoderDebugging();
	coder.enableAutomaticDecoding();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	try {
	    // Decode the value in one step. Note that although the input
	    // contains the encoding of EXTERNAL, the decoder decodes it
	    // as the value of INSTANCE OF.
	    MyDialogue_1997 myDialogue = 
		(MyDialogue_1997)coder.decode(encodedData, new MyDialogue_1997()); 
	    // Print the decoded value
	    System.out.println();
	    System.out.println("The value decoded:");
	    System.out.println(myDialogue);
	} catch (Exception e) {
	    System.out.println("Decoding has failed: " + e);
	}

	try {
	    encodedData.close();
	} catch (IOException e) {
	    System.out.println("Error when closing the input file: " + e);
	}

	Dialogue.deinitialize();
    }
}
