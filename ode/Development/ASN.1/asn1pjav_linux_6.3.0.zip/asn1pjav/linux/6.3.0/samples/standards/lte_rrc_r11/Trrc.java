/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.	          */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Trrc.java	17.2  15/11/13
 */

/*
 * Demonstrates part of RRC protocol layer of an LTE UE stack.
 */

import java.io.*;

import com.oss.asn1.*;
import com.oss.util.*;

import rrc.*;
import rrc.oss_rrc_eutra_internodedefinitions.*;
import rrc.oss_rrc_eutra_rrc_definitions.*;
import rrc.oss_rrc_eutra_ue_variables.*;

public class Trrc {

    static Coder coder;
    static String border = "-------------------------------------------------------";

    /*
     * Decodes and prints the input messages; creates, encodes and prints 
     * the output (response) messages.
     */
    public static void main(String[] args) 
    {
	// Initialize the project
	try {
	    Rrc.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	coder = Rrc.getPERUnalignedCoder();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();

	// An optional parameter includes the path to all the files that are used by
	// the program.
	String path = (args.length > 0) ? args[0] : null;

	try {
	    testDL_DCCH_Message(path, "RRCConnectionRelease.uper");
	} catch (Exception e) {
	    System.out.println(e);
	}

	try {
	    testDL_DCCH_Message(path, "SecurityModeCommand.uper");
	} catch (Exception e) {
	    System.out.println(e);
	}

	try {
	    testDL_DCCH_Message(path, "LoggedMeasurementConfiguration.uper");
	} catch (Exception e) {
	    System.out.println(e);
	}

	System.out.println("\nTesting successful");
    }

    /*
     * Represents am imcomplete implementation of UE-side function processing
     * a downlink DCCH message. It decodes the message, prints it, and creates
     * a response for some particular alternatives. The function can be used
     * to implement a complete LTE RRC UE-side dispatcher.
     */
    static void testDL_DCCH_Message(String path, String filename) throws IOException, Exception
    {
	OSS_RRC_DL_DCCH_Message 	request;
	OSS_RRC_UL_DCCH_Message 	response;

	File file = new File(path, filename);
	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}
	FileInputStream source = new FileInputStream(file);

	System.out.println("============================================================================");
	System.out.println("Read encoding from file: " + filename + "\n");
	System.out.println("Decoding the input downlink DCCH message");
	System.out.println(border);
	/* Deserialize input message */
        request = (OSS_RRC_DL_DCCH_Message)coder.decode(
    			    source, new OSS_RRC_DL_DCCH_Message());
	source.close();
	System.out.println("\nPDU decoded");
	
	if (!request.getMessage().hasC1()) {
	    throw new Exception("Incorrect message");
	}

	OSS_RRC_DL_DCCH_MessageType.C1 msg_typ = 
		(OSS_RRC_DL_DCCH_MessageType.C1)
					request.getMessage().getChosenValue();
	System.out.println(border);
	switch (msg_typ.getChosenFlag()) {
	    /* You can take unimplemented CHOICE alternatives one by
	     * one and add support for them */
	    case OSS_RRC_DL_DCCH_MessageType.C1.csfbParametersResponseCDMA2000_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.dlInformationTransfer_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.handoverFromEUTRAPreparationRequest_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.mobilityFromEUTRACommand_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.rrcConnectionReconfiguration_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.rrcConnectionRelease_chosen:
		/* Print deserialized message */
		System.out.println(request);
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.securityModeCommand_chosen:
		/* Print deserialized message */
		System.out.println(request);
		System.out.println("Creating response");
		System.out.println(border);
		/* Create response */
		response = createSecurityModeCommandResponse(request);

		System.out.println();
		System.out.println("Response created successfully");
		System.out.println(border);
		/* Print outcome message */
		System.out.println(response);
		System.out.println("Encoding response");
		System.out.println(border);
		/* Serialize outcome message */
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
		    coder.encode(response, out);
		    out.close();
		} catch (Exception e) {
		    System.out.println("Encoding failed: " + e);
		    System.exit(1);
		}

		/* Print serialized outcome message */
		System.out.println("\nEncoded response "
				+ "(" + out.size() + " bytes):");
		System.out.println(HexTool.getHex(out.toByteArray()));

		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.ueCapabilityEnquiry_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.counterCheck_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.ueInformationRequest_r9_chosen:
		System.out.println("Unimplemented");
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.loggedMeasurementConfiguration_r10_chosen:
		System.out.println(request);
		break;
	    case OSS_RRC_DL_DCCH_MessageType.C1.rnReconfiguration_r10_chosen:
		System.out.println("The message is not intended for UE");
		break;
	    default:
		System.out.println("Unknown CHOICE alternative selected");
		break;
	}	
    }

    /*
     * Creates an OSS_RRC_UL_DCCH_Message PDU (security mode complete) 
     * for given OSS_RRC_DL_DCCH_Message PDU (security mode command).
     */
    static OSS_RRC_UL_DCCH_Message createSecurityModeCommandResponse(
				OSS_RRC_DL_DCCH_Message request)
    throws IOException, Exception
    {
	OSS_RRC_SecurityAlgorithmConfig.IntegrityProtAlgorithm ipalg;
	OSS_RRC_SecurityAlgorithmConfig.CipheringAlgorithm calg;

	if (!request.getMessage().hasC1()
	    || !((OSS_RRC_DL_DCCH_MessageType.C1)
		request.getMessage().getChosenValue()).hasSecurityModeCommand()
	    || !((OSS_RRC_SecurityModeCommand)((OSS_RRC_DL_DCCH_MessageType.C1)
	    	    request.getMessage().getChosenValue()).getChosenValue()
	    	).getCriticalExtensions().hasC1()
	    || !((OSS_RRC_SecurityModeCommand.CriticalExtensions.C1)
		((OSS_RRC_SecurityModeCommand)((OSS_RRC_DL_DCCH_MessageType.C1)
	    	    request.getMessage().getChosenValue()).getChosenValue()
	        ).getCriticalExtensions().getChosenValue()).hasSecurityModeCommand_r8()
	   )
	    throw new Exception("cannot handle ASN.1 data");



	ipalg = ((OSS_RRC_SecurityModeCommand_r8_IEs)
		((OSS_RRC_SecurityModeCommand.CriticalExtensions.C1)((OSS_RRC_SecurityModeCommand)
		 ((OSS_RRC_DL_DCCH_MessageType.C1)request.getMessage().getChosenValue()
		 ).getChosenValue()).getCriticalExtensions().getChosenValue()).getChosenValue()
		).getSecurityConfigSMC().getSecurityAlgorithmConfig().getIntegrityProtAlgorithm();
    
	calg = ((OSS_RRC_SecurityModeCommand_r8_IEs)
		((OSS_RRC_SecurityModeCommand.CriticalExtensions.C1)((OSS_RRC_SecurityModeCommand)
		 ((OSS_RRC_DL_DCCH_MessageType.C1)request.getMessage().getChosenValue()
		 ).getChosenValue()).getCriticalExtensions().getChosenValue()).getChosenValue()
		).getSecurityConfigSMC().getSecurityAlgorithmConfig().getCipheringAlgorithm();

	if (ipalg != OSS_RRC_SecurityAlgorithmConfig.IntegrityProtAlgorithm.eia0_v920
		&& ipalg != OSS_RRC_SecurityAlgorithmConfig.IntegrityProtAlgorithm.eia1
		&& ipalg != OSS_RRC_SecurityAlgorithmConfig.IntegrityProtAlgorithm.eia2)
	    throw new Exception("unknown integrity protection");

	if (calg != OSS_RRC_SecurityAlgorithmConfig.CipheringAlgorithm.eea0
		&& calg != OSS_RRC_SecurityAlgorithmConfig.CipheringAlgorithm.eea1
		&& calg != OSS_RRC_SecurityAlgorithmConfig.CipheringAlgorithm.eea2)
	    throw new Exception("unknown ciphering");

	OSS_RRC_RRC_TransactionIdentifier transactionIdentifier =
	    ((OSS_RRC_SecurityModeCommand)((OSS_RRC_DL_DCCH_MessageType.C1)
		request.getMessage().getChosenValue()).getChosenValue()).getRrc_TransactionIdentifier();
	OSS_RRC_SecurityModeComplete.CriticalExtensions criticalExtensions =
	    OSS_RRC_SecurityModeComplete.CriticalExtensions.
		createCriticalExtensionsWithSecurityModeComplete_r8(
		    new OSS_RRC_SecurityModeComplete_r8_IEs());
	OSS_RRC_SecurityModeComplete securityModeComplete =
	    new OSS_RRC_SecurityModeComplete(transactionIdentifier, criticalExtensions);
	OSS_RRC_UL_DCCH_MessageType.C1 c1 =
	    OSS_RRC_UL_DCCH_MessageType.C1.createC1WithSecurityModeComplete(securityModeComplete);
	OSS_RRC_UL_DCCH_MessageType message =
	    OSS_RRC_UL_DCCH_MessageType.createOSS_RRC_UL_DCCH_MessageTypeWithC1(c1);
	OSS_RRC_UL_DCCH_Message response = new OSS_RRC_UL_DCCH_Message(message);

	return response;
    }
}
