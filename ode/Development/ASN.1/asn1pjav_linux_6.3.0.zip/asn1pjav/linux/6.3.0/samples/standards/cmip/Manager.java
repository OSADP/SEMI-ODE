/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Manager.java	16.3 14/02/08
 */

/*
 * Demonstrates a sample of CMIP protocol exchange:
 * the manager sends an M-GET request to the agent and receives a GetResult reply.
 * Interaction between the manager and agent is emulated only - the manager decodes
 * the M-GET reply from a predefined buffer as if it were just received from the
 * agent.
 */
import java.io.*;

import com.oss.asn1.*;
import com.oss.util.HexTool;

import cmip.*;
import cmip.cmip_1.*;
import cmip.cmip_sample.*;
import cmip.remote_operations_generic_ros_pdus.*;
import cmip.remote_operations_information_objects.*;

public class Manager {

    /* Predefined M-GET reply message as if it were received from the agent */
    static byte reply[] = new byte[] {
    (byte)0x60, (byte)0x01, (byte)0x0A, (byte)0x00, (byte)0x01, (byte)0x03, (byte)0x2C, (byte)0x78,
    (byte)0x06, (byte)0x2B, (byte)0x06, (byte)0x01, (byte)0x02, (byte)0x01, (byte)0x04, (byte)0x00,
    (byte)0x01, (byte)0x00, (byte)0x13, (byte)0x32, (byte)0x30, (byte)0x30, (byte)0x32, (byte)0x30,
    (byte)0x38, (byte)0x32, (byte)0x31, (byte)0x32, (byte)0x32, (byte)0x32, (byte)0x35, (byte)0x34,
    (byte)0x31, (byte)0x2E, (byte)0x39, (byte)0x38, (byte)0x37, (byte)0x5A, (byte)0x02, (byte)0x80,
    (byte)0x01, (byte)0x04, (byte)0x02, (byte)0x01, (byte)0x00, (byte)0x80, (byte)0x01, (byte)0x05,
    (byte)0x02, (byte)0x01, (byte)0x02
    };

    public static void main(String[] args) {

	/* Sending message */
	// Initialize the project
	try {
	    Cmip.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	Coder coder = Cmip.getPERAlignedCoder();

	coder.enableEncoderDebugging();
	coder.enableDecoderDebugging();
	coder.enableAutomaticEncoding();
	coder.enableAutomaticDecoding();
	
        /*
         * Construct an M-GET request PDU for encoding.
         */
	AbstractData msg = fill_mget_Request();
	System.out.println("\nPDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}

	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);
	
	/* Reseiving response */
	
	System.out.println("Original PER-encoded PDU...\n");
	HexTool.printHex(reply);
	System.out.println("\nDecoding...");

	ByteArrayInputStream source = new ByteArrayInputStream(reply);
	
	CMIP_1.attributeSet.addElement(CMIP_Sample.attribute1);
	CMIP_1.attributeSet.addElement(CMIP_Sample.attribute2);
	/*
	 * Decode the response.
	 */
	msg = null;
	try {
	    msg = (ROSEapdus)
		coder.decode(source, new ROSEapdus());
	} catch (DecodeNotSupportedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	} catch (DecodeFailedException e) {
	    System.out.println("Decoding failed: " + e);
	    System.exit(2);
	}

	/*
	 * Print the PDU.
	 */
	System.out.println("\nDecoded PDU...\n");
	System.out.println(msg);	
    }

    static ROSEapdus fill_mget_Request()
    {
	InvokeId invoke_id = InvokeId.createInvokeIdWithPresent(10);
	Code invoke_opcode = Code.createCodeWithLocal(3 /*M-GET*/);

	Invoke invoke = new Invoke(invoke_id, invoke_opcode);
	fill_mget_argument(invoke);
	
	ROSEapdus pdu = ROSEapdus.createROSEapdusWithInvoke(invoke);
	return pdu;    
    }

    /* Construct MakeCallResult part of the reply */    
    static void fill_mget_argument(Invoke invoke)
    {
	String  oidstr = "1.3.6.1.2.1.4";
	
	ObjectIdentifier oid = null;
	try {
	    oid = new ObjectIdentifier(oidstr);
	} catch (BadObjectIdentifierException e) {
	    System.out.println("Bad Ibject identifier value: " + e.getMessage());
	}
	ObjectClass objcls = ObjectClass.createObjectClassWithGlobalForm(oid);
	
	/* population of rdname is not shown in this sample */
	RelativeDistinguishedName rdname = new 	RelativeDistinguishedName();
	DistinguishedName distname = new DistinguishedName();
	distname.add(rdname);
	/* baseManagedObjectInstance */
	ObjectInstance  objinst = 
	    ObjectInstance.createObjectInstanceWithDistinguishedName(distname);

	GetArgument.AttributeIdList atids = new GetArgument.AttributeIdList();
	fill_getarg_atids(atids);

	GetArgument getarg = new GetArgument(objcls, objinst);
	getarg.setAttributeIdList(atids);
	OpenType invarg = new OpenType(getarg);
	invoke.setArgument(invarg);
    }

    static void fill_getarg_atids(GetArgument.AttributeIdList atids)
    {
	AttributeId id = AttributeId.createAttributeIdWithLocalForm(4);
	atids.add(id);
	id = AttributeId.createAttributeIdWithLocalForm(5);
	atids.add(id);
    }
}
