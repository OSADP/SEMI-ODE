/*
 * Copyright (C) 2016 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Tpos.java	1.3 14/02/08 */
/*
 * This example demonstrates encoded value positions feature. Sample
 * "baseball card" record is encoded and then decoded by using
 * the decodeWithPositions() method so size/offset information
 * of PDU component encodings are available after decoding.
 *
 * To run the program say:
 *
 * asn1pjav basebal.asn
 * cd baseball
 * baseball.bat javac
 * cd ..
 * javac -g *.java
 * java Tpos
 */

import baseball.*;
import baseball.bcas.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Tpos {

    /**
     * Constructor.
     */
    public Tpos () {
    }

    public static void main(String args[]) {

	// Initialize the project
	try {
	    Baseball.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization exception: " + e);
	    System.exit(1);
	}

	// Create the value of BBCard using the constructor with arguments
	System.out.println("Creating 'myCard' value, using the constructor with arguments...");
	BBCard myCard = new BBCard (
	    new IA5String (
		"Casey"
	    ),
	    new IA5String (
		"Mudville Nine"
	    ),
	    32,
	    new IA5String (
		"left field"
	    ),
	    BBCard.Handedness.ambidextrous,
	    250.E-3);

	// Encode the myCard value using BER
	try {
	    Coder coder = Baseball.getBERCoder();
	    ByteArrayOutputStream sink = new ByteArrayOutputStream();

	    // Enable trace output from the encoder and decoder
	    coder.enableEncoderDebugging();
	    coder.enableDecoderDebugging();

	    // Print the input to the encoder
	    System.out.println("\nThe input to the encoder\n");
	    System.out.println(myCard);

	    // Encode a card
	    System.out.println("\nThe encoder's trace messages ...");
	    coder.encode(myCard, sink);

	    // Extract the encoding from the sink stream
	    byte[] encoding = sink.toByteArray();

	    // Print the encoding using the HexTool utility
	    System.out.println("Card encoded into " + encoding.length + " bytes.");
	    HexTool.printHex(encoding);

	    // enable relaxed decoding mode if needed
	    String relax = System.getProperty("oss.samples.relaxedmode");
	    if (relax != null && relax.equalsIgnoreCase("on")) {
		coder.enableRelaxedDecoding();
	    }

	    try {
		ByteArrayInputStream source = new ByteArrayInputStream(encoding);

		// Decode the card whose encoding is in the 'encoding' byte array.
		System.out.println("\nThe decoder's trace messages ...\n");
		AbstractDataWithPositions pos= coder.decodeWithPositions(source, new BBCard());
		AbstractDataPositions psns = pos.getPositions();
		System.out.println("Card decoded.");
		System.out.println("\nEncoded PDU size " + pos.getSize()/8 + " octets");
		System.out.println("Positions (offset/size in octets):");
		// Print out the player's batting average
		BBCard decodedCard = (BBCard)pos.getDecodedValue();
		printPosition("PDU", decodedCard, psns);
		printPosition("name", decodedCard.getName(), psns);
		printPosition("team", decodedCard.getTeam(), psns);
		printPosition("position", decodedCard.getPosition(), psns);
// ATTENTION! In general case the following line can report position not
// available due to multiple ENUMERATED component occurences.
		printPosition("handedness", decodedCard.getHandedness(), psns);
// Would not compile for components that are mapped to Java primitive types
//                printPosition("batting-avarage", decodedCard.getBatting_average(), psns);

		double batting_average = decodedCard.getBatting_average();
		String name = decodedCard.getName().stringValue();
		String team = decodedCard.getTeam().stringValue();
		System.out.println("\n" +
		    name + " of the " + team + " has a batting average of " +
		    batting_average);
		System.out.println("\nOutput from decoder ...");
		System.out.println(decodedCard);
	    } catch (DecodeFailedException e) {
		System.out.println("Decoder exception: " + e);
	    } catch (DecodeNotSupportedException e) {
		System.out.println("Decoder exception: " + e);
	    }
	} catch (EncodeFailedException e) {
	    System.out.println("Encoder exception: " + e);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoder exception: " + e);
	}

	// Do final cleanup
	Baseball.deinitialize();
    }

    static void printPosition(String name, AbstractData component,
	AbstractDataPositions pos)
    {
	Position p = pos.get(component);
	if (p != null) {
	    System.out.println("Component \"" + name + "\" offset " +
		p.getOffset()/8 + " size " + p.getSize()/8
		+ (p.isConstructed() ? " constructed " : " primitive "));
	} else {
	    System.out.println("Component \"" + name + "\" position not available");
	}
    }
}

