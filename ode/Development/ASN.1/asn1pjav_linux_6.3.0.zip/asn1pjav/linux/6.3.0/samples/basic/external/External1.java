/*************************************************************/
/* Copyright (C) 2016 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)External1.java	16.3 14/02/08 */
/* Prepared by OSS Nokalva, Inc.     */

/* Application Program: External1.java

   Illustrates one possible way to process the encoding that is nested
   in the value of the EXTERNAL ASN.1 type. The type of the value of the
   encoding in the 'encoding' component of the EXTERNAL is identified by the
   OBJECT IDENTIFIER in the 'direct-reference' field.
   
   This sample decodes the value of EXTERNAL in two steps. First, the 
   equivalent ASN.1 SEQUENCE that represents the EXTERNAL is decoded. Second,
   the application uses the value of the 'direct-reference' component to
   determine the type of the value in the 'encoding'. Then it completes
   the decoding of the outermost value by decoding the 'encoding'
   component.
   
   In this example the knowledge of the mapping of the value of 
   'direct-reference' to the type in the 'encoding' is built-in into the
   application code.

   To run the sample perform the following steps:

    asn1pjav dialogue.asn -ber -nounique
    cd dialogue
    dialogue.bat javac
    javac -g ../External1.java
    java External1
*/

/* Compiler generated classes */
import dialogue.*;
import dialogue.dialoguepdus.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;

/* Java I/O classes */
import java.io.*;

public class External1 {
    public static void main(String[] args)
    {
	try {
	    Dialogue.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization failed: " + e);
	    System.exit(1);
	}

	// Open the file that contains the input encoding
	String dataFile = "myDialogue.ber";
	FileInputStream encodedData = null;

	try {
	    encodedData = new FileInputStream(dataFile);
	} catch (IOException e) {
	    System.out.println("Cannot open " + dataFile + " for reading: " + e);
	    System.exit(2);
	}

	// Create the BER coder and set it to emit the diagnostic output
	Coder coder = Dialogue.getBERCoder();
	coder.enableDecoderDebugging();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    coder.enableRelaxedDecoding();
	}

	try {
	    // Decode the equivalent SEQUENCE that repreents the EXTERNAL
	    MyDialogue myDialogue = 
		(MyDialogue)coder.decode(encodedData, new MyDialogue()); 
	    if (myDialogue.hasDirect_reference() && !myDialogue.hasIndirect_reference()) {
		// The direct-reference OPTIONAL component is present
		System.out.println();
		System.out.println("The 'direct-reference' optional field is present");
		if (myDialogue.getDirect_reference().equals(DialoguePDUs.dialogue_as_id)) {
		    // The value of the "direct-reference" indicates that the "encoding"
		    // contains the DialoguePDU
		    System.out.println("And its value is equal to 'dialogue_as_id'.");
		    System.out.println("Hence the 'encoding:single-ASN1-type' carries the value of the DialoguePDU");
		    System.out.println();
		    External.Encoding encoding = myDialogue.getEncoding();
		    if (encoding.hasSingle_ASN1_type()) {
			// Decode it as DialoguePDU
			OpenType ot = (OpenType)encoding.getChosenValue();
			AbstractData dialoguePDU =
			    coder.decode(ot.getEncodedValueAsStream(), new DialoguePDU());
			ot.setDecodedValue(dialoguePDU);
		    }
		}
	    }
	    // Print the decoded value
	    System.out.println();
	    System.out.println("The value decoded:");
	    System.out.println(myDialogue);
	} catch (Exception e) {
	    System.out.println("Decoding has failed: " + e);
	}

	try {
	    encodedData.close();
	} catch (IOException e) {
	    System.out.println("Error when closing the input file: " + e);
	}

	Dialogue.deinitialize();
    }
}
