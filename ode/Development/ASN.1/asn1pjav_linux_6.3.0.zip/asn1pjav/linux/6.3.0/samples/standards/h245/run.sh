#!/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE: @(#)run.sh	16.10	14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

OPTION=$1

if [ "$OPTION" = "-c" ]; then
    echo "-c   client mode: initiate Terminal Capability Set exchange"
elif [ "$OPTION" = "-s" ]; then
    echo "-s   server mode: listen for client connections"
    echo "Run this program with '-c' option from a separate terminal"
fi

ACTION=${1:-"all"}

. ../../common.sh


case ${ACTION} in
    "cleanup")
	rm -fr h245v10
	rm -f *.log
	rm -f *.class
	break;;
	
    "-c"|"-s"|"all")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the abstract syntax and run the tests

	echo "----- ASN.1-compiling the syntax -----"
	$ASN1 $COMMON_ASN1_OPTIONS -commandfile h245.cmd -err compile.log
	if [ $? -eq 0 ]; then 
	    cd h245v10
	    echo "----- Compiling generated classes -----"
	    sh h245v10.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g H245.java 2>&1 >> compile.log
	    if [ -f H245.class ]; then
		if test "$ACTION" = "all"; then                
		    echo "----- Running the H245 test with -s option -----" > run_s.log
            	    echo "" >> run_s.log
		    $JAVA $COMMON_JAVA_OPTIONS H245 -s >> run_s.log & sleep 1; 
		    echo "----- Running the H245 test with -c option -----" > run_c.log
            	    echo "" >> run_c.log
		    $JAVA $COMMON_JAVA_OPTIONS H245 -c >> run_c.log;
		    cat run_s.log
		    cat run_c.log
		else 
		    echo "----- Running the H245 test with $1 option -----";
            	    echo ""
		    $JAVA $COMMON_JAVA_OPTIONS H245 $1;
		fi
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	echo "Usage: run.sh [ -s | -c ]"  1>&2
	echo ""
	;;
    
esac
