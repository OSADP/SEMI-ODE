/*************************************************************/
/* Copyright (C) 2016 OSS Nokalva.  All rights reserved.     */
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS Nokalva, INC. AND
 * MAY BE USED ONLY BY DIRECT LICENSEES OF OSS Nokalva, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* FILE: @(#)Tbook.java	17.1 15/11/13 */
/* Prepared by OSS Nokalva, Inc.  */

/* Application Program: Tbook.java

   Encodes a sample book using the BOOK Abstract Syntax. Illustrates usage
   of Java compression classes.

    To run the sample perform the following steps:

    asn1pjav sample.asn -ber -per -xer
    cd sample
    sample.bat javac
    cd ..
    javac -g Tbook.java
    java Tbook
*/

/*
 */
 
/* Compiler-generated classes */
import sample.*;
import sample.bookmodule.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.util.HexTool;

/* Java I/O classes */
import java.io.*;
import java.util.zip.*;

public class Tbook {

    public static void main(String[] args)
    {
	try {
	    Sample.initialize();
	} catch (Exception e) {
	    System.out.println("Initialization error: " + e);
	    System.exit(1);
	}
	Coder ber = Sample.getBERCoder();
	Coder per = Sample.getPERAlignedCoder();
	Coder xer = Sample.getXERCoder();

	// enable relaxed decoding mode if needed
	String relax = System.getProperty("oss.samples.relaxedmode");
	if (relax != null && relax.equalsIgnoreCase("on")) {
	    ber.enableRelaxedDecoding();
	    per.enableRelaxedDecoding();
	    xer.enableRelaxedDecoding();
	}

	/*
	 * Fill in the book structure.
	 */
	Book book = new Book();

	book.setTitle(new IA5String(
	    "ASN.1 Communication between Heterogeneous Systems"
	    )
	);
	book.setAuthor(new IA5String("Olivier Dubuisson"));
	book.setIsbn(1263361);
	book.setPrice(49);

	ChapterInfo ch1 = null;
	ChapterInfo ch2 = null;

	/*
	 * An optional parameter includes the path to all the files that are used by
	 * the program.
	 */
	String path = (args.length > 0) ? args[0] : null;

	/*
	 * Read the first chapter.
	 */
	try {
	    ch1 = readChapter(path, 1);
	} catch (Exception e) {
	    System.out.println("Exception while reading Chapter 1: " + e);
	    System.exit(1);
	}

	/*
	 * Read the second chapter.
	 */
	try {
	    ch2 = readChapter(path, 2);
	} catch (Exception e) {
	    System.out.println("Exception while reading Chapter 2: " + e);
	    System.exit(1);
	}

	Book.Chapters chapters = new Book.Chapters();
	chapters.add(ch1);
	chapters.add(ch2);
	book.setChapters(chapters);

	/*
	 * Print the input to the encoder.
	 */
	System.out.println("The input to the encoder...\n");
	System.out.println(book);

	int length = 0;   /* length of normal encoding */
	int length2 = 0;  /* length of compressed encoding */

	System.out.println("\n============= BER ==============");
	System.out.println("Encoding/Decoding normally...");
	try {
	    length = encodeAndDecode(book, ber, false);
	} catch (Exception e) {
	    System.out.println("Exception in BER test: " + e);
	    System.exit(2);
	}

	System.out.println("\nEncoding/decoding with compression...");
	try {
	    length2 = encodeAndDecode(book, ber, true);
	} catch (Exception e) {
	    System.out.println("Exception in BER test: " + e);
	    System.exit(2);
	}

	System.out.println("Compression ratio: " + 100 * length2 / length + "%");

	System.out.println("\n============= PER ==============");
	System.out.println("Encoding/Decoding normally...");
	try {
	    length = encodeAndDecode(book, per, false);
	} catch (Exception e) {
	    System.out.println("Exception in PER test: " + e);
	    System.exit(2);
	}

	System.out.println("\nEncoding/decoding with compression...");
	try {
	    length2 = encodeAndDecode(book, per, true);
	} catch (Exception e) {
	    System.out.println("Exception in PER test: " + e);
	    System.exit(2);
	}

	System.out.println("Compression ratio: " + 100 * length2 / length + "%");

	System.out.println("\n============= XER ==============");
	System.out.println("Encoding/Decoding normally...");
	try {
	    length = encodeAndDecode(book, xer, false);
	} catch (Exception e) {
	    System.out.println("Exception in XER test: " + e);
	    System.exit(2);
	}

	System.out.println("\nEncoding/decoding with compression...");
	try {
	    length2 = encodeAndDecode(book, xer, true);
	} catch (Exception e) {
	    System.out.println("Exception in XER test: " + e);
	    System.exit(2);
	}

	System.out.println("Compression ratio: " + 100 * length2 / length + "%");

	Sample.deinitialize();
    }

    /* read a chapter content from a file */
    private static ChapterInfo readChapter(String path, int num)
	throws IOException
    {
	File file = new File(path, "chapt" + num + ".txt");

	if (!file.exists()) {
	    throw new IOException("Failed to open the " + file.toString() + " file. " +
		"Restart the sample program using as input parameter the name of the directory " +
		"where the '" + file.getName() + "' file is located.\n");
	}

	byte buf[] = new byte[(int)file.length()];
	int  bufpos = 0;
	int c;

	FileInputStream in = new FileInputStream(file);

	while ((c = in.read()) != -1)
	    buf[bufpos++] = (byte)c;

	in.close();

	String chapter = new String(buf);

	return new ChapterInfo(num, new IA5String(chapter));
    }

    private static int encodeAndDecode(AbstractData pdu, Coder coder,
	boolean compress)
	throws EncodeNotSupportedException, EncodeFailedException,
	       DecodeNotSupportedException, DecodeFailedException,
	       IOException
    {
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	OutputStream sink = baos;
	int result = 0;
	byte[] encoding;

	if (compress)
	    sink = new GZIPOutputStream(baos);

	coder.encode(pdu, sink);

	if (compress)
	    ((GZIPOutputStream)sink).finish();

	encoding = baos.toByteArray();
	result = encoding.length;
	System.out.println("The book encoded in " + encoding.length +
	    " bytes.");

	ByteArrayInputStream bais = new ByteArrayInputStream(encoding);
	InputStream source = bais;

	if (compress)
	    source = new GZIPInputStream(bais);

	AbstractData decoded = coder.decode(source, pdu);

	System.out.println("Book decoded successfully.\n");
	    /*
	     * Compare the decoder's output with the original book.
	     */
	System.out.println("Compare the decoded book with the original one...");
	if (!decoded.equals(pdu))
	    System.out.println("Comparison failed.");
	else
	    System.out.println("Comparison succeeded.");

	return result;
    }

}
