#!/usr/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	16.2 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -rf signed
	rm -f *.class
	rm -f *.log
	rm -f *.der
	break;;
	
    "javac")

	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the signed abstract syntax and run the ExeSigner test

	echo "----- Compiling the signed specification -----"
	$ASN1 $COMMON_ASN1_OPTIONS signed -der -err compile.log
	if [ $? -eq 0 ]; then
	    cd signed
	    echo "----- Compiling generated classes -----"
	    sh signed.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g ExeSigner.java 2>&1 >> compile.log
	    if [ -f ExeSigner.class ]; then
		echo "----- Running the ExeSigner to send ExeSigner.class file -----";
		$JAVA $COMMON_JAVA_OPTIONS ExeSigner -v send ExeSigner.class john jabberwock;
		echo "----- Running the ExeSigner to verify signed ExeSigner.class.der file -----";
		$JAVA $COMMON_JAVA_OPTIONS ExeSigner -v receive ExeSigner.class.der;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac

