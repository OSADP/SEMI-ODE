/*
 * Copyright (C) 2016 OSS Nokalva Inc.  All rights reserved.
 */

/*
 * THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND MAY BE USED
 * ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC. THIS FILE MAY NOT BE
 * DISTRIBUTED. THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */

/* FILE: @(#)Tthreads.java	16.3 14/02/08 */
/*
 * This example illustrates multi-threading capability of the OSS Java
 * runtime on the baseball example. It creates a separate thread for each
 * coder for the "myCard" PDU object and executes threads in parallel. The
 * output from each thread is captured in an internal buffer and is printed
 * after all threads are no longer alive to provide a readable output.  Each
 * thread performs the following:
 *
 *   - prints value notation for "myCard";
 *   - checks whether or not "myCard" satisfies constraints applied to its type;
 *   - encodes "myCard";
 *   - decodes the resulted encoded value;
 *   - prints value notation for the decoded value.
 *
 * Note that currently there is no way to re-direct tracing from encoders/decoders
 * to another output stream.  So the debugging capability is disabled in this
 * test program.
 *
 * To run the program say:
 *
 * asn1pjav baseball.asn
 * cd baseball
 * baseball.bat javac
 * cd ..
 * javac -g *.java
 * java Tthreads
 */


/* Compiler-generated classes */
import baseball.*;
import baseball.bcas.*;

/* Universal classes from the OSS runtime library */
import com.oss.asn1.*;
import com.oss.metadata.*;
import com.oss.util.*;

/* Java I/O classes */
import java.io.*;

public class Tthreads extends Baseball {

    public static void main(String[] args)
    {
	try {
	    setup();
	    testBBCard();
	    baseball.Baseball.deinitialize();
	}
	catch(Exception e) {
	    System.out.println("Initialization failed.");
	    return;
	}
    }

	//
	// Initialize the environment and coders.
	//
    public static void setup()
    {
	try {
	    baseball.Baseball.initialize();
	    initCoders();
	}
	catch(Exception e) {
	    System.out.println("Initialization failed.");
	    return;
	}
    }

	//
	// Array of coders to test.
	//
    private static Coder[] cCoders = new Coder[5];
	//
	// Integral variable that keeps the number of failed threads.
	//
    private static int mFailureCount = 0;

	//
	// Initialize the array of coders for all encoding rules including two
	// BER coders to be used with definite and indefinite length encodings.
	//
    private static void initCoders()
    {
	int index = 0;
	
	cCoders[index] = getBERCoder();
	cCoders[index++].useDefiniteLengthEncoding();
	cCoders[index] = getBERCoder();
	cCoders[index++].useIndefiniteLengthEncoding();
	cCoders[index++] = getDERCoder();
	cCoders[index++] = getPERAlignedCoder();
	cCoders[index] = getPERUnalignedCoder();
	String relax = System.getProperty("oss.samples.relaxedmode");
	for (int i = 0; i < cCoders.length; i++) {
	    cCoders[i].enableEncoderConstraints();
	    cCoders[i].enableDecoderConstraints();
	    // enable relaxed decoding mode if needed
	    if (relax != null && relax.equalsIgnoreCase("on")) {
		cCoders[i].enableRelaxedDecoding();
	    }

	}
    }

	//
	// Creates and starts coder threads.
	//
    private static void testBBCard()
    {
	AbstractData pdu = baseball.bcas.BCAS.myCard;
	int i, num_threads = cCoders.length;
	CoderThread[] threads = new CoderThread[num_threads];

		//
		// Create a thread for each coder.
		//
	for (i = 0; i < num_threads; i++)
	    threads[i] = new CoderThread(cCoders[i], pdu);
		//
		// Initialize and execute all threads.
		//
	System.out.println("Starting " + num_threads + " threads...");	
	for (i = 0; i < num_threads; i++)
	    try {     
		threads[i].start();
	    }
	    catch (Exception e) {
		System.out.println("Creating " + threads[i].getCoderName() +
						 " coder thread failed.");
		System.out.println(e.getMessage());
	    }
		//
		// Wait until all threads are no longer alive.
		//
	for (i = 0; i < num_threads; i++)
	    try {
		threads[i].join();
	    }
	    catch (InterruptedException e) {
	    }
	System.out.println("All the threads run to completion.");
		//
		// Print the output from all threads accumulated in the
		// internal buffers.
		//
	for (i = 0; i < num_threads; i++) {
	    threads[i].printOutput();
	    if (threads[i].failed)
		mFailureCount++;
	}

	if (mFailureCount > 0)
	    System.out.println(mFailureCount + " values failed.");
	else
	    System.out.println("\nAll values encoded and decoded successfully.");
    }

	//
	// The CoderThread class implements a coder thread that performs
	// testing encoding/decoding routines for a specific coder/PDU
	// combination.  The output from a thread is captured in an internal
	// buffer.  Its contents is printed after all threads are completed.
	//
    static class CoderThread extends Thread {
		//
		// Coder to test.
		//
	private Coder coder = null;
		//
		// AbstractData object, myCard, to be used in encoding and
		// decoding.
		//
	AbstractData value = null;
		//
		// Primitive used to check return values. It is set to 'true'
		// if encoding, decoding, or constraint checking failed.
		//
	boolean failed = false;
		//
		// Character output stream used as internal buffer.
		//
	private StringWriter messageBuffer = null;
		//
		// The stream where the output for this thread is redirected to.
		//
	private PrintWriter testOutput = null;

		//
		// Construct a coder thread object.
		//
	CoderThread(Coder coder, AbstractData value) 
        {
	    this.coder = coder;
	    this.value = value;
		//
		// Create an internal buffer and an output stream where all
		// output of a given thread will be written to.
		//
	    messageBuffer = new StringWriter();
	    testOutput = new PrintWriter(messageBuffer);
	}

		//
		// Main entry point for the thread.
		//
	public void run()
	{
	    failed = encodeDecodeAndPrint(coder, value);
	}

		//
		// Test encoding and decoding of an input AbstractData object,
		// check it on constraints.
		//
	protected boolean encodeDecodeAndPrint(Coder coder, AbstractData pdu)
	{
	    boolean err = false;

	    try {
		String coder_name = getCoderName();
		byte[] encoding = null;

		testOutput.print("\n\tTesting " + coder_name + " coder thread...\n");
			//
			// Print the original PDU object.
			//
		testOutput.print("\n\tUnencoded PDU...\n\n");
		testOutput.print(pdu);

			//
			// Check constraints.
			//
		try {
		    if (pdu.isValid())
			testOutput.print("\nConstraints checking succeeded.\n");
		} catch (ValidateFailedException e) {
			testOutput.print("\nConstraints checking failed." + e + "\n");
			err = true;
		} catch (ValidateNotSupportedException e) {
			testOutput.print("\nConstraints checking failed." + e + "\n");
			err = true;
		}
			//
			// Encode the PDU.
			//
		try {
		    encoding = encodeDecodedValue(pdu, coder);
		    testOutput.print("\n\tEncoded PDU...\n\n");
		    testOutput.print(HexTool.getHex(encoding));
		}
		catch (EncodeFailedException e) {
		    testOutput.println("\nEncoding failed with return code = " + e.getReason());
		    testOutput.print(e);
		    return true;
		}
		if (err)
		    return err;
			//
			// Decode the PDU that was just encoded.
			//
		AbstractData decoded = null;
		try {
		    decoded = decodeEncodedValue(pdu.getClass(), encoding, coder);
		    testOutput.print("\n\n\tDecoded PDU...\n\n");
		    testOutput.print(decoded);
		}
		catch (DecodeFailedException e) {
		    testOutput.println("\nDecoding failed with return code = " + e.getReason());
		    testOutput.print(e);
		    return true;
		}
	    }
	    catch (Exception e) {
		e.printStackTrace(testOutput);
		err = true;
	    }
	    return err;
	}

		//
		// Encode a PDU into a byte[].
		//
	private byte[] encodeDecodedValue(AbstractData pdu, Coder coder)
		throws EncodeNotSupportedException, EncodeFailedException
	{
	    ByteArrayOutputStream encoding = new ByteArrayOutputStream();
	    coder.encode(pdu, encoding);
	    return encoding.toByteArray();
	}

		//
		// Decode an encoded value into an AbstractData object.
		//
	private AbstractData decodeEncodedValue(Class clazz,
	    byte[] encoding, Coder coder) throws InstantiationException,
		IllegalAccessException,DecodeNotSupportedException, 
		DecodeFailedException
	{
	    AbstractData pdu = (AbstractData)clazz.newInstance();
	    ByteArrayInputStream in = new ByteArrayInputStream(encoding);
	    return coder.decode(in, pdu);
	}

		//
		// Print the output accumulated in the internal buffer.
		//
	void printOutput()
	{
	    testOutput.flush();
	    messageBuffer.flush();
		//
		// Get the contents of the internal buffer as a String.
		//
	    String out = messageBuffer.toString();
	    if (out.length() > 0)
		System.out.print(out);
        }

		//
		// Return the name of the coder associated with the
		// current thread.
		//
	String getCoderName()
	{
	    if (coder instanceof BERCoder) {
		if (coder.usingDefiniteLengthEncoding())
		    return "BER DEFINITE-length";
		else
		    return "BER INDEFINITE-length";
	    }
	    else if (coder instanceof DERCoder)
		return "DER";
	    else if (coder instanceof PERAlignedCoder) 
		return "PER ALIGNED";
	    else if (coder instanceof PERUnalignedCoder)
		return "PER UNALIGNED";
	    else
		return "Unknown";
	}
    }
}
