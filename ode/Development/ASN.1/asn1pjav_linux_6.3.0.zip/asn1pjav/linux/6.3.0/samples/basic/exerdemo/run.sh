#!/bin/sh
#***************************************************************************
# Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.
#***************************************************************************
# THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
# AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
# THIS FILE MAY NOT BE DISTRIBUTED.
# THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
#***************************************************************************
# FILE     @(#)run.sh	16.2 14/02/08
#***************************************************************************

# Please use this  script to run the samples. Make sure
# that you properly set up the OSS_ASN1_JAVA, CLASSPATH and 
# PATH environment variables before running this script

ACTION=${1:-"javac"}

. ../../common.sh

case ${ACTION} in
    "cleanup")
	rm -rf ebaseball
	rm -f *.class
	rm -f *.log
	break;;
	
    "javac")
	CLASSPATH=`pwd`:$CLASSPATH; export CLASSPATH

	# Compile the BCAS abstract syntax and run the XERDemo

	echo "----- Compiling the ebaseball specification -----"
	$ASN1 $COMMON_ASN1_OPTIONS -test -exer ebaseball -err compile.log
	if [ $? -eq 0 ]; then
	    cd ebaseball
	    echo "----- Compiling generated classes -----"
	    sh ebaseball.sh "$JAVAC $JFLAGS" 2>&1 >> ../compile.log
	    cd ..
	    $JAVAC $JFLAGS -g EXERDemo.java 2>&1 >> compile.log
	    if [ -f EXERDemo.class ]; then
		echo "----- Running the EXERDemo sample -----";
		$JAVA $COMMON_JAVA_OPTIONS EXERDemo;
	    fi
	fi
	break;;

    *)
	echo "Invalid argument \"$1\"."
	break;;
    
esac



