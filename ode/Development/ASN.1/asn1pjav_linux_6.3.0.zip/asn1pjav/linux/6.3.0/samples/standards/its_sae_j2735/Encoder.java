
/*****************************************************************************/
/* Copyright (C) 2016 OSS Nokalva, Inc.  All rights reserved.     	     */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.                    */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*
 * FILE: @(#)Encoder.java	16.2 14/02/08
 */

/*
 * Demonstrates DSRC BasicSafetyMessage PDU encoding.
 */
import com.oss.asn1.AbstractData;
import com.oss.asn1.Coder;
import com.oss.asn1.EncodeFailedException;
import com.oss.asn1.EncodeNotSupportedException;
import com.oss.asn1.OctetString;
import com.oss.util.HexTool;
import j2735.J2735;
import j2735.dsrc.BSMblob;
import j2735.dsrc.BasicSafetyMessage;
import j2735.dsrc.BrakeSystemStatus;
import j2735.dsrc.Count;
import j2735.dsrc.DDateTime;
import j2735.dsrc.DDay;
import j2735.dsrc.DHour;
import j2735.dsrc.DMinute;
import j2735.dsrc.DMonth;
import j2735.dsrc.DSRCmsgID;
import j2735.dsrc.DSecond;
import j2735.dsrc.DYear;
import j2735.dsrc.DescriptiveName;
import j2735.dsrc.Elevation;
import j2735.dsrc.EventFlags;
import j2735.dsrc.ExteriorLights;
import j2735.dsrc.FullPositionVector;
import j2735.dsrc.Heading;
import j2735.dsrc.Latitude;
import j2735.dsrc.Longitude;
import j2735.dsrc.PathHistory;
import j2735.dsrc.PathPrediction;
import j2735.dsrc.PositionConfidenceSet;
import j2735.dsrc.PositionalAccuracy;
import j2735.dsrc.RTCMHeader;
import j2735.dsrc.RTCMPackage;
import j2735.dsrc.SpeedandHeadingandThrottleConfidence;
import j2735.dsrc.TemporaryID;
import j2735.dsrc.TimeConfidence;
import j2735.dsrc.TransmissionAndSpeed;
import j2735.dsrc.VINstring;
import j2735.dsrc.VehicleIdent;
import j2735.dsrc.VehicleSafetyExtension;
import j2735.dsrc.VehicleStatus;
import j2735.dsrc.VehicleStatus.Wipers;
import j2735.dsrc.VehicleType;
import j2735.dsrc.WiperRate;
import j2735.dsrc.WiperStatusFront;
import java.io.ByteArrayOutputStream;

public class Encoder {
    
    public static void main(String[] args)
    {
        // Initialize the project
        try {
            J2735.initialize();
        } catch (Exception e) {
            System.out.println("Initialization exception: " + e);
            System.exit(1);
        }
        
        Coder coder = J2735.getBERCoder();
        
        coder.enableEncoderDebugging();
        
        // Construct a sample PDU for encoding
        
        AbstractData msg = fill_BasicSafetyMessage_PDU();
        
	System.out.println("\nPDU for encoding...\n");
	System.out.println(msg);
	System.out.println("\nEncoding...");
	/*
	 * Set the output stream.
	 */
	ByteArrayOutputStream sink = new ByteArrayOutputStream();
	/*
	 * Encode the PDU.
	 */
	try {
	    coder.encode(msg, sink);
	} catch (EncodeNotSupportedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	} catch (EncodeFailedException e) {
	    System.out.println("Encoding failed: " + e);
	    System.exit(2);
	}
	System.out.println("Encoded successfully.");
	/*
	 * Print the encoded PDU.
	 */
	System.out.println("\nEncoded PDU...\n");
	byte[] encoding = sink.toByteArray();
	HexTool.printHex(encoding);

    }

    // Creates the sample BasicSafetyMessage PDU
    private static AbstractData fill_BasicSafetyMessage_PDU() 
    {
         BasicSafetyMessage msg = new BasicSafetyMessage();
         
         msg.setMsgID(DSRCmsgID.basicSafetyMessage);
         
         BSMblob blob = createBSMblob();
         msg.setBlob1(blob);

         VehicleSafetyExtension ext = createVehicleSafetyExtension();
         msg.setSafetyExt(ext);
         
         VehicleStatus status = createStatus();
         msg.setStatus(status);
         
         return msg;
    }

    // Fill sample BSM blob data
    private static BSMblob createBSMblob() 
    {
        final byte[] blob = {
            (byte)0x01, (byte)0xC0, (byte)0xA8, (byte)0x01, (byte)0x15,
            (byte)0x4A, (byte)0x38, (byte)0x18, (byte)0xBC, (byte)0x4D,
            (byte)0x4F, (byte)0x21, (byte)0xCB, (byte)0x39, (byte)0xED,
            (byte)0xC1, (byte)0x5B, (byte)0x00, (byte)0x00, (byte)0x00,
            (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x2C, (byte)0x8D,
            (byte)0xB6, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
            (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
            (byte)0x20, (byte)0x89, (byte)0x39
        };
        
        return new BSMblob(blob);
    }

    // Creates sample VehicleSafetyExtension value
    private static VehicleSafetyExtension createVehicleSafetyExtension() 
    {
        VehicleSafetyExtension ext = new VehicleSafetyExtension();
        
        EventFlags flags = new EventFlags(0);
        ext.setEvents(flags);
        
        PathHistory pathHistory = createPathHistory();
        ext.setPathHistory(pathHistory);
        
        PathPrediction pathPrediction = new PathPrediction(0, 0);
        ext.setPathPrediction(pathPrediction);
        
        final byte[] rtcmHeader = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00 };        
        RTCMPackage theRTCM = new RTCMPackage(new RTCMHeader(rtcmHeader));        
        ext.setTheRTCM(theRTCM);
        return ext;
    }

    // Creates sample VehicleStatus value
    private static VehicleStatus createStatus() 
    {
        VehicleStatus status = new VehicleStatus();
        
        ExteriorLights lights = new ExteriorLights(0);        
        status.setLights(lights);
        
        Wipers wipers = new Wipers(WiperStatusFront.off, new WiperRate(0));        
        status.setWipers(wipers);
        
        final byte[] brakes = new byte[] { 0x00, 0x00 };
        BrakeSystemStatus brakeStatus = new BrakeSystemStatus(brakes);        
        status.setBrakeStatus(brakeStatus);
        
        FullPositionVector fullPos = createFullPosition();
        status.setFullPos(fullPos);
        
        VehicleIdent vid = createVehicleIdent();
        status.setVehicleIdent(vid);
        return status;
    }

    // Creates sample PathHistory value
    private static PathHistory createPathHistory() 
    {
        PathHistory pathHistory = new PathHistory();
        
        FullPositionVector initial = createInitial();        
        pathHistory.setInitialPosition(initial);
        
        byte[] crumbData = new byte[] {
            (byte)0x00, (byte)0x01, (byte)0x02, (byte)0x03, (byte)0x04, 
            (byte)0x05, (byte)0x06, (byte)0x07, (byte)0x08, (byte)0x09,
            (byte)0x0A, (byte)0x0B, (byte)0x0C, (byte)0x0D, (byte)0x0E, 
            (byte)0x0F, (byte)0x10, (byte)0x11, (byte)0x12, (byte)0x13,
            (byte)0x14, (byte)0x15, (byte)0x16, (byte)0x17, (byte)0x18, 
            (byte)0x19, (byte)0x1A, (byte)0x1B, (byte)0x1C, (byte)0x1D,
            (byte)0x1E, (byte)0x1F, (byte)0x20, (byte)0x21, (byte)0x22, 
            (byte)0x23, (byte)0x24, (byte)0x25, (byte)0x26, (byte)0x27,
            (byte)0x28, (byte)0x29, (byte)0x2A, (byte)0x2B, (byte)0x2C, 
            (byte)0x2D, (byte)0x2E, (byte)0x2F, (byte)0x30, (byte)0x31,
            (byte)0x32, (byte)0x33, (byte)0x34, (byte)0x35, (byte)0x36, 
            (byte)0x37, (byte)0x38, (byte)0x39, (byte)0x3A, (byte)0x3B,
            (byte)0x3C, (byte)0x3D, (byte)0x3E, (byte)0x3F, (byte)0x40, 
            (byte)0x41, (byte)0x42, (byte)0x43, (byte)0x44, (byte)0x45,
            (byte)0x46, (byte)0x47, (byte)0x48, (byte)0x49, (byte)0x4A, 
            (byte)0x4B, (byte)0x4C, (byte)0x4D, (byte)0x4E, (byte)0x4F,
            (byte)0x50, (byte)0x51, (byte)0x52, (byte)0x53, (byte)0x54, 
            (byte)0x55, (byte)0x56, (byte)0x57, (byte)0x58, (byte)0x59,
            (byte)0x5A, (byte)0x5B, (byte)0x5C, (byte)0x5D, (byte)0x5E, 
            (byte)0x5F, (byte)0x60, (byte)0x61, (byte)0x62, (byte)0x63,
            (byte)0x64, (byte)0x65, (byte)0x66, (byte)0x67, (byte)0x68, 
            (byte)0x69, (byte)0x6A, (byte)0x6B, (byte)0x6C, (byte)0x6D,
            (byte)0x6E, (byte)0x6F, (byte)0x70, (byte)0x71, (byte)0x72, 
            (byte)0x73, (byte)0x74, (byte)0x75, (byte)0x76, (byte)0x77,
            (byte)0x78, (byte)0x79, (byte)0x7A, (byte)0x7B, (byte)0x7C, 
            (byte)0x7D, (byte)0x7E, (byte)0x7F, (byte)0x80, (byte)0x81,
            (byte)0x82, (byte)0x83, (byte)0x84, (byte)0x85, (byte)0x86, 
            (byte)0x87, (byte)0x88, (byte)0x89, (byte)0x8A, (byte)0x8B,
            (byte)0x8C, (byte)0x8D, (byte)0x8E, (byte)0x8F, (byte)0x90, 
            (byte)0x91, (byte)0x92, (byte)0x93, (byte)0x94, (byte)0x95,
            (byte)0x96, (byte)0x97, (byte)0x98, (byte)0x99, (byte)0x9A, 
            (byte)0x9B, (byte)0x9C, (byte)0x9D, (byte)0x9E, (byte)0x9F,
            (byte)0xA0, (byte)0xA1, (byte)0xA2, (byte)0xA3, (byte)0xA4, 
            (byte)0xA5, (byte)0xA6, (byte)0xA7, (byte)0xA8, (byte)0xA9,
            (byte)0xAA, (byte)0xAB, (byte)0xAC, (byte)0xAD, (byte)0xAE, 
            (byte)0xAF, (byte)0xB0, (byte)0xB1, (byte)0xB2, (byte)0xB3,
            (byte)0xB4, (byte)0xB5, (byte)0xB6, (byte)0xB7, (byte)0xB8, 
            (byte)0xB9, (byte)0xBA, (byte)0xBB, (byte)0xBC, (byte)0xBD,
            (byte)0xBE, (byte)0xBF, (byte)0xC0, (byte)0xC1, (byte)0xC2, 
            (byte)0xC3, (byte)0xC4, (byte)0xC5, (byte)0xC6, (byte)0xC7,
            (byte)0xC8, (byte)0xC9, (byte)0xCA, (byte)0xCB, (byte)0xCC, 
            (byte)0xCD, (byte)0xCE, (byte)0xCF, (byte)0xD0, (byte)0xD1,
            (byte)0xD2, (byte)0xD3, (byte)0xD4, (byte)0xD5, (byte)0xD6, 
            (byte)0xD7, (byte)0xD8, (byte)0xD9, (byte)0xDA, (byte)0xDB,
            (byte)0xDC, (byte)0xDD, (byte)0xDE, (byte)0xDF, (byte)0xE0, 
            (byte)0xE1, (byte)0xE2, (byte)0xE3, (byte)0xE4, (byte)0xE5,
            (byte)0xE6, (byte)0xE7, (byte)0xE8, (byte)0xE9, (byte)0xEA, 
            (byte)0xEB, (byte)0xEC, (byte)0xED, (byte)0xEE, (byte)0xEF,
            (byte)0xF0, (byte)0xF1, (byte)0xF2, (byte)0xF3, (byte)0xF4, 
            (byte)0xF5, (byte)0xF6, (byte)0xF7, (byte)0xF8, (byte)0xF9,
            (byte)0xFA, (byte)0xFB, (byte)0xFC, (byte)0xFD, (byte)0xFE, 
            (byte)0xFF, (byte)0x00, (byte)0x01, (byte)0x02, (byte)0x03,
            (byte)0x04, (byte)0x05, (byte)0x06, (byte)0x07, (byte)0x08, 
            (byte)0x09, (byte)0x0A, (byte)0x0B, (byte)0x0C, (byte)0x0D,
            (byte)0x0E, (byte)0x0F, (byte)0x10, (byte)0x11, (byte)0x12, 
            (byte)0x13
        };
        pathHistory.setItemCnt(new Count(23));
        pathHistory.setCrumbData(
            PathHistory.CrumbData.createCrumbDataWithPathHistoryPointSets_03(
                new OctetString(crumbData)));
        
        return pathHistory;
    }

    // Creates sample FullPositionVector value
    private static FullPositionVector createFullPosition() {
        FullPositionVector initial = new FullPositionVector();
        
        initial.setUtcTime(new DDateTime(
            new DYear(2010), 
            new DMonth(1), 
            new DDay(16), 
            new DHour(21), 
            new DMinute(6), 
            new DSecond(31000)));
        
        initial.set_long(new Longitude(-745213180L));
        
        initial.setLat(new Latitude(405407860L));
        
        final byte[] elevation = new byte[] {0x02, 0x00};
        initial.setElevation(new Elevation(elevation));
        
        initial.setHeading(new Heading(24901));
        
        byte[] tsAndSpeed = new byte[] {0x00, 0x00};
        initial.setSpeed(new TransmissionAndSpeed(tsAndSpeed));

        byte[] posAccuracy = new byte[] {(byte)0x04, (byte)0x02, 
            (byte)0xFF, (byte)0xFF};        
        initial.setPosAccuracy(new PositionalAccuracy(posAccuracy));
        
        initial.setTimeConfidence(TimeConfidence.unavailable);
        
        byte[] posConfidence = new byte[] {0x00};
        initial.setPosConfidence(new PositionConfidenceSet(posConfidence));
        
        byte[] speedConfidence = new byte[] {0x00};;
        initial.setSpeedConfidence(
                new SpeedandHeadingandThrottleConfidence(speedConfidence));

        return initial;
    }

    // Creates sample VehicleIdent value
    private static VehicleIdent createVehicleIdent() {
        VehicleIdent ident = new VehicleIdent();
        
        final String name = 
            "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZ";
        ident.setName(new DescriptiveName(name));
        
        byte[] vin = new byte[] {0x41, 0x61, 0x42, 0x62, 0x43};
        ident.setVin(new VINstring(vin));
        
        final String ownerCode = "AaBbCcDdEeFfGgHhIiJjK";
        ident.setOwnerCode(new DescriptiveName(ownerCode));
        
        byte[] id = new byte[] {0x00, 0x00, 0x00, 0x00};
        ident.setId(new TemporaryID(id));
        
        ident.setVehicleType(VehicleType.special);

        return ident;
    }

    //  Creates sample FullPositionVector value representing intial position
    private static FullPositionVector createInitial() {
        FullPositionVector initial = new FullPositionVector();
        
        initial.setUtcTime(new DDateTime(
            new DYear(2010), 
            new DMonth(1), 
            new DDay(16), 
            new DHour(21), 
            new DMinute(5), 
            new DSecond(30000)));
        
        initial.set_long(new Longitude(-887008270L));
        
        initial.setLat(new Latitude(-154554887L));
        
        final byte[] elevation = new byte[] {0x02, 0x00};
        initial.setElevation(new Elevation(elevation));
        
        initial.setHeading(new Heading(11441));
        
        byte[] tsAndSpeed = new byte[] {0x00, 0x00};
        initial.setSpeed(new TransmissionAndSpeed(tsAndSpeed));

        byte[] posAccuracy = new byte[] {(byte)0x04, (byte)0x02, 
            (byte)0xFF, (byte)0xFF};        
        initial.setPosAccuracy(new PositionalAccuracy(posAccuracy));
        
        initial.setTimeConfidence(TimeConfidence.unavailable);
        
        byte[] posConfidence = new byte[] {0x00};
        initial.setPosConfidence(new PositionConfidenceSet(posConfidence));
        
        byte[] speedConfidence = new byte[] {0x00};;
        initial.setSpeedConfidence(
                new SpeedandHeadingandThrottleConfidence(speedConfidence));

        return initial;
    }
}
